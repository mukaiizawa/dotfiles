View�p�R���\�[�� (Console.view class)
$Id: c-view.m 5859 2016-11-26 07:39:50Z kt $

*[man]
View��Œ��ڕ����̓��o�͂��s���ׂ̃R���\�[���B
.hierarchy Console.view
.caption �֘A����
.overview console

*import.@
	Mulk import: #("sconsole" "view")

*Console.view class.@
	ScreenConsole addSubclass: #Console.view instanceVars: "view vw vh fw fh"
**Console.view >> rawStart
	View ->view;
	view open
**Console.view >> rawSetSize
	view width ->vw;
	view height ->vh;
	view fontWidth ->fw;
	view fontHeight ->fh;
	vw // fw ->width;
	vh // fh ->height
**Console.view >> rawFinish
	view close
**Console.view >> rawScroll
	view copyAreaX: 0 Y: fh width: vw height: height - 1 * fh X: 0 Y: 0;
	view clearRectangleX: 0 Y: height - 1 * fh width: vw height: fh
**Console.view >> rawLineFeed
	self!
**Console.view >> rawPutChar: ch
	curX * fw ->:x;
	curY * fh ->:y;
	view clearRectangleX: x Y: y width: fw * ch width height: fh;
	view drawX: x Y: y char: ch
**Console.view >> rawClear
	view clear
**Console.view >> rawFetch
	curX * fw ->:x;
	curY * fh ->:y;
	self charX: curX Y: curY ->:ch;
	ch = #skip ifTrue: [' ' ->ch];
	view fillRectangleX: x Y: y width: fw * ch width height: fh;
	view drawX: x Y: y char: ch color: view background;
	view get asChar ->:result;
	self rawPutChar: ch;
	result!
**Console.view >> rawFetch?
	view hit?!
**Console.view >> rawShiftMode: modeArg
	view property: 0 put: modeArg

**api.
***Console.view >> font: fontName
	view font: fontName;
	self resetScreen
****[man.m]
�w�肳�ꂽ�t�H���g�ɐ؂�ւ���B
��ʂ̓N���A����J��������s���͍Đݒ肳���B
