/*
	primitive support.
	$Id: prim.h 3665 2014-10-19 02:21:41Z kt $
*/

#include "xbarray.h"
#define PRIM(name) int prim_##name(object self,object *args,object *result)

#define GET_SINT_ARG(i,num) \
{ \
	object o; \
	o=args[i]; \
	if(!sint_p(o)) return FALSE; \
	num=sint_val(o); \
}

extern int p_strings_val(int n,object *os,char **ss);
extern char *p_string_val(object);
extern object p_string_xbarray(struct xbarray *x);
extern int p_byte_p(int byte);
extern int p_farray_to_array(object fa,int *size,object **array);
extern object p_lint(int64_t val);
extern object p_int64(int64_t val);
extern int p_int64_val(object i,int64_t *valp);
extern object p_intptr(intptr_t val);
extern int p_intptr_val(object o,intptr_t *valp);
extern object p_float(double val);
extern int p_float_val(object o,double *valp);
