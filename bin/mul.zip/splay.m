splay�� (Splay class)
$Id: splay.m 6282 2017-05-11 13:14:41Z kt $

*[man]
.caption ����
�A�z�z���splay�؂ɂ������B
.hierarchy Splay
�L�[�ƂȂ�l���m�͔�r�\(Magnitude������)�łȂ��Ă͂Ȃ�Ȃ��B

*Splay.Node class.@
	Object addSubclass: #Splay.Node instanceVars: "key value left right"
**Splay.Node >> key: keyArg
	keyArg ->key
**Splay.Node >> key
	key!
**Splay.Node >> value: valueArg
	valueArg ->value
**Splay.Node >> value
	value!
**Splay.Node >> left: leftArg
	leftArg ->left
**Splay.Node >> left
	left!
**Splay.Node >> right: rightArg
	rightArg ->right
**Splay.Node >> right
	right!

**Splay.Node >> rotL
	left ->:p;
	p right ->left;
	p right: self;
	p!
**Splay.Node >> rotR
	right ->:p;
	p left ->right;
	p left: self;
	p!
**Splay.Node >> rotLL
	left ->:p;
	p left ->:q;
	p left: q right;
	q right: self;
	q!
**Splay.Node >> rotRR
	right ->:p;
	p right ->:q;
	p right: q left;
	q left: self;
	q!
**Splay.Node >> rotLR
	left ->:p;
	p right ->:q;
	p right: q left;
	q left: p;
	q right ->left;
	q right: self;
	q!
**Splay.Node >> rotRL
	right ->:p;
	p left ->:q;
	p left: q right;
	q right: p;
	q left ->right;
	q left: self;
	q!
**Splay.Node >> printOn: wr
	value nil? ifTrue: [self!];
	wr put: '(';
	left printOn: wr;
	wr put: value;
	right printOn: wr;
	wr put: ')'
		
*Splay class.@
	Object addSubclass: #Splay instanceVars: "top sentinel"
**Splay >> init
	Splay.Node new ->sentinel ->top
**Splay >> balance: key
	sentinel key: key;
	sentinel left: sentinel;
	sentinel right: sentinel;
	top ->:p;
	[key compareTo: p key ->:d, <> 0] whileTrue:
		[d < 0
			ifTrue:
				[p left ->:q;
				key compareTo: q key ->d, = 0
					ifTrue: [p rotL!]
					ifFalse:
						[d < 0 ifTrue: [p rotLL] ifFalse: [p rotLR] ->p]]
			ifFalse:
				[p right ->q;
				key compareTo: q key ->d, = 0
					ifTrue: [p rotR!]
					ifFalse:
						[d > 0 ifTrue: [p rotRR] ifFalse: [p rotRL] ->p]]];
	p!

**Splay >> at: key put: value
	self balance: key ->:nt;
	nt = sentinel
		ifTrue:
			[Splay.Node new ->top;
			top left: sentinel left;
			top right: sentinel right;
			top key: key]
		ifFalse: [nt ->top];
	top value: value
***[man.m]
key�ɑΉ�����value��ݒ肷��B
	
**Splay >> resume
	top left = sentinel ifTrue: [top right ->top!];

	top right <> sentinel ifTrue:
		[top left ->:p;
		[p right <> sentinel] whileTrue: [p right ->p];
		p right: top right];
	top left ->top
	
**Splay >> at: key
	self balance: key ->top, = sentinel
		ifTrue:
			[self resume;
			nil]
		ifFalse: [top value]!
***[man.m]
key�ɑΉ�����l��Ԃ��B

�l���ݒ肳��Ă��Ȃ��ꍇ��nil��Ԃ��B

**Splay >> removeAt: key
	self balance: key ->top, = sentinel
		ifTrue:
			[self resume;
			self assertFailed];
	self resume
***[man.m]
key�ɑΉ�����l���폜����B
