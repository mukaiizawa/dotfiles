/*
	View class.
	$Id: view.c 6218 2017-04-01 23:36:39Z kt $
*/

#include "std.h"
#include "view.h"
#include "om.h"

#include "prim.h"

PRIM(view_open)
{
	int width,height;
	GET_SINT_ARG(0,width);
	GET_SINT_ARG(1,height);
	view_open(width,height);
	return TRUE;
}

PRIM(view_set_font)
{
	char *font;
	if((font=p_string_val(args[0]))==NULL) return FALSE;
	view_set_font(font);
	return TRUE;
}

PRIM(view_set_property)
{
	int prop;
	int64_t value;
	GET_SINT_ARG(0,prop);
	if(!p_int64_val(args[1],&value)) return FALSE;
	return view_set_property(prop,(int)value);
}

PRIM(view_get_property)
{
	int prop,value,st;
	GET_SINT_ARG(0,prop);
	st=view_get_property(prop,&value);
	*result=sint(value);
	return st;
}

PRIM(view_close)
{
	view_close();
	return TRUE;
}

PRIM(view_fill_rectangle)
{
	int x,y,width,height,color;
	GET_SINT_ARG(0,x);
	GET_SINT_ARG(1,y);
	GET_SINT_ARG(2,width);
	GET_SINT_ARG(3,height);
	GET_SINT_ARG(4,color);
	view_fill_rectangle(x,y,width,height,color);
	return TRUE;
}

PRIM(view_draw_char)
{
	int x,y,mbchar,color;

	GET_SINT_ARG(0,x);
	GET_SINT_ARG(1,y);
	GET_SINT_ARG(2,mbchar);
	GET_SINT_ARG(3,color);
	view_draw_char(x,y,mbchar,color);
	return TRUE;
}

PRIM(view_draw_line)
{
	int x0,y0,x1,y1,color;
	GET_SINT_ARG(0,x0);
	GET_SINT_ARG(1,y0);
	GET_SINT_ARG(2,x1);
	GET_SINT_ARG(3,y1);
	GET_SINT_ARG(4,color);
	view_draw_line(x0,y0,x1,y1,color);
	return TRUE;
}

PRIM(view_put_true_color_image)
{
	int x,y,w,h;
	object rgb;
	
	GET_SINT_ARG(0,x);
	GET_SINT_ARG(1,y);
	rgb=args[2];
	if(om_class(rgb)!=om_FixedByteArray) return FALSE;
	GET_SINT_ARG(3,w);
	GET_SINT_ARG(4,h);
	view_put_true_color_image(x,y,rgb->fbarray.elt,w,h);
	return TRUE;
}

PRIM(view_copy_area)
{
	int fx,fy,w,h,tx,ty;

	GET_SINT_ARG(0,fx);
	GET_SINT_ARG(1,fy);
	GET_SINT_ARG(2,w);
	GET_SINT_ARG(3,h);
	GET_SINT_ARG(4,tx);
	GET_SINT_ARG(5,ty);
	view_copy_area(fx,fy,w,h,tx,ty);
	return TRUE;
}

PRIM(view_get)
{
	*result=sint(view_get());
	return TRUE;
}

PRIM(view_hit_p)
{
	*result=om_boolean(view_hit_p());
	return TRUE;
}
