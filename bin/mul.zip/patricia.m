�p�g���V�A��
$Id: patricia.m 3799 2014-12-28 23:54:03Z kt $

*[man]
.caption ����
�ȈՓI�ȃp�g���V�A�؁B

*BitArray class.@
	Object addSubclass: #BitArray instanceVars: "size bits"
**[man.c]
�Œ蒷�̃r�b�g�z��B

�v�f�Ƃ���0��1�̐��l�݂̂�ێ��ł���B

**BitArray >> init: sizeArg
	sizeArg ->size;
	FixedByteArray basicNew: size + 7 // 8 ->bits
***[man.m]
�T�C�Y���w�肵�Ĕz�������������B

**BitArray >> initString: stringArg
	stringArg size ->:stringSize;
	stringSize * 8 ->size;
	FixedByteArray basicNew: stringSize,
		basicAt: 0 copyFrom: stringArg at: 0 size: stringSize ->bits
***[man.m]
������Ŕz�������������B

**BitArray >> bytePos: pos
	pos // 8!
**BitArray >> bitPos: pos
	7 - (pos % 8)!

**BitArray >> size
	size!
***[man.m]
�z��̃T�C�Y��Ԃ��B

**BitArray >> at: pos
	bits at: (self bytePos: pos), >> (self bitPos: pos), & 1!
***[man.m]
�ʒupos�̓��e��Ԃ��B

**BitArray >> at: pos put: val
	self bytePos: pos ->:bytePos;
	1 << (self bitPos: pos) ->:mask;
	bits at: bytePos, & (0xff ^ mask) ->:byte;
	val = 1 ifTrue: [byte | mask ->byte];
	bits at: bytePos put: byte
***[man.m]
�ʒupos�ɒlval��ݒ肷��B

**BitArray >> printOn: wr
	size timesDo:
		[:pos
		pos <> 0 & (pos % 8 = 0) ifTrue: [wr put: '_'];
		wr put: (self at: pos)]
**BitArray >> missmatchIndex: ba offset: off
	ba size - off ->:baSize;
	size min: baSize ->:cmpSize;
	cmpSize timesDo:
		[:pos
		self at: pos, <> (ba at: pos + off), ifTrue: [pos!]];
	size = baSize ifTrue: [#equal!];
	size > baSize ifTrue: [#selfLong!];
	#argLong!
**BitArray >> copyFrom: from until: until
	until - from ->:newSize;
	BitArray new init: newSize ->:result;
	newSize timesDo:
		[:i
		result at: i put: (self at: i + from)];
	result!
**BitArray >> copyFrom: from
	self copyFrom: from until: size!
**BitArray >> copyUntil: until
	self copyFrom: 0 until: until!
					
*Patricia.Node class.@
	Object addSubclass: #Patricia.Node instanceVars:
		"key value child0 child1"
**Patricia.Node >> key
	key!
**Patricia.Node >> key: keyArg
	keyArg ->key
**Patricia.Node >> value
	value!
**Patricia.Node >> value: valueArg
	valueArg ->value
**Patricia.Node >> at: side
	side = 0 ifTrue: [child0] ifFalse: [child1]!
**Patricia.Node >> at: side put: child
	side = 0 ifTrue: [child ->child0] ifFalse: [child ->child1]
**Patricia.Node >> dump: depth
	Out put: "  " times: depth;
	Out putLn: key asString + ": " + value;
	child0 notNil? ifTrue: [child0 dump: depth + 1];
	child1 notNil? ifTrue: [child1 dump: depth + 1]
**Patricia.Node >> splitAt: pos
	Patricia.Node new
		key: (key copyFrom: pos),
		value: value,
		at: 0 put: child0,
		at: 1 put: child1 ->:n2;
	key at: pos, = 0
		ifTrue:
			[n2 ->child0;
			nil ->child1]
		ifFalse:
			[nil ->child0;
			n2 ->child1];
	key copyUntil: pos ->key;
	nil ->value
**Patricia.Node >> sweep: block
	value notNil? ifTrue: [block value: value];
	child0 notNil? ifTrue: [child0 sweep: block];
	child1 notNil? ifTrue: [child1 sweep: block]
	
*Patricia class.@
	Object addSubclass: #Patricia instanceVars: "top"
**[man.c]
�p�g���V�A�؁B

key��BitArray�Avalue��C�ӂ̃I�u�W�F�N�g�Ƃ���A�z�z��Ƃ��ċ@�\����B

**Patricia >> nodeAt: key headMatch?: headMatch?
	top nil? ifTrue: [nil!];
	top ->:n;
	0 ->:off;
	[n key missmatchIndex: key offset: off ->:mi;
	mi = #equal ifTrue: [n!];
	mi = #selfLong ifTrue: [headMatch? ifTrue: [n] ifFalse: [nil]!];
	mi <> #argLong ifTrue: [nil!];
	off + n key size ->off;
	n at: (key at: off) ->n;
	n nil? ifTrue: [nil!]] loop

**Patricia >> at: key
	self nodeAt: key headMatch?: false, value!
***[man.m]
key�ɑΉ��t����ꂽ�l��Ԃ��B

**Patricia >> at: key put: value
	top nil? ifTrue: [Patricia.Node new key: key, value: value ->top!];

	top ->:n;
	0 ->:off;
	[n key missmatchIndex: key offset: off ->:mi;

	mi = #equal ifTrue: [n value: value!];
	mi = #selfLong ifTrue:
		[n splitAt: key size - off;
		n value: value!];
	mi <> #argLong ifTrue:
		[n splitAt: mi;
		off + mi ->off;
		Patricia.Node new key: (key copyFrom: off), value: value ->:n2;
		n at: (key at: off) put: n2!];
	--mi = #argLong
	off + n key size ->off;
	key at: off ->:side;
	n at: side ->n2, nil? ifTrue:
		[Patricia.Node new key: (key copyFrom: off), value: value ->n2;
		n at: side put: n2!];
	n2 ->n] loop
***[man.m]
key�ɑΉ�����value��ݒ肷��B

**Patricia >> headMatches: key
	Array new ->:result;
	self nodeAt: key headMatch?: true ->:n, notNil? ifTrue:
		[n sweep: [:v result addLast: v]];
	result!
***[man.m]
�L�[�̐擪�r�b�g��key�ƈ�v����S�Ă�value�̔z���Ԃ��B

**Patricia >> dump
	top notNil? ifTrue: [top dump: 0]
