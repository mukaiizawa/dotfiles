/*
	xc log.
	$Id: log.h 4 2009-08-11 14:52:30Z kt $
*/

extern void log_open(char *fn);
extern int log_p(void);
extern void log_c(int ch);
extern void log_ln(void);
extern void log_f(char *fmt,...);
extern void log_close(void);
