/*
	object memory.
	$Id: om.h 5296 2016-04-10 01:49:30Z kt $
*/

typedef union om *object;

union om {
#define HEADER int header
	HEADER;
#define OM_HASH_MASK 0x000fffff
#define OM_SIZE_MASK 0x0ff00000
#define OM_SIZE_POS 20
#define OM_GENERATION_MASK 0x30000000
#define OM_GENERATION_POS 28
#define OM_ALIVE_BIT 0x40000000
#define OM_REFNEW_BIT 0x80000000

#define SIZE_SINT 255 /* not om */

#define SIZE_FBARRAY 254
#define SIZE_STRING 253
#define SIZE_SYMBOL 252
	struct fbarray {
		HEADER;
		int size;
		char elt[1];
	} fbarray;

#define SIZE_FARRAY 251
	struct farray {
		HEADER;
		int size;
		object elt[1];
	} farray;

#define SIZE_LINT 250
	struct lint {
		HEADER;
		int64_t val;
	} lint;
	
#define SIZE_FLOAT 249
	struct xfloat {
		HEADER;
		double val;
	} xfloat;

#define SIZE_LAST 249 /* see base.m Class >> special? */

	struct gobject { /* general object */
#define OHEADER \
		HEADER; \
		object xclass
		OHEADER;
		object elt[1];
	} gobject;

#define SIZE_CLASS 6
	struct xclass {
		OHEADER;
		object name;
		object size;
		object superclass;
		object features;
		object instance_vars;
		object methods;
	} xclass;

	struct method {
		OHEADER;
		object belong_class;
		object selector;
		object arg_count;
		object prim_code;
		object ext_temp_size;
		object context_size;
		object bytecode;
		object literal;
	} method;

	/* executing */
	struct process {
		OHEADER;
		object context;
		object method;
		object ip;

		object frame_stack;
		object sp;
		object sp_used;
		object sp_max;
		object fp;
		
		object context_stack;
		object cp;
		object cp_used;
		object cp_max;

		object exception_handlers;
		object interrupt_block;
	} process;
	
#define SIZE_CONTEXT 3
	struct context {
		OHEADER;
		object method;
		object sp;
		object cp;
		object vars[1];
	} context;

	struct block {
		OHEADER;
		object context;
		object narg;
		object start;
	} block;

	struct xchar {
		OHEADER;
		object code;
/*attr:
	0x000001 -- isprint
	0x000002 -- isspace
	0x000004 -- isdigit
	0x000008 -- islower
	0x000010 -- isupper
	0x000020 -- mblead_p
	0x000040 -- mbtrail_p
	0x00ff00 -- trailSize
*/		
		object attr;
	} xchar;
	
#if OM_MEMORY_CHUNK_P
	object next;
#endif
};

#include "xarray.h"

#if MACRO_OM_P_P
#define om_p(o) ((((intptr_t)o)&1)==0)
#else
extern int om_p(object o);
#endif

#define SINT_BITS 30
#define SINT_MAX 0x3fffffff
#define SINT_MIN (-SINT_MAX-1)

#define LINT_BITS 63

#if MACRO_SINT_P_P
#define sint_p(o) ((((intptr_t)o)&1)==1)
#else
extern int sint_p(object o);
#endif

#if MACRO_SINT_VAL_P
#define sint_val(o) ((int)(((intptr_t)o)>>1))
#else
extern int sint_val(object o);
#endif

extern int sint_range_p(int i);

#if MACRO_SINT_P
#define sint(i) ((object)((((uintptr_t)i)<<1)|1))
#else
extern object sint(int i);
#endif

extern int om_hash(object o);
extern void om_set_hash(object o,int val);
extern void om_init_hash(object o);
extern int om_bytes_hash(char *p,int size);
extern void om_set_string_hash(object o);
extern int om_number_hash(double d);

#if MACRO_OM_SIZE_P
#define om_size(x) (sint_p(x)?SIZE_SINT:(x->header&OM_SIZE_MASK)>>OM_SIZE_POS)
#else
extern int om_size(object o);
#endif

extern void om_set_size(object o,int size);

extern object om_alloc(int size);
extern void om_free(object o);
extern int om_used_memory;
extern int om_max_used_memory;

extern struct xarray om_table;

extern object om_nil;
extern object om_true;
extern object om_false;

extern object om_Class;
extern object om_ShortInteger;
extern object om_LongInteger;
extern object om_Float;
extern object om_FixedByteArray;
extern object om_String;
extern object om_Symbol;
extern object om_FixedArray;
extern object om_Method;
extern object om_Process;
extern object om_Context;
extern object om_Block;
extern object om_Char;

extern object om_Mulk;
extern object om_boot;
extern object om_doesNotUnderstand;
extern object om_primitiveFailed;
extern object om_error;
extern object om_trap_cp_sp;
extern object om_equal;
extern object om_plus;
extern object om_lt;
extern object om_inc;
extern object om_dec;

/* utility */
extern void om_init_array(object *table,int size);
extern object om_class(object o);
extern object om_boolean(int b);

extern void om_init(void);

