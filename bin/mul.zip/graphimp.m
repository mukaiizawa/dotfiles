graph/vgraph common part.
$Id: graphimp.m 3391 2014-07-31 12:25:09Z kt $

*import.@
	Mulk import: #("csvrd" "point")
	
*Graph class.@
	Object addSubclass: #Graph
		instanceVars: "data xmin xmax ymin ymax width height"
		+ " planeWidth planeHeight"
**Graph >> read
	Array new ->data;
	CsvReader new init: In ->:r;
	[r get ->:ar, notNil?] whileTrue:
		[ar first asNumber @ (ar at: 1, asNumber) ->:pt;
		data empty?
			ifTrue:
				[pt x ->xmin ->xmax;
				pt y ->ymin ->ymax]
			ifFalse:
				[xmin > pt x ifTrue: [pt x ->xmin];
				xmax < pt x ifTrue: [pt x ->xmax];
				ymin > pt y ifTrue: [pt y ->ymin];
				ymax < pt y ifTrue: [pt y ->ymax]];
		data addLast: pt];
	xmax - xmin * 1.1 ->width;
	ymax - ymin * 1.1 ->height;
	width / 2 ->:dx;
	height / 2 ->:dy;
	xmin + xmax / 2 ->:cx;
	ymin + ymax / 2 ->:cy;
	cx - dx ->xmin;
	cx + dx ->xmax;
	cy - dy ->ymin;
	cy + dy ->ymax
**Graph >> convertX: x
	x - xmin / width * planeWidth + 0.5, asInteger!
**Graph >> convertY: y
	1 - (y - ymin / height) * planeHeight + 0.5, asInteger!
