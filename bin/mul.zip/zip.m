zip�A�[�J�C�o�[
$Id: zip.m 5622 2016-08-28 03:09:48Z kt $

*[man]
.caption ����
	zip.c [option] zipFile dir -- dir�̓��e��zipFile�ɂ܂Ƃ߂�B
	zip.l zipFile -- zipFile���̃t�@�C���ꗗ��\���B
	zip.e [option] zipFile dir -- zipFile�̓��e��dir���֓W�J����B
.caption ����
zipFile�փt�@�C����ۑ���������o�����肷��B
.caption �I�v�V����
	f -- �W�����͂���̃t�@�C�����X�g�̃t�@�C���݂̂�ΏۂƂ���B
	p dirname -- �A�[�J�C�u��̃p�X���ɑO�u����f�B���N�g���� (c�̂�)�B

*Zip class.@
	Mulk import: #("dl" "optparse");
	Object addSubclass: #Zip instanceVars: "zip"
**import libzip.@
	"libzip.so.2" ->:lib; -- linux
	Mulk.hostOS ->:os, = #windows ifTrue: ["libzip-4" ->lib];
	os = #cygwin ifTrue: ["cygzip-2.dll" ->lib];
	os = #freebsd ifTrue: ["libzip.so" ->lib];

	DL import: lib procs:
		#(#zip_open 3 #zip_close 1 #zip_source_file 6 #zip_get_num_entries 2
		#zip_get_name 3 #zip_fopen 3 #zip_fread 4 #zip_fclose 1);
	os = #windows
		ifTrue: [DL import: lib procs: #(#zip_file_add 4)]
		ifFalse: [DL import: lib procs: #(#zip_add 3)]
**Zip >> open: file mode: mode
	DL call: #zip_open with: file path with: mode with: 0 ->zip;
	self assert: zip <> 0
**Zip >> openCreate: file
	self open: file mode: 1
**Zip >> openRead: file
	self open: file mode: 0
**Zip >> addFile: file as: name
	DL call: #zip_source_file with: zip with: file path with: #(0 0 0 0) ->:zf;
	Mulk.hostOS = #windows
		ifTrue: [DL call: #zip_file_add with: zip with: name with: zf with: 0]
		ifFalse: [DL call: #zip_add with: zip with: name with: zf]
**Zip >> close
	DL call: #zip_close with: zip
**Zip >> list: block
	DL call: #zip_get_num_entries with: zip with: 0 ->:num;
	num timesDo:
		[:i
		DL call: #zip_get_name with: zip with: i with: 0 ->:addr;
		block value: (DL loadString: addr)]
**Zip >> readFile: srcfn to: destfile
	4096 ->:bufSize;
	FixedByteArray basicNew: bufSize ->:buf;
	DL call: #zip_fopen with: zip with: srcfn with: 0 ->:zfp;
	destfile writeDo:
		[:destwr
		0 ->:size;
		[DL call: #zip_fread with: zfp with: buf with: bufSize with: 0 ->:rd;
		self assert: rd <> -1;
		size + rd ->size;
		rd <> 0] whileTrue:
			[destwr write: buf size: rd]];
	DL call: #zip_fclose with: zfp;
	size = 0 ifTrue: [destfile remove]
			
*zip command.@
	Object addSubclass: #Cmd.zip instanceVars: "zip baseDir fileSet prefix"
**Cmd.zip >> initFileSet: op
	op at: 'f', ifTrue: [Set new addAll: In lines ->fileSet]
**Cmd.zip >> addFile: f
	f readableFile? ifFalse: [self!];

	f pathFrom: baseDir ->:fn;
	fileSet notNil? ifTrue: [fileSet includes?: fn, ifFalse: [self!]];

	prefix notNil? ifTrue: [prefix + fn ->fn];
	
	zip addFile: f as: fn
**Cmd.zip >> main.c: args
	OptionParser new init: "fp:" ->:op, parse: args ->args;

	self initFileSet: op;

	op at: 'p' ->prefix, notNil? ifTrue:
		[prefix last <> '/' ifTrue: [prefix + '/' ->prefix]];

	args first asFile ->:zipFile, none? ifFalse: [zipFile remove];
	args at: 1, asFile ->baseDir;
			
	Zip new openCreate: zipFile ->zip;
	baseDir deepList: [:f2 self addFile: f2];
	zip close
**Cmd.zip >> main.l: args
	Zip new openRead: args first asFile ->zip;
	zip list: [:name Out putLn: name];
	zip close
**Cmd.zip >> main.e: args
	OptionParser new init: "f" ->:op, parse: args ->args;
	self initFileSet: op;
	Zip new openRead: args first asFile ->zip;
	args at: 1, asFile ->baseDir;
	zip list:
		[:fn
		fileSet nil? or: [fileSet includes?: fn], ifTrue:
			[zip readFile: fn to: baseDir + fn]];
	zip close
