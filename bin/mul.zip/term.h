/*
	Terminal class.
	$Id: term.h 6287 2017-05-20 06:00:15Z kt $
*/

/* properties */
#include "kbd.h" /*0*/
#define TERM_WIDTH 1
#define TERM_HEIGHT 2

extern void term_start(void);
extern int term_set_property(int prop,int value);
extern int term_get_property(int prop,int *value);
extern void term_finish(void);

extern int term_get(void);
extern void term_put(char *p,int size);
extern int term_hit_p(void);
extern void term_goto_xy(int x,int y);
extern void term_clear(void);
