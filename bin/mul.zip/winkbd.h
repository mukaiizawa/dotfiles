/*
	windows keyboard i/f.
	$Id: winkbd.h 2871 2014-01-03 11:46:12Z kt $
*/

extern int winkbd_type;
#define WINKBD_JIS 0
#define WINKBD_OTHER 1

extern int winkbd_shift_mode;

extern void winkbd_init(void);
extern int winkbd_down(int code);
extern int winkbd_up(int code);
