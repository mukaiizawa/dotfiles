/*
	windows keyboard i/f.
	$Id: winkbd.c 2871 2014-01-03 11:46:12Z kt $
*/

#include "std.h"
#include <windows.h>

#include "kbd.h"
#include "winkbd.h"

int winkbd_type;
int winkbd_shift_mode;

struct vktable {
	int code;
	int normal;
	int shift;
	int ctrl;
	int left_p;
};

static struct vktable jis_vktable[]={
	{VK_ESCAPE,27,-1,-1,TRUE},
/*row1*/
	{'1','1','!',-1,TRUE},
	{'2','2','"',-1,TRUE},
	{'3','3','#',-1,TRUE},
	{'4','4','$',-1,TRUE},
	{'5','5','%',-1,TRUE},
	{'6','6','&','&',FALSE},
	{'7','7','\'',-1,FALSE},
	{'8','8','(',-1,FALSE},
	{'9','9',')',-1,FALSE},
	{'0','0',-1,-1,FALSE},
	{VK_OEM_MINUS,'-','=',-1,FALSE},
	{VK_OEM_7,'^','~',-1,FALSE},
	{VK_OEM_5,'\\','|',28,FALSE},
	{VK_BACK,8,8,-1,FALSE},
/*r2*/
	{VK_TAB,9,9,-1,FALSE},
	{'Q','q','Q',17,TRUE},
	{'W','w','W',23,TRUE},
	{'E','e','E',5,TRUE},
	{'R','r','R',18,TRUE},
	{'T','t','T',20,TRUE},
	{'Y','y','Y',25,FALSE},
	{'U','u','U',21,FALSE},
	{'I','i','I',9,FALSE},
	{'O','o','O',15,FALSE},
	{'P','p','P',16,FALSE},
	{VK_OEM_3,'@','`',0,FALSE},
	{VK_OEM_4,'[','{',27,FALSE},
	{VK_RETURN,13,13,-1,FALSE},
/*r3*/
	{'A','a','A',1,TRUE},
	{'S','s','S',19,TRUE},
	{'D','d','D',4,TRUE},
	{'F','f','F',6,TRUE},
	{'G','g','G',7,TRUE},
	{'H','h','H',8,FALSE},
	{'J','j','J',10,FALSE},
	{'K','k','K',11,FALSE},
	{'L','l','L',12,FALSE},
	{VK_OEM_PLUS,';','+',-1,FALSE},
	{VK_OEM_1,':','*',-1,FALSE},
	{VK_OEM_6,']','}',29,FALSE},
/*r4*/
	{'Z','z','Z',26,TRUE},
	{'X','x','X',24,TRUE},
	{'C','c','C',3,TRUE},
	{'V','v','V',22,TRUE},
	{'B','b','B',2,TRUE},
	{'N','n','N',14,FALSE},
	{'M','m','M',13,FALSE},
	{VK_OEM_COMMA,',','<',-1,FALSE},
	{VK_OEM_PERIOD,'.','>',-1,FALSE},
	{VK_OEM_2,'/','?',-1,FALSE},
	{VK_OEM_102,'\\','_',28,FALSE},
/*r5*/
	{' ',' ',0,0,FALSE}
};

#define MAXCODE 0xff
static struct vktable *vktable[MAXCODE];

int winkbd_type=-1;
int winkbd_mode;

void winkbd_init(void)
{
	int i;
	struct vktable *p;
	
	if(winkbd_type==-1) {
		if(GetKeyboardType(0)==7) {
			winkbd_type=WINKBD_JIS;
			for(i=0;i<sizeof(jis_vktable)/sizeof(struct vktable);i++) {
				p=&jis_vktable[i];
				vktable[p->code]=p;
			}
			winkbd_shift_mode=KBD_CROSS_SHIFT_MODE;
		} else winkbd_type=WINKBD_OTHER;
	}
}

static int type_space_p;

static int press_p(int code)
{
	return GetKeyState(code)&0x8000;
}

#define SELECT_NORMAL 0
#define SELECT_SHIFT 1
#define SELECT_CTRL 2

int winkbd_down(int code)
{
	struct vktable *v;
	int select;
	
	if(winkbd_shift_mode==KBD_SPACE_SHIFT_MODE&&code==' ') {
		type_space_p=TRUE;
		return -1;
	}

	if(!(0<=code&&code<MAXCODE)) return -1;
	if((v=vktable[code])==NULL) return -1;

	select=SELECT_NORMAL;
	if(press_p(VK_LSHIFT)||press_p(VK_RSHIFT)) select=SELECT_SHIFT;
	else if(press_p(VK_LCONTROL)||press_p(VK_RCONTROL)) select=SELECT_CTRL;
	else {
		if(winkbd_shift_mode==KBD_CROSS_SHIFT_MODE) {
			if(press_p(VK_NONCONVERT)) {
				if(v->left_p) select=SELECT_CTRL;
				else select=SELECT_SHIFT;
			} else if(press_p(VK_CONVERT)) {
				if(v->left_p) select=SELECT_SHIFT;
				else select=SELECT_CTRL;
			}
		} else if(winkbd_shift_mode==KBD_SPACE_SHIFT_MODE) {
			if(press_p(' ')) {
				select=SELECT_SHIFT;
				type_space_p=FALSE;
			} else if(press_p(VK_NONCONVERT)||press_p(VK_CONVERT)) {
				select=SELECT_CTRL;
			}
		}
	}

	if(select==SELECT_NORMAL) return v->normal;
	else if(select==SELECT_SHIFT) return v->shift;
	else return v->ctrl;
}

int winkbd_up(int code)
{
	if(winkbd_shift_mode==KBD_SPACE_SHIFT_MODE&&code==' '&&type_space_p) {
		return ' ';
	} else return -1;
}
