deepCopy.
$Id: deepcopy.m 5453 2016-07-23 13:02:02Z kt $

*[man]
.caption ����
�I�u�W�F�N�g���Q�ƍ\�����܂߂ĕ�������B

����\����A�����ӏ�����̓���I�u�W�F�N�g�̎Q�Ƃ������Ă��K�؂ɓ��삷��B

*DeepCopyer.CopyInfo class.@
	Object addSubclass: #DeepCopyer.CopyInfo instanceVars: "from to index"
**DeepCopyer.CopyInfo >> initFrom: fromArg to: toArg index: indexArg
	fromArg ->from;
	toArg ->to;
	indexArg ->index
**DeepCopyer.CopyInfo >> from
	from!
**DeepCopyer.CopyInfo >> to
	to!
**DeepCopyer.CopyInfo >> index
	index!
	
*DeepCopyer class.@
	Object addSubclass: #DeepCopyer instanceVars: "objectMap queue"
**DeepCopyer >> deepCopy: object
	StrictDictionary new ->objectMap;
	Ring new ->queue;
	object deepCopyWith: self ->:result;
	[queue empty?] whileFalse:
		[queue first ->:info;
		queue removeFirst;
		info index ->:i;
		info to basicAt: i put: (info from basicAt: i, deepCopyWith: self)];
	result!
**DeepCopyer >> copyObject: object create: block
	objectMap at: object ifAbsentPut: [block value]!
**DeepCopyer >> enqueueCopyInfoFrom: from to: to index: index
	queue addLast: (DeepCopyer.CopyInfo new initFrom: from to: to index: index)

*copyies.
**Object >> deepCopyWith: copyer
	copyer copyObject: self create:
		[self class variableSize? ifTrue: [self basicSize] ifFalse: [0] ->:ext;
		self class basicNew: ext ->:result;
		self basicSize timesDo:
			[:i
			copyer enqueueCopyInfoFrom: self to: result index: i];
		result]!
**Nil >> deepCopyWith: copyer
	self!
**Class >> deepCopyWith: copyer
	self!
**Boolean >> deepCopyWith: copyer
	self!
**Number >> deepCopyWith: copyer
	self!
**AbstractChar >> deepCopyWith: copyer
	self!
**FixedByteArray >> deepCopyWith: copyer
	copyer copyObject: self create: [self copy]!
**AbstractString >> deepCopyWith: copyer
	self!
	
*Object >> deepCopy
	DeepCopyer new deepCopy: self!
**[man.m]
���������I�u�W�F�N�g��Ԃ��B
