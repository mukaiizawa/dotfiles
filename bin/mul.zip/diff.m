�e�L�X�g�t�@�C����r
$Id: diff.m 4954 2015-12-20 06:43:08Z kt $

*[man]
.caption ����
	diff file1 file2
.caption ����
file1��file2���s�P�ʂŔ�r����B
file2�Ƃ��ăf�B���N�g�����w�肷��ƁA�w��f�B���N�g������file1�Ɠ����̃t�@�C�����w�肳�ꂽ���̂Ƃ���B

file1�ɂ�����file2�ɂȂ��s��
	file1�̍s�ԍ�-�s�̓��e
.cont
file2�ɂ�����file1�ɂȂ��s��
	file2�̍s�ԍ�+�s�̓��e
.cont
�ƌ����`���ŕ\������B
|
based on "An O(NP) Sequence Comparison Algorithm" by Sun Wu, Udi Manber, Gene Myers, Webb Miller.

*Cmd.diff.Cord class.@
	Object addSubclass: #Cmd.diff.Cord instanceVars: "x y k"
**Cmd.diff.Cord >> x: xArg y: yArg k: kArg
	xArg ->x;
	yArg ->y;
	kArg ->k
**Cmd.diff.Cord >> x
	x!
**Cmd.diff.Cord >> y
	y!
**Cmd.diff.Cord >> k
	k!
**Cmd.diff.Cord >> printOn: writer
	writer put: "(" + x + ',' + y + ',' + k + ')'

*diff tool.@
	Object addSubclass: #Cmd.diff
		instanceVars: "a b m n offset path pathCord reverse? fp"
**Cmd.diff >> readFile: file
	file lines!
**Cmd.diff >> fp: pos
	fp at: pos + offset!
**Cmd.diff >> fp: pos put: value
	fp at: pos + offset put: value
**Cmd.diff >> path: pos
	path at: pos + offset!
**Cmd.diff >> path: pos put: value
	path at: pos + offset put: value
**Cmd.diff >> snake: k
	(self fp: k - 1) + 1 ->:above;
	self fp: k + 1 ->:below;
	above > below
		ifTrue:
			[self path: k - 1 ->:r;
			above ->:y]
		ifFalse:
			[self path: k + 1 ->r;
			below ->y];
	y - k ->:x;
	[x < m & (y < n) and: [a at: x, = (b at: y)]] whileTrue:
		[x + 1 ->x;
		y + 1 ->y];
	self path: k put: pathCord size;
	pathCord addLast: (Cmd.diff.Cord new x: x y: y k: r);
	y!
**Cmd.diff >> solveFp: k
	self fp: k put: (self snake: k)
**Cmd.diff >> printDiff: side at: pos
	side = #a ifTrue: [a] ifFalse: [b] ->:array;
	side = #a = reverse? not ifTrue: ['-'] ifFalse: ['+'] ->:mark;
	Out put: pos + 1 width: 7,
		put: mark,
		putLn: (array at: pos)
**Cmd.diff >> main: args
	args first asFile ->:aFile;
	self readFile: aFile ->a;

	args at: 1, asFile ->:bFile;
	bFile directory? ifTrue: [bFile + aFile name ->bFile];
	self readFile: bFile ->b;

	a size > b size ->reverse?, ifTrue:
		[a ->:tmp;
		b ->a;
		tmp ->b];
		
	a size ->m;
	b size ->n;

	n - m ->:delta;
	m + 1 ->offset;
	Array new size: m + n + 3, fill: -1 ->fp;
	Array new size: m + n + 3, fill: -1 ->path;
	Array new ->pathCord;

	-1 ->:p;
	[p + 1 ->p;
	p negated ->:k;
	[k <= (delta - 1)] whileTrue:
		[self solveFp: k;
		k + 1 ->k];
	delta + p ->k;
	[k >= (delta + 1)] whileTrue:
		[self solveFp: k;
		k - 1 ->k];
	self solveFp: delta;
	pathCord size > 100000 ifTrue: [Out putLn: "TOO MANY DIFFS."!];
	self fp: delta, <> n] whileTrue;

	self path: delta ->:r;
	Array new ->:epc;
	[r <> -1] whileTrue:
		[pathCord at: r ->:c;
		epc addLast: c;
		c k ->r];

	0 ->:x;
	0 ->:y;
	epc reverseDo:
		[:e
		[x < e x | (y < e y)] whileTrue:
			[e y - e x - y + x ->:d;
			d = 0
				ifTrue:
					[x + 1 ->x;
					y + 1 ->y]
				ifFalse:
					[d > 0
						ifTrue:
							[self printDiff: #b at: y;
							y + 1 ->y]
						ifFalse:
							[self printDiff: #a at: x;
							x + 1 ->x]]]]
				
