�L�����N�^�[���p�R���\�[�� (Console.term class)
$Id: c-term.m 5859 2016-11-26 07:39:50Z kt $

*[man]
.caption ����
	cset term
.caption ����
�L�����N�^�[����ł̃J�[�\�����[�V�����ɑΉ������R���\�[���B
.hierarchy Console.term
.caption �֘A����
.overview console

*import.@
	Mulk import: #("sconsole" "term")

*Console.term class.@
	ScreenConsole addSubclass: #Console.term instanceVars: "term tCurX tCurY"
**Console.term >> rawStart
	Terminal new start ->term
**Console.term >> rawSetSize
	term width ->width;
	term height ->height
**Console.term >> rawFinish
	term finish
**Console.term >> rawScroll
	term autoLineFeedIfLineFilled? & (tCurX = width) ifTrue: [self!];
	
	tCurY <> (height - 1) ifTrue:
		[height - 1 ->tCurY;
		term gotoX: 0 Y: tCurY];
	0 ->tCurX;
	term put: '\r', put: '\n'
**Console.term >> rawLineFeed
	term autoLineFeedIfLineFilled? & (tCurX = width) ifTrue:
		[0 ->tCurX;
		tCurY + 1 ->tCurY;
		tCurY = height ifTrue: [tCurY - 1 ->tCurY]]
**Console.term >> moveCursor
	curX <> tCurX | (curY <> tCurY) ifTrue:
		[term gotoX: curX Y: curY;
		curX ->tCurX;
		curY ->tCurY]
**Console.term >> rawPutChar: ch
	self moveCursor;
	term put: ch;
	tCurX + ch width ->tCurX
**Console.term >> rawClear
	term clear;
	0 ->tCurX ->tCurY
**Console.term >> rawFetch
	self moveCursor;
	term get asChar!
**Console.term >> rawFetch?
	term hit?!
**Console.term >> rawShiftMode: modeArg
	term property: 0 put: modeArg
