/*
	mulk main routine.
	$Id: mulk.c 5017 2016-01-10 06:21:39Z kt $
*/

#include "std.h"

#include <stdlib.h>
#include <string.h>

#if WINDOWS_P
#include <io.h>
#include <fcntl.h>
#endif

#include "xgetopt.h"
#include "pf.h"

#include "om.h"
#include "gc.h"
#include "ir.h"
#include "ip.h"

static char *main_class;
static char *image_pn;
static int frame_stack_size;
static int context_stack_size;

static void option(int argc,char *argv[])
{
	int ch;
	
	main_class=NULL;
	image_pn=NULL;
	frame_stack_size=DEFAULT_FRAME_STACK_SIZE;
	context_stack_size=DEFAULT_CONTEXT_STACK_SIZE;
	
	while((ch=xgetopt(argc,argv,"m:i:f:c:"))!=EOF) switch(ch) {
	case 'm': main_class=xoptarg; break;
	case 'i': image_pn=xoptarg; break;
	case 'f': frame_stack_size=atoi(xoptarg); break;
	case 'c': context_stack_size=atoi(xoptarg); break;
	default:
		fputs("\
-m CLASS as main class.\n\
-i FN as image file.\n\
-f KSIZE as frame stack size.\n\
-c KSIZE as context stack size.\n\
",stderr);
		exit(1);
	}
}

static object make_boot_args(int argc,char *argv[])
{
	object boot_args,main_args;
	int i;
	
	boot_args=gc_object_new(om_FixedArray,3);
	if(main_class==NULL) boot_args->farray.elt[0]=om_nil;
	else boot_args->farray.elt[0]=gc_string(main_class);

	main_args=gc_object_new(om_FixedArray,argc);
	for(i=0;i<argc;i++) main_args->farray.elt[i]=gc_string(argv[i]);
	boot_args->farray.elt[1]=main_args;

	boot_args->farray.elt[2]=gc_string(image_pn);
	
	return boot_args;
}

static void read_image(char *fn)
{
	struct pf_stat stat;
	char *mem;
	FILE *fp;
	
	pf_stat(fn,&stat);
	mem=xmalloc((int)stat.size);

	if((fp=fopen(fn,"rb"))==NULL) xerror("read_image/open %s failed.",fn);
	fread(mem,1,(int)stat.size,fp);
	fclose(fp);

	ir(mem);
	xfree(mem);
}

int main(int argc,char *argv[])
{
	object boot_args;
	char buf[MAX_STR_LEN];
	
	setbuf(stdout,NULL);
#if WINDOWS_P
#ifdef __BORLANDC__
#define _setmode setmode
#endif
	_setmode(_fileno(stdin),_O_BINARY);
	_setmode(_fileno(stdout),_O_BINARY);
#endif

	option(argc,argv);
	if(image_pn==NULL) {
		pf_exepath(argv[0],buf);
#if !UNIX_P
		*strrchr(buf,'.')='\0';
#endif
		strcat(buf,".mi");
		image_pn=buf;	
	}

	om_init();
	read_image(image_pn);
	gc_init();

	boot_args=make_boot_args(argc-xoptind,&argv[xoptind]);

	ip_start(boot_args,frame_stack_size*K,context_stack_size*K);
	return 0;
}
