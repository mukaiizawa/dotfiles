InternetResource.ie class.
$Id: irie.m 5522 2016-08-05 21:02:42Z kt $

*[man]
.caption ����
Internet explorer��MSXML2.XmlHttp��p�����C���^�[�l�b�g���\�[�X�̎擾�B
.caption ��������
windows�ł̂ݓ���B

*InternetResource.ie class.@
	Object addSubclass: #InternetResource.ie
**InternetResource.ie >> makeScriptToGet: url to: file
	Out putLn: "var xmlhttp=WScript.CreateObject(\"MSXML2.XmlHttp\");";
	Out putLn: "xmlhttp.open(\"GET\",\"" + url + "\",false);";
	Out putLn: "xmlhttp.send();";

	Out putLn: "var stream=WScript.CreateObject(\"ADODB.Stream\");";
	Out putLn: "stream.Type=1;";
	Out putLn: "stream.Open();";
	Out putLn: "stream.Write(xmlhttp.responseBody);";
	Out putLn: "stream.SaveToFile(" + file quotedPath + ");";
	Out putLn: "stream.Close();"
**InternetResource.ie >> get: url to: file
	[self makeScriptToGet: url to: file] pipe: "wsh";
	file resetStat none? ifTrue: [self error: "get " + url + " failed."]
