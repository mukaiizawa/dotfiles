/*
	primitive table for ib.
	$Id: ibprim.c 331 2010-09-26 06:41:21Z kt $
*/

#include "std.h"
#include "om.h"

#define PRIM(name) extern int prim_##name(object self,object *args,\
	object *result);
#include "ibprim.wk"
#undef PRIM

int (*prim_table[])(object self,object *args,object *result)={
#define PRIM(name) prim_##name,
#include "ibprim.wk"
#undef PRIM
	NULL
};

