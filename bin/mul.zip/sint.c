/*
	ShortInteger class.
	$Id: sint.c 3662 2014-10-18 13:30:54Z kt $
*/

#include "std.h"
#include "om.h"
#include "prim.h"

PRIM(sint_equal)
{
	int x,y;
	x=sint_val(self);
	GET_SINT_ARG(0,y);
	*result=om_boolean(x==y);
	return TRUE;
}

PRIM(sint_lt)
{
	int x,y;
	x=sint_val(self);
	GET_SINT_ARG(0,y);
	*result=om_boolean(x<y);
	return TRUE;
}

PRIM(sint_add)
{
	int x,y;
	x=sint_val(self);
	GET_SINT_ARG(0,y);
	x+=y;
	*result=p_int64(x);
	return TRUE;
}

PRIM(sint_multiply)
{
	int64_t x,y;
	x=sint_val(self);
	GET_SINT_ARG(0,y);

	*result=p_int64(x*y);
	return TRUE;
}

PRIM(sint_divide)
{
	int x,y;
	x=sint_val(self);
	GET_SINT_ARG(0,y);
	if(y==0) return FALSE;
	*result=p_int64(x/y);
	return TRUE;
}

PRIM(sint_modulo)
{
	int x,y;
	x=sint_val(self);
	GET_SINT_ARG(0,y);
	if(y==0) return FALSE;
	*result=sint(x%y);
	return TRUE;
}

PRIM(sint_and)
{
	int x,y;
	x=sint_val(self);
	GET_SINT_ARG(0,y);
	if(x<0||y<0) return FALSE;
	*result=sint(x&y);
	return TRUE;
}

PRIM(sint_or)
{
	int x,y;
	x=sint_val(self);
	GET_SINT_ARG(0,y);
	if(x<0||y<0) return FALSE;
	*result=sint(x|y);
	return TRUE;
}

PRIM(sint_xor)
{
	int x,y;
	x=sint_val(self);
	GET_SINT_ARG(0,y);
	if(x<0||y<0) return FALSE;
	*result=sint(x^y);
	return TRUE;
}

static int bits(int x)
{
	int i;
	for(i=0;i<SINT_BITS+1;i++) if(x<1<<i) return i;
	xassert(FALSE);
	return SINT_BITS;
}

PRIM(sint_shift)
{
	int x,y;
	x=sint_val(self);
	if(x<0) return FALSE;
	GET_SINT_ARG(0,y);
	if(x!=0) {
		if(y>0) {
			if(bits(x)+y>SINT_BITS) return FALSE;
			x<<=y;
		} else x>>=-y;
	}
	*result=sint(x);
	return TRUE;
}		

PRIM(sint_asLongInteger)
{
	*result=p_lint(sint_val(self));
	return TRUE;
}

PRIM(sint_asFloat)
{
	*result=p_float(sint_val(self));
	return TRUE;
}
