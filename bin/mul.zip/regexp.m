���K�\�� (RegExp class)
$Id: regexp.m 5539 2016-08-10 23:17:27Z kt $

*[man]
.caption ����
���K�\�����R���p�C�����A�}�b�`���O����B
.hierarchy RegExp
�R���p�C���������K�\���̓I�u�W�F�N�g���ɕێ����A�C�ӂɃ}�b�`���O�o����B

�T�|�[�g���郁�^�����͈ȉ��̒ʂ�B

	^ -- �s���B
	$ -- �s���B
	? -- �C�ӂ̈ꕶ���B
	[...] -- �O���[�v�Ɋ܂܂��C�ӂ�1�����B�擪��~�ŃN���[�v�Ɋ܂܂�Ȃ������Ƀ}�b�`����Bx-y��x����y�܂ł̕����ɑΉ��B
	\ -- �G�X�P�[�v�����BMulk�W���̃G�X�P�[�v�V�[�P���X�ɑΉ����鑼�A���^�����𒼐ڋL�q����̂ɗp����B
	x* -- �ꕶ���ɑΉ����鐳�K�\��x���\�Ȍ���}�b�`������B
	(x|y...) -- �C�ӂ̐��K�\��x, y...�̃}�b�`�����Ɏ��݂�B
	~x -- �w��ʒu�Ő��K�\��x�Ƀ}�b�`�����ꍇ�A�㑱�Ɋւ�炸�}�b�`�S�̂����s������B
	# -- �}�[�N�B�}�b�`�����ʒu��matchMarkPosAt:�ŎQ�Əo����B
|
.right 2
ein Sprache, ein Konstrukteur, ein Regelmaessige explession.
--der Konstrukteur.

*elements.
**RegExp.Elt class.@
	Object addSubclass: #RegExp.Elt instanceVars: "re next"
***RegExp.Elt >> init: reArg
	reArg ->re
***RegExp.Elt >> next: nextArg
	nextArg ->next
***RegExp.Elt >> next
	next!
***RegExp.Elt >> determin?
	false!

**RegExp.DeterminElt class.@
	RegExp.Elt addSubclass: #RegExp.DeterminElt
***RegExp.DeterminElt >> determin?
	true!

**RegExp.FirstElt class.@
	RegExp.DeterminElt addSubclass: #RegExp.FirstElt
***RegExp.FirstElt >> match
	re pos = 0!
****[test.m]
	RegExp new compile: "^" ->:re;
	self assert: (re match: "");
	RegExp new compile: "a^" ->re;
	self assert: (re match: "a") not
	
**Regexp.LastElt class.@
	RegExp.DeterminElt addSubclass: #RegExp.LastElt
***RegExp.LastElt >> match
	re fetch nil?!
****[test.m]
	RegExp new compile: "$" ->:re;
	self assert: (re match: "");
	RegExp new compile: "$a" ->re;
	self assert: (re match: "a") not

**Regexp.MarkElt class.@
	RegExp.DeterminElt addSubclass: #RegExp.MarkElt instanceVars: "pos"
***RegExp.MarkElt >> match
	re pos ->pos;
	true!
****[test.m]
	RegExp new compile: "a*#" ->:re;
	self assert: (re match: "aaa");
	self assert: (re matchMarkPosAt: 0) = 3
	
***RegExp.MarkElt >> pos
	pos!
	
**RegExp.SteppingElt class.@
	RegExp.DeterminElt addSubclass: #RegExp.SteppingElt
***RegExp.SteppingElt >> stepIfSatisfied: b
	b ifTrue: [re step];
	b!
	
**RegExp.AnyCharElt class.@
	RegExp.SteppingElt addSubclass: #RegExp.AnyCharElt
***RegExp.AnyCharElt >> match
	self stepIfSatisfied: re fetch notNil?!
****[test.m]
	RegExp new compile: "?" ->:re;
	self assert: (re match: "a");
	self assert: (re match: "") not
	
**RegExp.CharElt class.@
	RegExp.SteppingElt addSubclass: #RegExp.CharElt instanceVars: "ch"
***RegExp.CharElt >> ch: chArg
	chArg ->ch
***RegExp.CharElt >> match
	self stepIfSatisfied: re fetch = ch!
****[test.m]
	RegExp new compile: "a" ->:re;
	self assert: (re match: "a");
	self assert: (re match: "A") not

**RegExp.CaseInsensitiveCharElt class.@
	RegExp.SteppingElt addSubclass: #RegExp.CaseInsensitiveCharElt
		instanceVars: "lower upper"
***RegExp.CaseInsensitiveCharElt >> ch: chArg
	chArg ->lower;
	chArg upper ->upper
***RegExp.CaseInsensitiveCharElt >> match
	re fetch ->:ch;
	self stepIfSatisfied: (ch = lower or: [ch = upper])!
****[test.m]
	RegExp new caseInsensitive compile: "a" ->:re;
	self assert: (re match: "a");
	self assert: (re match: "A");
	self assert: (re match: "b") not
	
**RegExp.CharGroupElt class.@
	RegExp.SteppingElt addSubclass: #RegExp.CharGroupElt instanceVars: "set"
***RegExp.CharGroupElt >> set: setArg
	setArg ->set
***RegExp.CharGroupElt >> match
	self stepIfSatisfied: (set includes?: re fetch)!
****[test.m]
	RegExp new compile: "[bd]" ->:re;
	self assert: (re match: "a") not;
	self assert: (re match: "b");
	self assert: (re match: "c") not;
	self assert: (re match: "d");
	self assert: (re match: "e") not
****[test.m] range
	RegExp new compile: "[b-d]" ->:re;
	self assert: (re match: "a") not;
	self assert: (re match: "b");
	self assert: (re match: "c");
	self assert: (re match: "d");
	self assert: (re match: "e") not
****[test.m] caseInsensitive
	RegExp new caseInsensitive compile: "[bd]" ->:re;
	self assert: (re match: "A") not;
	self assert: (re match: "b");
	self assert: (re match: "c") not;
	self assert: (re match: "D");
	self assert: (re match: "e") not
****[test.m] caseInsensitiveRange
	RegExp new caseInsensitive compile: "[b-d]" ->:re;
	self assert: (re match: "A") not;
	self assert: (re match: "b");
	self assert: (re match: "c");
	self assert: (re match: "D");
	self assert: (re match: "e") not

**RegExp.ExcludeCharGroupElt class.@
	RegExp.CharGroupElt addSubclass: #RegExp.ExcludeCharGroupElt
***RegExp.ExcludeCharGroupElt >> match
	self stepIfSatisfied:
		(re fetch ->:ch, notNil? and: [set includes?: ch, not])!
****[test.m]
	RegExp new compile: "[~bd]" ->:re;
	self assert: (re match: "a");
	self assert: (re match: "b") not;
	self assert: (re match: "c");
	self assert: (re match: "d") not;
	self assert: (re match: "e")
****[test.m] range
	RegExp new compile: "[~b-d]" ->:re;
	self assert: (re match: "a");
	self assert: (re match: "b") not;
	self assert: (re match: "c") not;
	self assert: (re match: "d") not;
	self assert: (re match: "e")
****[test.m] caseInsensitive
	RegExp new caseInsensitive compile: "[~bd]" ->:re;
	self assert: (re match: "A");
	self assert: (re match: "b") not;
	self assert: (re match: "c");
	self assert: (re match: "D") not;
	self assert: (re match: "e") 
****[test.m] caseInsensitiveRange
	RegExp new caseInsensitive compile: "[~b-d]" ->:re;
	self assert: (re match: "A");
	self assert: (re match: "b") not;
	self assert: (re match: "c") not;
	self assert: (re match: "D") not;
	self assert: (re match: "e")

**RegExp.SelectElt class.@
	RegExp.Elt addSubclass: #RegExp.SelectElt instanceVars: "alternatives"
***RegExp.SelectElt >> init
	Array new ->alternatives
***RegExp.SelectElt >> add: e
	alternatives addLast: e
***RegExp.SelectElt >> next: nextArg
	alternatives size timesDo:
		[:i
		alternatives at: i ->:e, nil?
			ifTrue: [alternatives at: i put: nextArg]
			ifFalse:
				[[e next notNil?] whileTrue: [e next ->e];
				e next: nextArg]]
***RegExp.SelectElt >> match
	re pos ->:p;
	alternatives do:
		[:elt
		re matchElt: elt from: p, ifTrue: [true!]];
	false!
****[test.m]
	RegExp new compile: "(ab|cd)" ->:re;
	self assert: (re match: "ab");
	self assert: (re match: "cd");
	self assert: (re match: "ef") not
****[test.m] 2
	RegExp new compile: "(a*|b*)" ->:re;
	self assert: (re match: "aaa") & (re matchEndPos = 3);
	self assert: (re match: "bbb") & (re matchEndPos = 0)
	
**RegExp.ClosureElt class.@
	RegExp.Elt addSubclass: #RegExp.ClosureElt instanceVars: "elt"
***RegExp.ClosureElt >> elt: eltArg
	self assert: (eltArg kindOf?: RegExp.SteppingElt);
	eltArg ->elt
***RegExp.ClosureElt >> match
	re pos ->:pos0;
	[elt match] whileTrue;
	re pos ->:pos1;
	pos1 to: pos0, do:
		[:p
		re matchElt: next from: p, ifTrue: [true!]];
	false!
****[test.m]
	RegExp new compile: "^a*$" ->:re;
	self assert: (re match: "");
	self assert: (re match: "a");
	self assert: (re match: "aa");
	self assert: (re match: "aab") not
	
**RegExp.NotElt class.@
	RegExp.DeterminElt addSubclass: #RegExp.NotElt instanceVars: "elt"
***RegExp.NotElt >> elt: eltArg
	eltArg ->elt
***RegExp.NotElt >> match
	re pos ->:pos;
	re matchElt: elt from: pos, not ->:result, ifTrue: [re pos: pos];
	result!
****[test.m]
	RegExp new compile: "^~b?*$" ->:re;
	self assert: (re match: "");
	self assert: (re match: "a");
	self assert: (re match: "ab");
	self assert: (re match: "b") not;
	self assert: (re match: "bc") not
****[test.m] 2
	RegExp new compile: "^~(abc)d$" ->:re;
	self assert: (re match: "d");
	--�ȉ��A�ے�p�^�[�����s���Ɋ����߂��Ȃ��Ɛ�������P�[�X�B
	self assert: (re match: "ad") not;
	self assert: (re match: "abd") not

*RegExp class.@
	Object addSubclass: #RegExp instanceVars:
		"reader sequence topElt pos target targetSize matchStartPos matchEndPos"
		+ " caseInsensitive? marks"

**RegExp >> init
	false ->caseInsensitive?;
	Array new ->marks
	
**compile.
***RegExp >> addElt: class
	class new init: self ->:e;
	sequence addLast: e;
	e!
***RegExp >> parseSelect
	reader skipChar;
	self addElt: RegExp.SelectElt ->:se;
	sequence ->:savedSequence;
	se add: self parseSequence;
	[reader nextChar = '|'] whileTrue:
		[reader skipChar;
		se add: self parseSequence];
	self assert: reader skipChar = ')';
	savedSequence ->sequence
***RegExp >> addChar: ch toSet: set
	caseInsensitive? and: [ch lower?], ifTrue: [set add: ch upper];
	set add: ch
***RegExp >> parseGroup
	reader skipChar;
	RegExp.CharGroupElt ->:class;
	reader nextChar = '~' ifTrue:
		[reader skipChar;
		RegExp.ExcludeCharGroupElt ->class];
	Set new ->:set;
	[reader nextChar <> ']'] whileTrue:
		[reader skipWideEscapeChar ->:ch;
		reader nextChar = '-',
			ifTrue:
				[reader skipChar;
				ch code to: reader skipWideEscapeChar code, do:
					[:code self addChar: code asChar toSet: set]]
			ifFalse: [self addChar: ch toSet: set]];
	reader skipChar;
	self addElt: class, set: set
***RegExp >> parseNot
	reader skipChar;
	self addElt: RegExp.NotElt ->:e;
	sequence ->:savedSequence;
	Array new ->sequence;
	self parseOne;
	e elt: sequence first;
	savedSequence ->sequence
***RegExp >> parseOne
	reader nextChar ->:ch;
	ch mblead? ifTrue:
		[ch trailSize + 1 timesRepeat:
			[self addElt: RegExp.CharElt, ch: reader skipChar]!];
	ch = '?' ifTrue:
		[reader skipChar;
		self addElt: RegExp.AnyCharElt!];
	ch = '^' ifTrue:
		[reader skipChar;
		self addElt: RegExp.FirstElt!];
	ch = '$' ifTrue:
		[reader skipChar;
		self addElt: RegExp.LastElt!];
	ch = '*' ifTrue:
		[reader skipChar;
		sequence last ->:e;
		sequence removeLast;
		self addElt: RegExp.ClosureElt, elt: e!];
	ch = '(' ifTrue: [self parseSelect!];
	ch = '[' ifTrue: [self parseGroup!];
	ch = '~' ifTrue: [self parseNot!];
	ch = '#' ifTrue:
		[reader skipChar;
		marks addLast: (self addElt: RegExp.MarkElt)!];
		
	caseInsensitive? and: [ch lower?],
		ifTrue: [self addElt: RegExp.CaseInsensitiveCharElt]
		ifFalse: [self addElt: RegExp.CharElt],
		ch: reader skipWideEscapeChar
***RegExp >> parseSequence
	Array new ->sequence;
	[reader nextChar ->:ch, nil? | (ch = '|') | (ch = ')')] whileFalse:
		[self parseOne];
	sequence empty?
		ifTrue: [nil]
		ifFalse:
			[sequence first ->:p;
			1 until: sequence size, do:
				[:i
				sequence at: i ->:n;
				p next: n;
				n ->p];
			sequence first]!

**match.
***access from elt.
****RegExp >> fetch
	pos = targetSize
		ifTrue: [nil!]
		ifFalse: [target at: pos!]
****RegExp >> step
	pos + 1 ->pos
****RegExp >> pos
	pos!
****RegExp >> pos: posArg
	posArg ->pos
	
***RegExp >> matchElt: elt from: tp
	tp ->pos;
	[elt notNil?] whileTrue:
		[elt determin?
			ifTrue:
				[elt match ifFalse: [false!];
				elt next ->elt]
			ifFalse: [elt match!]];
	true!
***RegExp >> startMatchElt: elt from: st
	st ->matchStartPos;
	self matchElt: elt from: st,
		ifTrue:
			[pos ->matchEndPos;
			true]
		ifFalse: [false]!

**api.
***RegExp >> caseInsensitive
	true ->caseInsensitive?
****[man.m]
���K�\�����̉p�������ɑ΂��A�啶�����}�b�`������B

compile:���ĂԑO�Ɏ��s����K�v������B
	
***RegExp >> compile: re
	AheadReader new init: re ->reader;
	self parseSequence ->topElt;
	self assert: reader nextChar nil?
****[man.m]
���K�\��pat���R���p�C������B

***RegExp >> match: targetArg from: st
	targetArg ->target;
	target size ->targetSize;

	topElt memberOf?: RegExp.FirstElt, ifTrue:
		[st = 0
			ifTrue: [self startMatchElt: topElt next from: st]
			ifFalse: [false]!];
			
	[st <= targetSize] whileTrue:
		[self startMatchElt: topElt from: st, ifTrue: [true!];
		st + 1 ->st];
	false!
****[man.m]
targetArg�������st�����ڈȍ~�����K�\���Ƀ}�b�`���邩���肷��B

***RegExp >> match: targetArg
	self match: targetArg from: 0!
****[man.m]
targetArg�����񂪐��K�\���Ƀ}�b�`���邩���肷��B

***RegExp >> matchStartPos
	matchStartPos!
****[man.m]
���������}�b�`�̐擪�ʒu��Ԃ��B

***RegExp >> matchEndPos
	matchEndPos!
****[man.m]
���������}�b�`�̏I�[�ʒu��Ԃ��B

***RegExp >> matchMarkPosAt: i
	marks at: i, pos!
****[man.m]
i�Ԗڂ̃}�[�N�̃}�b�`�����ʒu��Ԃ��B
