/*
	sleep in seconds.
	$Id: xsleep.c 5145 2016-02-20 10:21:07Z kt $
*/
#include "std.h"

#if WINDOWS_P
#include <windows.h>
#endif

#if UNIX_P
#include <time.h>
#endif

#if DOS_P
#include <dos.h>
#include "om.h"
#include "ip.h"
#include "dosterm.h"
#endif

void xsleep(double t)
{
#if WINDOWS_P
	Sleep((int)(t*1000));
#endif

#if UNIX_P
	struct timespec ts,rem;
	ts.tv_sec=t;
	ts.tv_nsec=(t-ts.tv_sec)*1000000000;
	nanosleep(&ts,&rem);
#endif

#if DOS_P
#define POLLING_MS 100
	t*=1000;
	while(t>POLLING_MS) {
		dosterm_check();
		if(ip_trap_code!=TRAP_NONE) return;
		delay(POLLING_MS);
		t-=POLLING_MS;
	}
	delay(t);
#endif
}
