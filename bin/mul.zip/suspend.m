�x�~
$Id: suspend.m 5857 2016-11-26 07:19:37Z kt $

*[man]
.caption ����
	suspend
.caption ����
windows���x�~(�T�X�y���h)��Ԃɂ���B
.caption ��������
windows�ł̂ݓ���B

*suspend tool.@
	Mulk import: "dl";
	Object addSubclass: #Cmd.suspend
**import dll.@
	DL import: "kernel32.dll" procs:
		#(	#GetCurrentProcess 100
			#CloseHandle 101
			#SetSystemPowerState 102);
	DL import: "advapi32.dll" procs:
		#(	#OpenProcessToken 103
		  	#LookupPrivilegeValueA 103
			#AdjustTokenPrivileges 106)
**Cmd.suspend >> main: args
	DL call: #GetCurrentProcess ->:process;
	DL.IntPtrBuffer new ->:token;
	-- 0x28 = TOKEN_ADJUST_PRIVILEGES | TOKEN_QUERY
	DL call: #OpenProcessToken with: process with: 0x28 with: token, = 0
		ifTrue: [self error: "OpenProcessToken failed."];
	DL.Buffer new init: 8 ->:luid;
	DL call: #LookupPrivilegeValueA with: 0 with: "SeShutdownPrivilege"
			with: luid, = 0
		ifTrue: [self error: "LookupPrivilegeValueA failed."];
	DL.Buffer new init: 16 ->:priv;
	priv buffer nativeInt32At: 0 put: 1;
	priv buffer nativeInt64At: 4 put: (luid buffer nativeInt64At: 0);
	priv buffer nativeInt32At: 12 put: 2 {SE_PRIVILEGE_ENABLED};
	DL call: #AdjustTokenPrivileges with: token value with: 0 with: priv
			with: 16 with: 0 with: 0, = 0
		ifTrue: [self error: "AdjustTokenPrivileges failed."];
	DL call: #CloseHandle with: token value;
	DL call: #SetSystemPowerState with: 1 with: 0
