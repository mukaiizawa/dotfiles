EUC->SJIS�ϊ���
$Id: ctres.m 3736 2014-11-30 02:28:02Z kt $

*[man]
EUC->SJIS��p��CodeTranslator�N���X�B

CodeTranslatorFactory���ԐړI�ɍ\�z�����̂ŁA���ڎg�p����K�v�͂Ȃ��B
.caption �֘A����
.overview ctrlib

*CodeTranslator.es class.@
	CodeTranslator addSubclass: #CodeTranslator.es
**CodeTranslator.es >> init: arg
	self assert: arg = "es"
**CodeTranslator.es >> translate: buf size: size
	self reserve: size;
	0 ->:ipos;
	0 ->:opos;
	[ipos < size] whileTrue:
		[buf at: ipos ->:b1;
		ipos + 1 ->ipos;
		b1 between: 0xa1 and: 0xfe,
			ifTrue:
				[b1 & 0x7f ->b1;
				buf at: ipos, & 0x7f ->:b2;
				ipos + 1 ->ipos;
				b1 & 1 = 1
					ifTrue:
						[b2 + (b2 < 0x60 ifTrue: [0x1f] ifFalse: [0x20]) ->b2]
					ifFalse: [b2 + 0x7e ->b2];
				b1 + (b1 < 0x5f ifTrue: [0xe1] ifFalse: [0x161]) >> 1 ->b1;
				resultBuf at: opos put: b1;
				resultBuf at: opos + 1 put: b2;
				opos + 2 ->opos]
			ifFalse:
				[resultBuf at: opos put: b1;
				opos + 1 ->opos]];
	opos!				
