/*
	terminal for windows.
	$Id: winterm.c 6287 2017-05-20 06:00:15Z kt $
*/

#include "std.h"
#include "cqueue.h"
#include "term.h"
#include "winkbd.h"

#include "om.h"
#include "ip.h"

#include <windows.h>

static int init_p=FALSE;

static HANDLE console_in;
static HANDLE console_out;
static DWORD saved_mode;
static struct cqueue cq;

static void init(void)
{
	winkbd_init();

	console_in=GetStdHandle(STD_INPUT_HANDLE);
	console_out=GetStdHandle(STD_OUTPUT_HANDLE);
	if(!GetConsoleMode(console_in,&saved_mode)) {
		xerror("term/GetConsoleMode failed.");
	}

	init_p=TRUE;
}

static void set_mode(DWORD mode)
{
	if(!SetConsoleMode(console_in,mode)) xerror("term/SetConsoleMode failed.");
}

void term_start(void)
{
	if(!init_p) init();
	set_mode(ENABLE_PROCESSED_INPUT);
	cqueue_reset(&cq);
}

int term_set_property(int prop,int value)
{
	switch(prop) {
	case KBD_SHIFT_MODE:
		winkbd_shift_mode=value;
		break;
	default:
		return FALSE;
	}
	return TRUE;
}

static void buffer_base(int *x,int *y)
{
	CONSOLE_SCREEN_BUFFER_INFO i;
	GetConsoleScreenBufferInfo(console_out,&i);
	*x=i.srWindow.Left; *y=i.srWindow.Top;
}

static void buffer_size(int *w,int *h)
{
	CONSOLE_SCREEN_BUFFER_INFO i;
	GetConsoleScreenBufferInfo(console_out,&i);
	*w=i.srWindow.Right-i.srWindow.Left+1;
	*h=i.srWindow.Bottom-i.srWindow.Top+1;
}

int term_get_property(int prop,int *value)
{
	int w,h;
	buffer_size(&w,&h);
	switch(prop) {
	case TERM_WIDTH:
		*value=w;
		break;
	case TERM_HEIGHT:
		*value=h;
		break;
	default:
		return FALSE;
	}
	return TRUE;
}

void term_finish(void)
{
	set_mode(saved_mode);
}

static void fetch(void)
{
	INPUT_RECORD input;
	DWORD nread,control_state;
	int ch;

	ReadConsoleInput(console_in,&input,1,&nread);
	if(input.EventType!=KEY_EVENT) return;
	
	if(winkbd_type==WINKBD_OTHER) {
		if(!input.Event.KeyEvent.bKeyDown) return;
		ch=input.Event.KeyEvent.uChar.AsciiChar;
		if(ch==0) return;
		control_state=input.Event.KeyEvent.dwControlKeyState;
		if(control_state&(LEFT_CTRL_PRESSED|RIGHT_CTRL_PRESSED)) ch&=0x1f;
	} else {
		ch=input.Event.KeyEvent.wVirtualKeyCode;
		if(input.Event.KeyEvent.bKeyDown) ch=winkbd_down(ch);
		else ch=winkbd_up(ch);
		if(ch==-1) return;
	}
	cqueue_put(&cq,ch);
}

int term_hit_p(void)
{
	DWORD nevent;
	while(TRUE) {
		GetNumberOfConsoleInputEvents(console_in,&nevent);
		if(nevent==0) break;
		fetch();
	}

	return !cqueue_empty_p(&cq);
}

int term_get(void)
{
	if(term_hit_p()) return cqueue_get(&cq);
	while(TRUE) {
		fetch();
		if(ip_trap_code!=TRAP_NONE) return 3;
		if(!cqueue_empty_p(&cq)) break;
	}
	return cqueue_get(&cq);
}

void term_put(char *p,int size)
{
	DWORD nwrite;
	WriteConsole(console_out,p,size,&nwrite,NULL);
}

void term_goto_xy(int x,int y)
{
	COORD c;
	int bx,by;

	buffer_base(&bx,&by);
	c.X=bx+x; c.Y=by+y;
	SetConsoleCursorPosition(console_out,c);
}

void term_clear(void)
{
	int w,h,bx,by;
	COORD c;
	DWORD nwrite;
	
	buffer_base(&bx,&by);
	buffer_size(&w,&h);
	
	c.X=bx; c.Y=by;
	FillConsoleOutputCharacter(console_out,' ',w*h,c,&nwrite);
	term_goto_xy(0,0);
}
