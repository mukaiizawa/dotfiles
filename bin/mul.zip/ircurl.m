InternetResource.curl class.
$Id: ircurl.m 5622 2016-08-28 03:09:48Z kt $

*[man]
.caption ����
curl���C�u������p�����C���^�[�l�b�g���\�[�X�̎擾�B

�ȉ���Mulk�����̓��e���Q�Ƃ���B
	InternetResource.curl.proxy -- �v���L�V�T�[�o�[��URL

*InternetResource.curl class.@
	Mulk import: "dl";
	Object addSubclass: #InternetResource.curl instanceVars: "curl"
**import.@
	"libcurl-gnutls.so.4" ->:lib; -- linux
	Mulk.hostOS ->:os, = #windows ifTrue: ["libcurl-4" ->lib];
	os = #cygwin ifTrue: ["cygcurl-4.dll" ->lib];
	os = #macosx ifTrue: ["libcurl.4.dylib" ->lib];
	os = #freebsd ifTrue: ["libcurl.so" ->lib];
	DL import: lib procs:
		#(#curl_easy_init 0 #curl_easy_setopt 3 #curl_easy_perform 1
		#curl_easy_cleanup 1)
**InternetResource.curl >> init
	DL call: #curl_easy_init ->curl;
	self assert: curl <> 0
**InternetResource.curl >> opt: sym
	sym = #writedata ifTrue: [10001!];
	sym = #url ifTrue: [10002!];
	sym = #proxy ifTrue: [10004!];
	sym = #stderr ifTrue: [10037!];
	sym = #verbose ifTrue: [41!];
	self error: "unknown CURLOPT " + sym
**InternetResource.curl >> setopt: opt with: arg
	DL call: #curl_easy_setopt with: curl with: (self opt: opt) with: arg,
		<> 0 ifTrue: [self error: "setopt failed"]
**InternetResource.curl >> perform
	DL call: #curl_easy_perform with: curl ->:code, <> 0 ifTrue:
		[self error: "perform failed " + code]
**InternetResource.curl >> verbose
	self setopt: #stderr with: (OS fp: 2); --stderr
	self setopt: #verbose with: 1
**InternetResource.curl >> proxy: p
	self setopt: #proxy with: p
**InternetResource.curl >> get: url to: file
	self setopt: #url with: url;
	Mulk includesKey?: #InternetResource.curl.proxy,
		ifTrue: [self proxy: (Mulk at: #InternetResource.curl.proxy)];
	file writeDo:
		[:fs
		self setopt: #writedata with: fs fp;
		self perform];
	DL call: #curl_easy_cleanup with: curl
