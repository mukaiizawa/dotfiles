/*
	LongInteger class.
	$Id: lint.c 3788 2014-12-26 14:07:55Z kt $
*/

#include "std.h"
#include "om.h"
#include "prim.h"

PRIM(lint_equal)
{
	int64_t x,y;
	x=self->lint.val;
	if(!p_int64_val(args[0],&y)) return FALSE;
	*result=om_boolean(x==y);
	return TRUE;
}

PRIM(lint_lt)
{
	int64_t x,y;
	x=self->lint.val;
	if(!p_int64_val(args[0],&y)) return FALSE;
	*result=om_boolean(x<y);
	return TRUE;
}

PRIM(lint_add)
{
	int64_t x,y,z;
	x=self->lint.val;
	if(!p_int64_val(args[0],&y)) return FALSE;
	if((y>0&&x>INT64_MAX-y)||(y<0&&x<INT64_MIN-y)) return FALSE;
	z=x+y;
	*result=p_int64(z);
	return TRUE;
}

PRIM(lint_multiply)
{
	int64_t x,y,z;
	x=self->lint.val;
	if(!p_int64_val(args[0],&y)) return FALSE;
	
	if(x>0) {
		if(y>0) {
			if(x>INT64_MAX/y) return FALSE;
		} else {
			if(y<INT64_MIN/x) return FALSE;
		}
	} else {
		if(y>0) {
			if(x<INT64_MIN/y) return FALSE;
		} else {
			if(x!=0&&y<INT64_MAX/x) return FALSE;
		}
	}
	
	z=x*y;
	
	*result=p_int64(z);
	return TRUE;
}

PRIM(lint_divide)
{
	int64_t x,y;
	x=self->lint.val;
	if(!p_int64_val(args[0],&y)) return FALSE;
	if(y==0) return FALSE;
	if(x==INT64_MIN&&y==-1) return FALSE;
	*result=p_int64(x/y);
	return TRUE;
}

PRIM(lint_modulo)
{
	int64_t x,y;
	x=self->lint.val;
	if(!p_int64_val(args[0],&y)) return FALSE;
	if(y==0) return FALSE;
	*result=p_int64(x%y);
	return TRUE;
}

PRIM(lint_and)
{
	int64_t x,y;
	x=self->lint.val;
	if(!p_int64_val(args[0],&y)) return FALSE;
	if(x<0||y<0) return FALSE;
	*result=p_int64(x&y);
	return TRUE;
}

PRIM(lint_or)
{
	int64_t x,y;
	x=self->lint.val;
	if(!p_int64_val(args[0],&y)) return FALSE;
	if(x<0||y<0) return FALSE;
	*result=p_int64(x|y);
	return TRUE;
}

PRIM(lint_xor)
{
	int64_t x,y;
	x=self->lint.val;
	if(!p_int64_val(args[0],&y)) return FALSE;
	if(x<0||y<0) return FALSE;
	*result=p_int64(x^y);
	return TRUE;
}

static int bits(int64_t x)
{
	int i;
	for(i=0;i<LINT_BITS;i++) if(x<INT64(1)<<i) return i;
	return LINT_BITS;
}

PRIM(lint_shift)
{
	int64_t x;
	int y;
	x=self->lint.val;
	if(x<0) return FALSE;
	GET_SINT_ARG(0,y);
	if(x!=0) {
		if(y>0) {
			if(bits(x)+y>LINT_BITS) return FALSE;
			x<<=y;
		} else x>>=-y;
	}
	*result=p_int64(x);
	return TRUE;
}

PRIM(lint_asFloat)
{
	*result=p_float((double)self->lint.val);
	return TRUE;
}
