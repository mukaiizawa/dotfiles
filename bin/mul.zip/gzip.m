gz�t�@�C�����k/�L��
$Id: gzip.m 5622 2016-08-28 03:09:48Z kt $

*[man]
.caption ����
	gzip gzFile -- ���͂�gzFile�Ɉ��k����B
	gzip.d gzFile -- gzFile��L�����o�͂���B
.caption ����
gz�`���ւ̈��k�A�L�����s���B

*gzip command.@
	Mulk import: "dl";
	Object addSubclass: #Cmd.gzip instanceVars: "bufsize buf gzfp"
**libz i/f.@
	"libz.so" ->:lib; -- linux/freebsd
	Mulk.hostOS ->:os, = #windows ifTrue: ["zlib1" ->lib];
	os = #cygwin ifTrue: ["cygz.dll" ->lib];
	os = #macosx ifTrue: ["libz.dylib" ->lib];
	DL import: lib procs: #(#gzopen 2 #gzread 3 #gzwrite 3 #gzclose 1)
***Cmd.gzip >> open: path mode: mode
	DL call: #gzopen with: path with: mode ->gzfp
***Cmd.gzip >> write: len
	DL call: #gzwrite with: gzfp with: buf with: len!
***Cmd.gzip >> read: len
	DL call: #gzread with: gzfp with: buf with: len!
***Cmd.gzip >> close
	DL call: #gzclose with: gzfp

**Cmd.gzip >> init
	4096 ->bufsize;
	FixedByteArray basicNew: bufsize ->buf
**Cmd.gzip >> main: args
	self open: args first mode:  "wb9";
	[In read: buf size: bufsize ->:s, <> 0] whileTrue: [self write: s];
	self close
**Cmd.gzip >> main.d: args
	self open: args first mode: "rb";
	[self read: bufsize ->:s, <> 0] whileTrue: [Out write: buf size: s];
	self close
