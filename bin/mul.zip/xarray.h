/*
	xc extensible array.
	$Id: xarray.h 63 2009-10-15 13:27:11Z kt $
*/

struct xarray {
	void **elt;
	int size;
	int alloc_size;
};

extern void xarray_reset(struct xarray *x);
extern void xarray_init(struct xarray *x);
extern void xarray_add(struct xarray *x,void *d);
extern void xarray_free(struct xarray *x);
extern void xarray_resize(struct xarray *x,int newsize);
