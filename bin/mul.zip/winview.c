/*
	view for windows.
	$Id: winview.c 3355 2014-07-24 11:44:50Z kt $
*/

#include "std.h"

#include <windows.h>
#include <process.h>

#include "cqueue.h"

#include "om.h"
#include "ip.h"

#include "view.h"
#include "winkbd.h"

static char *class_name;
static HWND window;
static HBITMAP bitmap;
static HDC bitmap_dc,window_dc;
static HFONT font;

static int view_width,view_height;
static int font_width,font_height;

static HANDLE thread,event;

static struct cqueue key_queue;
static HANDLE key_sem;
static CRITICAL_SECTION key_cs;

static int init_p=FALSE;

static void key_queue_put(int ch)
{
	EnterCriticalSection(&key_cs);
	cqueue_put(&key_queue,ch);
	LeaveCriticalSection(&key_cs);
	ReleaseSemaphore(key_sem,1,NULL);
}

static LRESULT CALLBACK window_proc(HWND hWnd,UINT msg,WPARAM wParam,
	LPARAM lParam)
{
	HDC dc;
	PAINTSTRUCT ps;
	int ch;

	switch(msg) {
	case WM_CLOSE:
		ip_trap_code=TRAP_QUIT;
		key_queue_put(0); /* for waiting key_sem */
		break;
	case WM_DESTROY:
		PostQuitMessage(0);
		break;
	case WM_PAINT:
		dc=BeginPaint(hWnd,&ps);
		BitBlt(dc,ps.rcPaint.left,ps.rcPaint.top,
			ps.rcPaint.right,ps.rcPaint.bottom,
			bitmap_dc,ps.rcPaint.left,ps.rcPaint.top,SRCCOPY);
		EndPaint(hWnd,&ps);
	case WM_CHAR:
		if(winkbd_type==WINKBD_OTHER) {
			if(wParam==3) ip_trap_code=TRAP_INTERRUPT;
			key_queue_put((int)wParam);
		}
		break;
	case WM_KEYDOWN:
		if(winkbd_type==WINKBD_JIS) {
			ch=winkbd_down((int)wParam);
			if(ch!=-1) {
				if(ch==3) ip_trap_code=TRAP_INTERRUPT;
				key_queue_put(ch);
			}
		}
		break;	
	case WM_KEYUP:
		if(winkbd_type==WINKBD_JIS) {
			ch=winkbd_up((int)wParam);
			if(ch!=-1) key_queue_put(ch);
		}
		break;
	default:
		return DefWindowProc(hWnd,msg,wParam,lParam);
	}

	return 0;
}

static unsigned WINAPI window_main(void *arg)
{
	DWORD dwStyle;
	RECT rect;
	MSG msg;
	HDC dc;
	
	dwStyle=WS_CAPTION|WS_SYSMENU|WS_MINIMIZEBOX;
	SetRect(&rect,0,0,view_width,view_height);
	AdjustWindowRect(&rect,dwStyle,FALSE);
	window=CreateWindow(class_name,class_name,dwStyle,CW_USEDEFAULT,
		CW_USEDEFAULT,rect.right-rect.left,rect.bottom-rect.top,NULL,NULL,
		GetModuleHandle(NULL),NULL);

	dc=GetDC(window);
	bitmap=CreateCompatibleBitmap(dc,view_width,view_height);
	bitmap_dc=CreateCompatibleDC(dc);
	SelectObject(bitmap_dc,bitmap);
	ReleaseDC(window,dc);

	cqueue_reset(&key_queue);
	key_sem=CreateSemaphore(NULL,0,255,NULL);
	InitializeCriticalSection(&key_cs);
	
	ShowWindow(window,SW_SHOW);

	SetEvent(event);
	while(GetMessage(&msg,NULL,0,0)) {
		TranslateMessage(&msg);
		DispatchMessage(&msg);
	}
	return 0;
}

/* api */
/** frame */

void view_open(int width,int height)
{
	WNDCLASSEX wc;
	
	if(!init_p) {
		winkbd_init();
		
		class_name="mulkView";

		wc.cbSize=sizeof(wc);
		wc.style=0;
		wc.lpfnWndProc=window_proc;
		wc.cbClsExtra=0;
		wc.cbWndExtra=0;
		wc.hInstance=GetModuleHandle(NULL);
		wc.hIcon=NULL;
		wc.hCursor=LoadCursor(NULL,IDC_ARROW);
		wc.hbrBackground=GetStockObject(WHITE_BRUSH);
		wc.lpszMenuName=NULL;
		wc.lpszClassName=class_name;
		wc.hIconSm=NULL;
		if(RegisterClassEx(&wc)==0) xerror("RegisterClass failed.");
		
		init_p=TRUE;
	}

	event=CreateEvent(NULL,FALSE,FALSE,NULL);

	if(width==0) width=640;
	if(height==0) height=480;	
	view_width=width;
	view_height=height;

	ResetEvent(event);
	thread=(HANDLE)_beginthreadex(NULL,0,window_main,NULL,0,NULL);
	WaitForSingleObject(event,INFINITE);

	font=NULL;
	view_set_font("MS Gothic");

	window_dc=GetDC(window);
	SetBkMode(window_dc,TRANSPARENT);
	SetBkMode(bitmap_dc,TRANSPARENT);
}

void view_set_font(char *font_name)
{
	char *p;

	if(font!=NULL) DeleteObject(font);
	
	p=strrchr(font_name,',');
	if(p!=NULL) {
		font_width=atoi(p+1);
		*p='\0';
	} else font_width=8;

	font_height=font_width*2;
	font=CreateFont(font_height,font_width,0,0,FW_DONTCARE,FALSE,FALSE,FALSE,
		SHIFTJIS_CHARSET,OUT_DEFAULT_PRECIS,CLIP_DEFAULT_PRECIS,DEFAULT_QUALITY,
		FIXED_PITCH|FF_DONTCARE,font_name);
	if(font==NULL) xerror("CreateFont failed.");
}

int view_set_property(int prop,int value)
{
	RECT rect;
	
	switch(prop) {
	case KBD_SHIFT_MODE:
		winkbd_shift_mode=value;
		break;
	case VIEW_ORIGIN_X:
		GetWindowRect(window,&rect);
		MoveWindow(window,value,rect.top,
			rect.right-rect.left,rect.bottom-rect.top,TRUE);
		break;
	case VIEW_ORIGIN_Y:
		GetWindowRect(window,&rect);
		MoveWindow(window,rect.left,value,
			rect.right-rect.left,rect.bottom-rect.top,TRUE);
		break;
	default:
		return FALSE;
	}
	return TRUE;
}

int view_get_property(int prop,int *value)
{
	switch(prop) {
	case VIEW_WIDTH:
		*value=view_width;
		break;
	case VIEW_HEIGHT:
		*value=view_height;
		break;
	case VIEW_FONT_WIDTH:
		*value=font_width;
		break;
	case VIEW_FONT_HEIGHT:
		*value=font_height;
		break;
	default:
		return FALSE;
	}
	return TRUE;
}

void view_close(void)
{
	ReleaseDC(window,window_dc);
	DestroyWindow(window);
	PostMessage(window,WM_DESTROY,0,0);
	WaitForSingleObject(thread,INFINITE);

	CloseHandle(thread);

	DeleteObject(font);

	DeleteDC(bitmap_dc);
	DeleteObject(bitmap);

	CloseHandle(key_sem);
	DeleteCriticalSection(&key_cs);
}

/** drawing */

static COLORREF wcolor(int color)
{
	return RGB((color>>16)&0xff,(color>>8)&0xff,color&0xff);
}

void view_fill_rectangle(int x,int y,int width,int height,int color)
{
	RECT rect;
	HBRUSH brush;

	brush=CreateSolidBrush(wcolor(color));
	
	rect.left=x;
	rect.top=y;
	rect.right=x+width;
	rect.bottom=y+height;

	FillRect(window_dc,&rect,brush);
	FillRect(bitmap_dc,&rect,brush);

	DeleteObject(brush);
}

void view_draw_char(int x,int y,int mbchar,int color)
{
	char buf[2];
	int buflen;
	HFONT old_font;

	buflen=0;
	if(mbchar&0xff00) buf[buflen++]=(mbchar>>8)&0xff;
	buf[buflen++]=mbchar&0xff;

	old_font=SelectObject(window_dc,font);
	SetTextColor(window_dc,wcolor(color));
	TextOut(window_dc,x,y,buf,buflen);
	SelectObject(window_dc,old_font);

	old_font=SelectObject(bitmap_dc,font);
	SetTextColor(bitmap_dc,wcolor(color));
	TextOut(bitmap_dc,x,y,buf,buflen);
	SelectObject(bitmap_dc,old_font);
}

void view_draw_line(int x0,int y0,int x1,int y1,int color)
{
	HPEN old_pen,pen;

	pen=CreatePen(PS_SOLID,0,wcolor(color));
	old_pen=SelectObject(window_dc,pen);
	MoveToEx(window_dc,x0,y0,NULL);
	LineTo(window_dc,x1,y1);
	SelectObject(window_dc,old_pen);

	old_pen=SelectObject(bitmap_dc,pen);
	MoveToEx(bitmap_dc,x0,y0,NULL);
	LineTo(bitmap_dc,x1,y1);
	SelectObject(bitmap_dc,old_pen);

	DeleteObject(pen);
}

void view_put_true_color_image(int x0,int y0,char *rgb,int w,int h)
{
	BITMAPINFO bi;
	char *bits,*p,*q;
	int slice_len,x,y;
	
	bi.bmiHeader.biSize=sizeof(BITMAPINFOHEADER);
	bi.bmiHeader.biWidth=w;
	bi.bmiHeader.biHeight=h;
	bi.bmiHeader.biPlanes=1;
	bi.bmiHeader.biBitCount=24;
	bi.bmiHeader.biCompression=BI_RGB;
	bi.bmiHeader.biSizeImage=0;
	bi.bmiHeader.biXPelsPerMeter=0;
	bi.bmiHeader.biYPelsPerMeter=0;
	bi.bmiHeader.biClrUsed=0;
	bi.bmiHeader.biClrImportant=0;

	slice_len=w*3;
	if(slice_len%4!=0) slice_len+=(4-slice_len%4);
	bits=xmalloc(slice_len*h);
	
	for(y=0;y<h;y++) {
		for(x=0;x<w;x++) {
			p=rgb+(y*w+x)*3;
			q=bits+(h-1-y)*slice_len+x*3;
			q[0]=p[2];
			q[1]=p[1];
			q[2]=p[0];
		}		
	}
	
	StretchDIBits(window_dc,x0,y0,w,h,0,0,w,h,bits,&bi,DIB_RGB_COLORS,SRCCOPY);
	StretchDIBits(bitmap_dc,x0,y0,w,h,0,0,w,h,bits,&bi,DIB_RGB_COLORS,SRCCOPY);

	xfree(bits);
}

void view_copy_area(int fx,int fy,int w,int h,int tx,int ty)
{
	BitBlt(window_dc,tx,ty,tx+w,ty+h,window_dc,fx,fy,SRCCOPY);
	BitBlt(bitmap_dc,tx,ty,tx+w,ty+h,window_dc,fx,fy,SRCCOPY);
}

/** keyboard */

int view_get(void)
{
	int result;
	WaitForSingleObject(key_sem,INFINITE);
	EnterCriticalSection(&key_cs);
	result=cqueue_get(&key_queue);
	LeaveCriticalSection(&key_cs);
	return result;
}

int view_hit_p(void)
{
	return !cqueue_empty_p(&key_queue);
}

