/*
	primlist.
	$Id: primlist.c 3673 2014-10-24 23:26:22Z kt $
*/

#include "std.h"
#include <string.h>
#include "xbarray.h"

int main(int argc,char *argv[])
{
	int i;
	FILE *fp;
	struct xbarray buf;
	char *s;

	xbarray_init(&buf);
	for(i=1;i<argc;i++) {
		if((fp=fopen(argv[i],"r"))==NULL) xerror("open %s failed.",argv[i]);
		while((s=xbarray_fgets(&buf,fp))!=NULL) {
			if(strlen(s)>4&&strncmp(s,"PRIM",4)==0) printf("%s\n",s);
		}
		fclose(fp);
	}
	return 0;
}
