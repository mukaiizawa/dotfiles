View.
$Id: view.m 6016 2017-01-08 03:03:16Z kt $

*View.class class.@
	Object addSubclass: #View.class instanceVars:
		"open? foreground background"
**primitives.
***View.class >> basicOpenWidth: w height: h
	$view_open
***View.class >> font: fontName
	$view_set_font
***View.class >> property: type put: value
	$view_set_property
***View.class >> property: type
	$view_get_property
***View.class >> basicClose
	$view_close
***View.class >> fillRectangleX: x Y: y width: width height: height color: color
	$view_fill_rectangle
***View.class >> drawX: x Y: y code: code color: color
	$view_draw_char
***View.class >> drawLineX: x0 Y: y0 X: x1 Y: y1 color: color
	$view_draw_line
***View.class >> putTrueColorImageX: x Y: y rgb: rgb width: w height: h
	$view_put_true_color_image
***View.class >> copyAreaX: fx Y: fy width: w height: h X: tx Y: ty
	$view_copy_area
***View.class >> get
	$view_get
***View.class >> hit?
	$view_hit_p

**colors.
***View.class >> colorRed: r green: g blue: b
	 r << 16 | (g << 8) | b!
***View.class >> colorWhite
	self colorRed: 255 green: 255 blue: 255!
***View.class >> colorBlack
	self colorRed: 0 green: 0 blue: 0!
***View.class >> colorRed
	self colorRed: 255 green: 0 blue: 0!
***View.class >> colorGreen
	self colorRed: 0 green: 255 blue: 0!
***View.class >> colorBlue
	self colorRed: 0 green: 0 blue: 255!
	
**View.class >> init
	false ->open?;
	self foreground: self colorBlack;
	self background: self colorWhite
**View.class >> serializeTo: writer
	open? ->:savedOpen?;
	false ->open?;
	super serializeTo: writer;
	savedOpen? ->open?
**View.class >> openWidth: w height: h
	open? ifTrue: [self!];
	self basicOpenWidth: w height: h;
	true ->open?
**View.class >> open
	self openWidth: 0 height: 0;
	self clear
**View.class >> close
	open? ifTrue:
		[self basicClose;
		false ->open?]
**View.class >> onQuit
	self close
**View.class >> moveX: x Y: y
	self property: 5 put: x;
	self property: 6 put: y
			
**View.class >> width
	self property: 1!
**View.class >> height
	self property: 2!
**View.class >> fontWidth
	self property: 3!
**View.class >> fontHeight
	self property: 4!

**Mulk.hostOS = #android >
***View.class >> keyboardColor: color alpha: alpha
	self property: 7 put: color + (alpha << 24)
***View.class >> keyboardX: x y: y width: w height: h
	self
		property: 10 put: x,
		property: 11 put: y,
		property: 8 put: w,
		property: 9 put: h
		
**View.class >> foreground: color
	color ->foreground
**View.class >> background: color
	color ->background
**View.class >> foreground
	foreground!
**View.class >> background
	background!
**View.class >> drawX: x Y: y char: char color: color
	char code ->:code;
	--some X fonts has no Full width tilda (U+FF5E), use Wave dash (U+301C).
	Mulk.charset = #utf8 ifTrue:
		[code = 0xefbd9e ifTrue: [0xe3809c ->code]];
	self drawX: x Y: y code: code color: color
**View.class >> drawX: x Y: y char: char
	self drawX: x Y: y char: char color: foreground
**View.class >> fillRectangleX: x Y: y width: w height: h
	self fillRectangleX: x Y: y width: w height: h color: foreground
**View.class >> clearRectangleX: x Y: y width: w height: h
	self fillRectangleX: x Y: y width: w height: h color: background
**View.class >> clear
	self clearRectangleX: 0 Y: 0 width: self width height: self height
**View.class >> drawLineX: x0 Y: y0 X: x1 Y: y1
	self drawLineX: x0 Y: y0 X: x1 Y: y1 color: foreground
	
**image support.
***View.Image class.@
	Object addSubclass: #View.Image instanceVars: "width height buffer"
****View.Image >> initWidth: widthArg height: heightArg buffer: bufferArg
	widthArg ->width;
	heightArg ->height;
	bufferArg ->buffer
****View.Image >> width
	width!
****View.Image >> height
	height!
****View.Image >> buffer
	buffer!

***View.class >> putImage: image X: x Y: y
	self putTrueColorImageX: x Y: y rgb: image buffer
		width: image width height: image height
***View.class >> putImage: image
	self putImage: image X: 0 Y: 0

**View.class >> drawX: x Y: y string: string
	self fontWidth ->:w;
	StringReader new init: string ->:r;
	[r getWideChar ->:ch, notNil?] whileTrue:
		[self drawX: x Y: y char: ch;
		x + (ch width * w) ->x]
*@
	View.class new ->:v;
	Mulk at: #View put: v;
	Mulk.quitHook addLast: v
