/*
	dynamic library.
	$Id: dl.c 5630 2016-08-29 12:12:17Z kt $
*/

#include "std.h"

/* note: handle and symbol must be intptr_t compatible */

#if UNIX_P
#include <dlfcn.h>
#define DLOPEN(n) ((intptr_t)dlopen(n,RTLD_LAZY))
#define DLSYM(h,n) ((intptr_t)dlsym((void*)h,n))
#endif

#if WINDOWS_P
#include <windows.h>
#define DLOPEN(n) ((intptr_t)LoadLibrary(n))
#define DLSYM(h,n) ((intptr_t)GetProcAddress((HMODULE)h,n))
#endif

#include "mem.h"
#include "om.h"
#include "prim.h"
#include "dl.h"

PRIM(dl_open)
{
	char *n;
	intptr_t h;

	if((n=p_string_val(args[0]))==NULL) return FALSE;
	if((h=DLOPEN(n))==0) return FALSE;
	*result=p_intptr(h);
	return TRUE;
}

PRIM(dl_sym)
{
	intptr_t h,sym;
	char *n;

	if(!p_intptr_val(args[0],&h)) return FALSE;
	if((n=p_string_val(args[1]))==NULL) return FALSE;
	if((sym=DLSYM(h,n))==0) return FALSE;	
	*result=p_intptr(sym);
	return TRUE;
}

#define MAX_ARGS 14

PRIM(dl_call)
{
	intptr_t func;
	int type,i,cargc,cret_p;
	object fargs; /* FixedArray */
	intptr_t cargs[MAX_ARGS],cret;
	double cretd;

	if(!p_intptr_val(args[0],&func)) return FALSE;
	GET_SINT_ARG(1,type);
	fargs=args[2];

	cargc=type%100;
	cret_p=TRUE;
	cret=0;
	cretd=0;
	if(cargc==20) { /* double f(double) */
		cargc=0;
		cret_p=FALSE;
	} else if(cargc==21) { /* intptr f(intptr,intptr,double) */ 
		cargc=2;
	} else if(cargc==22) { /* double f(intptr,intptr) */
		cargc=2;
		cret_p=FALSE;
	}

	for(i=0;i<cargc;i++) {
		if(!p_intptr_val(fargs->farray.elt[i],&cargs[i])) return FALSE;
	}

#define A(i) (cargs[i])
	switch(type) {
#define F (*((intptr_t (*)())func))
	case 0: cret=F(); break;
	case 1: cret=F(A(0)); break;
	case 2: cret=F(A(0),A(1)); break;
	case 3: cret=F(A(0),A(1),A(2)); break;
	case 4: cret=F(A(0),A(1),A(2),A(3)); break;
	case 5: cret=F(A(0),A(1),A(2),A(3),A(4)); break;
	case 6: cret=F(A(0),A(1),A(2),A(3),A(4),A(5)); break;
	case 7: cret=F(A(0),A(1),A(2),A(3),A(4),A(5),A(6)); break;
	case 8: cret=F(A(0),A(1),A(2),A(3),A(4),A(5),A(6),A(7)); break;
	case 9: cret=F(A(0),A(1),A(2),A(3),A(4),A(5),A(6),A(7),A(8)); break;
	case 10: cret=F(A(0),A(1),A(2),A(3),A(4),A(5),A(6),A(7),A(8),A(9)); break;
	case 11:
		cret=F(A(0),A(1),A(2),A(3),A(4),A(5),A(6),A(7),A(8),A(9),A(10));
		break;
	case 12:
		cret=F(A(0),A(1),A(2),A(3),A(4),A(5),A(6),A(7),A(8),A(9),A(10),A(11));
		break;
	case 13:
		cret=F(A(0),A(1),A(2),A(3),A(4),A(5),A(6),A(7),A(8),A(9),A(10),A(11),
			A(12));
		break;
	case 14:
		cret=F(A(0),A(1),A(2),A(3),A(4),A(5),A(6),A(7),A(8),A(9),A(10),A(11),
			A(12),A(13));
		break;
	case 20:
		{
			double farg;
			if(!p_float_val(fargs->farray.elt[0],&farg)) return FALSE;
			cretd=(*((double (*)(double))func))(farg);
		}
		break;
	case 21:
		{
			double farg;
			if(!p_float_val(fargs->farray.elt[2],&farg)) return FALSE;
			cret=(*((intptr_t (*)(intptr_t,intptr_t,double))func))
				(A(0),A(1),farg);
		}
		break;
	case 22:
		{
			cretd=(*((double (*)(intptr_t,intptr_t))func))(A(0),A(1));
		}
		break;
#undef F
#if WINDOWS_P
#define F (*((intptr_t (__stdcall *)())func))
	case 100: cret=F(); break;
	case 101: cret=F(A(0)); break;
	case 102: cret=F(A(0),A(1)); break;
	case 103: cret=F(A(0),A(1),A(2)); break;
	case 104: cret=F(A(0),A(1),A(2),A(3)); break;
	case 105: cret=F(A(0),A(1),A(2),A(3),A(4)); break;
	case 106: cret=F(A(0),A(1),A(2),A(3),A(4),A(5)); break;
	case 107: cret=F(A(0),A(1),A(2),A(3),A(4),A(5),A(6)); break;
	case 108: cret=F(A(0),A(1),A(2),A(3),A(4),A(5),A(6),A(7)); break;
	case 109: cret=F(A(0),A(1),A(2),A(3),A(4),A(5),A(6),A(7),A(8)); break;
	case 110: cret=F(A(0),A(1),A(2),A(3),A(4),A(5),A(6),A(7),A(8),A(9)); break;
	case 111:
		cret=F(A(0),A(1),A(2),A(3),A(4),A(5),A(6),A(7),A(8),A(9),A(10));
		break;
	case 112:
		cret=F(A(0),A(1),A(2),A(3),A(4),A(5),A(6),A(7),A(8),A(9),A(10),A(11));
		break;
	case 113:
		cret=F(A(0),A(1),A(2),A(3),A(4),A(5),A(6),A(7),A(8),A(9),A(10),A(11),
			A(12));
		break;
	case 114:
		cret=F(A(0),A(1),A(2),A(3),A(4),A(5),A(6),A(7),A(8),A(9),A(10),A(11),
			A(12),A(13));
		break;
#undef F
#endif

	default:
		return FALSE;
	}

	if(cret_p) *result=p_intptr(cret);
	else *result=p_float(cretd);
	return TRUE;
}

/* utility */

PRIM(dl_load_byte)
{
	intptr_t addr;
	if(!p_intptr_val(args[0],&addr)) return FALSE;
	*result=sint(LC(addr));
	return TRUE;
}

/* FixedByteArray >> address */
PRIM(dl_address)
{
	*result=p_intptr((intptr_t)self->fbarray.elt);
	return TRUE;	
}
