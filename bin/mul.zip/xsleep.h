/*
	sleep in seconds.
	$Id: xsleep.h 1333 2012-04-01 06:06:34Z kt $
*/

extern void xsleep(double t);
