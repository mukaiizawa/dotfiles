View�ŃO���t�쐬
$Id: graphv.m 4385 2015-05-11 11:45:12Z kt $

*[man]
.caption ����
	graphv
.caption ����
�W�����͂���csv�`���̍��W���ǂݍ��݁AView��ɃO���t��\������B

*import.@
	Mulk import: #("graphimp" "view")

*Cmd.graphv class.@
	Graph addSubclass: #Cmd.graphv
**Cmd.graphv >> main: args
	self read;

	View open clear;
	View fontHeight ->:fh;
	View drawX: 0 Y: fh string: "  x: " + xmin + " - " + xmax;
	View drawX: 0 Y: fh * 2 string: "  y: " + ymin + " - " + ymax;

	View width - 1 ->planeWidth;
	View height - 1 ->planeHeight;

	0 between: xmin and: xmax, ifTrue:
		[self convertX: 0 ->:x0;
		View drawLineX: x0 Y: 0 X: x0 Y: View height];
	0 between: ymin and: ymax, ifTrue:
		[self convertY: 0 ->:y0;
		View drawLineX: 0 Y: y0 X: View width Y: y0];
		
	nil ->:prevPt;
	data do:
		[:pt
		(self convertX: pt x) @ (self convertY: pt y) ->pt;
		prevPt notNil? ifTrue:
			[View drawLineX: prevPt x Y: prevPt y X: pt x Y: pt y];
		pt ->prevPt]
