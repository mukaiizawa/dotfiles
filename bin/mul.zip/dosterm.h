/*
	dos terminal interrupt i/f.
	$Id: dosterm.h 2893 2014-01-06 12:23:48Z kt $
*/

extern void dosterm_init(void);
extern void dosterm_check(void);
