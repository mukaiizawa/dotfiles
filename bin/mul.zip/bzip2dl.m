Bzip2.dl class.
$Id: bzip2dl.m 5834 2016-11-19 23:41:17Z kt $

*[man]
.caption ����
libbz2���L���C�u������p����bzip2�t�@�C���̈��k�E�L���B

*Bzip2.dl class.@
	Mulk import: "dl";
	Object addSubclass: #Bzip2.dl instanceVars: "bufSize buf bzfp"

**libbz2 i/f.@
	"libbz2.so.1" ->:lib; -- linux.
	Mulk.hostOS ->:os, = #windows ifTrue: ["libbz2" ->lib];
	os = #macosx ifTrue: ["libbz2.dylib" ->lib];
	os = #cygwin ifTrue: ["cygbz2-1.dll" ->lib];
	os = #freebsd ifTrue: ["libbz2.so" ->lib];
	os = #windows
		ifTrue:
			[#(#BZ2_bzopen 102 #BZ2_bzread 103 #BZ2_bzwrite 103 #BZ2_bzflush 101
				#BZ2_bzclose 101)]
		ifFalse:
			[#(#BZ2_bzopen 2 #BZ2_bzread 3 #BZ2_bzwrite 3 #BZ2_bzflush 1
				#BZ2_bzclose 1)]
		->:procs;
	DL import: lib procs: procs

**Bzip2.dl >> init
	4096 ->bufSize;
	FixedByteArray basicNew: bufSize ->buf
**Bzip2.dl >> open: file mode: mode
	DL call: #BZ2_bzopen with: file path with: mode ->bzfp;
	self assert: bzfp <> 0
**Bzip2.dl >> write: len
	DL call: #BZ2_bzwrite with: bzfp with: buf with: len!
**Bzip2.dl >> read: len
	DL call: #BZ2_bzread with: bzfp with: buf with: len!
**Bzip2.dl >> close
	DL call: #BZ2_bzflush with: bzfp;
	DL call: #BZ2_bzclose with: bzfp

**Bzip2.dl >> compress: bz2 from: file
	self open: bz2 mode: "wb";
	file readDo:
		[:str
		[str read: buf size: bufSize ->:size, <> 0]
			whileTrue: [self write: size]];
	self close
**Bzip2.dl >> decompress: bz2 to: file
	self open: bz2 mode: "rb";
	file writeDo:
		[:str
		[self read: bufSize ->:size, <> 0]
			whileTrue: [str write: buf size: size]];
	self close
