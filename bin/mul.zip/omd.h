/*
	object memory describe.
	$Id: omd.h 442 2011-01-09 00:21:34Z kt $
*/

extern char *om_describe(char *buf,object o);
extern void om_log_symbol(object o);
