/*
	FixedByteArray class.
	$Id: fbarray.c 5686 2016-09-18 08:36:33Z kt $
*/

#include "std.h"
#include <string.h>

#include "om.h"
#include "prim.h"

PRIM(fbarray_bytesHash)
{
	*result=sint(om_bytes_hash(self->fbarray.elt,self->fbarray.size));
	return TRUE;	
}

PRIM(fbarray_copy)
{
	int tp,fp,s,fsize;
	object from;

	GET_SINT_ARG(0,tp);
	from=args[1];
	GET_SINT_ARG(2,fp);
	GET_SINT_ARG(3,s);

	if(!(0<=tp&&tp<=self->fbarray.size)) return FALSE;
	fsize=om_size(from);
	if(!(fsize==SIZE_FBARRAY||fsize==SIZE_STRING||fsize==SIZE_SYMBOL)) {
		return FALSE;
	}
	if(!(0<=fp&&fp<=from->fbarray.size)) return FALSE;
	if(s<0) return FALSE;
	if(!(tp+s<=self->fbarray.size)) return FALSE;
	if(!(fp+s<=from->fbarray.size)) return FALSE;

	memmove(self->fbarray.elt+tp,from->fbarray.elt+fp,s);
	return TRUE;
}

PRIM(fbarray_missmatchIndex)
{
	int fsize,i,ep;
	object fba;
	
	fba=args[0];
	GET_SINT_ARG(1,ep);
	
	fsize=om_size(fba);
	if(!(fsize==SIZE_FBARRAY||fsize==SIZE_STRING||fsize==SIZE_SYMBOL)) {
		return FALSE;
	}

	if(ep==-1||ep>self->fbarray.size) ep=self->fbarray.size;
	if(ep>fba->fbarray.size) ep=fba->fbarray.size;

	for(i=0;i<ep;i++) {
		if(self->fbarray.elt[i]!=fba->fbarray.elt[i]) break;
	}
	if(i==ep) *result=om_nil;
	else *result=sint(i);
	return TRUE;
}
