�O���t�쐬
$Id: graph.m 5877 2016-11-27 09:38:51Z kt $

*[man]
.caption ����
	graph
.caption ����
�W�����͂���csv�`���̍��W���ǂݍ��݁A�e�L�X�g�`���ŃO���t��\������B

*import.@
	Mulk import: #("graphimp" "matrix" "console")

*Cmd.graph class.@
	Graph addSubclass: #Cmd.graph instanceVars: "plane"
**Cmd.graph >> drawAxis
	0 between: xmin and: xmax, ifTrue:
		[self convertX: 0 ->:x0;
		0 until: plane height, do: [:yi plane at: x0 @ yi put: '|']];
	0 between: ymin and: ymax, ifTrue:
		[self convertY: 0 ->:y0;
		0 until: plane width, do: [:xi plane at: xi @ y0 put: '-']];
	x0 notNil? & y0 notNil? ifTrue: [plane at: x0 @ y0 put: '+']
**Cmd.graph >> makePlane
	Matrix new init: (Console width - 1) @ (Console height - 3) ->plane;
	plane width - 1 ->planeWidth;
	plane height - 1 ->planeHeight;
	plane fill: ' ';
	self drawAxis;
	data do:
		[:pt plane at: (self convertX: pt x) @ (self convertY: pt y) put: 'x']
**Cmd.graph >> main: args
	self read;
	self makePlane;
	plane subscriptsAndValuesDo:
		[:pos :value
		Out put: value;
		pos x = planeWidth ifTrue: [Out putLn]];
	Out putLn: "x: " + xmin + " - " + xmax;
	Out putLn: "y: " + ymin + " - " + ymax
