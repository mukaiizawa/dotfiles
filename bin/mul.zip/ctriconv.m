iconv�p�����R�[�h�ϊ���
$Id: ctriconv.m 5955 2016-12-23 01:25:10Z kt $

*[man]
.caption ����
iconv�ɂ��CodeTranslator�N���X�B

CodeTranslatorFactory���ԐړI�ɍ\�z�����̂ŁA���ڎg�p����K�v�͂Ȃ��B
.caption �֘A����
.overview ctrlib

*CodeTranslator.iconv class.@
	Mulk import: "dl";
	CodeTranslator addSubclass: #CodeTranslator.iconv instanceVars:
		"open conv close ic bufAddr bufSizeAddr resultAddr resultSizeAddr"
**CodeTranslator.iconv >> init
	super init;
	DL.IntPtrBuffer new ->bufAddr;
	DL.IntPtrBuffer new ->bufSizeAddr;
	DL.IntPtrBuffer new ->resultAddr;
	DL.IntPtrBuffer new ->resultSizeAddr;
	Mulk.hostOS ->:os, = #cygwin
		ifTrue: [#(#libiconv_open 2 #libiconv 5 #libiconv_close 1)]
		ifFalse: [#(#iconv_open 2 #iconv 5 #iconv_close 1)] ->:procs;
	procs first ->open;
	procs at: 2 ->conv;
	procs at: 4 ->close;
	"" ->:libName; -- linux
	os = #cygwin ifTrue: ["cygiconv-2.dll" ->libName];
	os = #macosx ifTrue: ["libiconv.dylib" ->libName];
	os = #freebsd ifTrue: ["libiconv.so" ->libName];
	DL import: libName procs: procs
**CodeTranslator.iconv >> codeString: ch
	ch = 'u' ifTrue: ["UTF-8"!];
	ch = 's' ifTrue: ["CP932"!];
	ch = 'e' ifTrue: ["EUC-JP"!];
	self error: "illegal code char " + ch
**CodeTranslator.iconv >> init: fromTo
	DL call: open with: (self codeString: (fromTo at: 1))
		with: (self codeString: fromTo first) ->ic
**CodeTranslator.iconv >> translate: buf size: bufSize
	self reserve: bufSize;
	bufAddr value: buf address;
	bufSizeAddr value: bufSize;
	resultAddr value: resultBuf address;
	resultSizeAddr value: resultBuf size;
	DL call: conv with: ic
		with: bufAddr with: bufSizeAddr with: resultAddr with: resultSizeAddr,
			= -1 ifTrue:
		[self error: "iconv failed."];
	resultBuf size - resultSizeAddr value!
**CodeTranslator.iconv >> finish
	DL call: close with: ic
