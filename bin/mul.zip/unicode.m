unicode/utf8 conversion.
$Id: unicode.m 3511 2014-08-28 12:50:05Z kt $

*[man]
.caption ����
unicode/utf8�Ԃ̕ϊ����s���B

*Integer >> unicodeToUtf8
	self <= 0x7f ifTrue: [self!];
	self <= 0x7ff ifTrue:
		[0xc080 + (self & 0x7c0 << 2) + (self & 0x3f)!];
	self <= 0xffff ifTrue:
		[0xe08080 + (self & 0xf000 << 4) + (self & 0xfc0 << 2)
			+ (self & 0x3f)!];
	self assertFailed
**[man.m]
unicode��utf8

*Integer >> utf8ToUnicode
	self <= 0xff ifTrue: [self!];
	self <= 0xffff ifTrue: [(self & 0x1f00 >> 2) + (self & 0x3f)!];
	self <= 0xffffff ifTrue:
		[(self & 0xf0000 >> 4) + (self & 0x3f00 >> 2) + (self & 0x3f)!];
	self assertFailed
**[man.m]
utf8��unicode
