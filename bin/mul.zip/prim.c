/*
	primitive support.
	$Id: prim.c 3667 2014-10-19 03:26:39Z kt $
*/

#include "std.h"

#include <limits.h>
#include <string.h>

#include "mem.h"

#include "om.h"
#include "gc.h"
#include "prim.h"

static struct xbarray buf={NULL,0,0};

#define MAX_STRINGS 10

int p_strings_val(int n,object *os,char **ss)
{
	int pos[MAX_STRINGS],i;
	object o;
	
	if(n>=MAX_STRINGS) return FALSE;
	xbarray_reset(&buf);
	for(i=0;i<n;i++) {
		pos[i]=buf.size;
		o=os[i];
		if(om_class(o)!=om_String) return FALSE;
		memcpy(xbarray_reserve(&buf,o->fbarray.size),o->fbarray.elt,
			o->fbarray.size);
		xbarray_add(&buf,'\0');
	}
	for(i=0;i<n;i++) ss[i]=buf.elt+pos[i];
	return TRUE;
}

char *p_string_val(object o)
{
	char *result;
	if(!p_strings_val(1,&o,&result)) return NULL;
	return result;
}

object p_string_xbarray(struct xbarray *x)
{
	object result;
	result=gc_object_new(om_String,x->size);
	memcpy(result->fbarray.elt,x->elt,x->size);
	om_set_string_hash(result);
	return result;
}

int p_byte_p(int b)
{
	return 0<=b&&b<256;
}

int p_farray_to_array(object fa,int *size,object **array)
{
	if(fa==om_nil) {
		*size=0;
		*array=NULL;
	} else if(om_class(fa)==om_FixedArray) {
		*size=fa->farray.size;
		*array=fa->farray.elt;
	} else return FALSE;

	return TRUE;
}

object p_lint(int64_t val)
{
	object result;
	result=gc_object_new(om_LongInteger,0);
	result->lint.val=val;
	om_set_hash(result,om_number_hash((double)val));
	return result;	
}

object p_int64(int64_t val)
{
	if(SINT_MIN<=val&&val<=SINT_MAX) return sint((int)val);
	return p_lint(val);
}

int p_int64_val(object o,int64_t *valp)
{
	if(sint_p(o)) *valp=sint_val(o);
	else if(om_class(o)==om_LongInteger) *valp=o->lint.val;
	else return FALSE;
	return TRUE;
}

object p_intptr(intptr_t val)
{
	return p_int64(val);
}

int p_intptr_val(object o,intptr_t *valp)
{
	int64_t i64;
	if(!p_int64_val(o,&i64)) return FALSE;
	if(!(INTPTR_MIN<=i64&&i64<=INTPTR_MAX)) return FALSE;
	*valp=(intptr_t)i64;
	return TRUE;
}

object p_float(double val)
{
	object o;
	o=gc_object_new(om_Float,0);
	o->xfloat.val=val;
	om_set_hash(o,om_number_hash(val));
	return o;
}

int p_float_val(object o,double *valp)
{
	int64_t i;
	if(p_int64_val(o,&i)) *valp=(double)i;
	else if(om_class(o)==om_Float) *valp=o->xfloat.val;
	else return FALSE;
	return TRUE;
}
