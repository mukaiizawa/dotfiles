lisp.
$Id: lisp.m 6318 2017-05-27 21:12:16Z kt $

*Lisp.Cons class.@
	Cons addSubclass: #Lisp.Cons
**Lisp.Cons >> mapcar: block
	Lisp.Cons new
		car: (block value: car),
		cdr: (cdr nil? ifTrue: [nil] ifFalse: [cdr mapcar: block])!

*Lisp.Reader class.@
	AheadReader addSubclass: #Lisp.Reader instanceVars:
		"token atom ungetToken"
**Lisp.Reader >> atomChar?
	nextChar nil?
		or: [nextChar space?],
		or: ["()';" includes?: nextChar],
		not!
**Lisp.Reader >> convertNumber
	token first digit?
		or: [token size >= 2
			and: [token first = '-'], and: [token at: 1, digit?]],
		ifFalse: [false!];
	AheadReader new init: token ->:r;
	r skipNumber ->atom;
	r nextChar nil?!
**Lisp.Reader >> convertAtom
	token = "nil" ifTrue: [nil ->atom!];
	self convertNumber ifTrue: [self!];
	token asSymbol ->atom
**Lisp.Reader >> getToken
	ungetToken notNil? ifTrue:
		[ungetToken ->:result;
		nil ->ungetToken;
		result!];

	self skipSpace;

	nextChar = ';' ifTrue:
		[[nextChar <> '\n'] whileTrue: [self skipChar];
		self getToken!];

	nextChar nil? ifTrue:
		[#*eof* ->atom;
		#atom!];
		
	"()'" includes?: nextChar, ifTrue: [self skipChar!];

	self resetToken;
	[self atomChar?] whileTrue: [self getChar];
	self token ->token;
	token = "." ifTrue: ['.'!];
	self convertAtom;
	#atom!
**Lisp.Reader >> ungetToken: tk
	self assert: ungetToken nil?;
	tk ->ungetToken
**Lisp.Reader >> getCloseParen
	self getToken <> ')' ifTrue: [self error: "missing ) "]
**Lisp.Reader >> readCdr
	self getToken ->:tk, = ')' ifTrue:
		[self ungetToken: tk;
		nil!];
	tk = '.' ifTrue: [self read!];
	self ungetToken: tk;
	Lisp.Cons new car: self read, cdr: self readCdr!
**Lisp.Reader >> read
	self getToken ->:tk, = #atom ifTrue: [atom!];
	tk = '\'' ifTrue:
		[Lisp.Cons new car: #quote, cdr: (Lisp.Cons new car: self read)!];
	tk = '(' ifTrue:
		[self getToken ->tk, = ')' ifTrue: [nil!];
		self ungetToken: tk;
		Lisp.Cons new car: self read, cdr: self readCdr ->:result;
		self getCloseParen;
		result!];
	self error: "illegal token: " + tk
		
*Lisp.Writer class.@
	Object addSubclass: #Lisp.Writer instanceVars: "writer"
**Lisp.Writer >> initWriter: writerArg
	writerArg ->writer
**Lisp.Writer >> write: c
	c memberOf?: Symbol, ifTrue: [writer put: c!];

	c memberOf?: Lisp.Cons, ifTrue:
		[writer put: '(';
		self write: c car;
		c cdr ->c;
		[c memberOf?: Lisp.Cons] whileTrue:
			[writer put: ' ';
			self write: c car;
			c cdr ->c];
		c notNil? ifTrue:
			[writer put: " . ";
			self write: c];
		writer put: ')'!];

	--nil or others.
	writer put: c
	
*Lisp.Evaluator class.@
	Object addSubclass: #Lisp.Evaluator instanceVars:
		"lisp bindingStack iArgs"
**Lisp.Evaluator >> init: lispArg
	lispArg ->lisp;
	Array new ->bindingStack
**Lisp.Evaluator >> bindingStackPos: sym
	bindingStack size - 2 ->:i;
	[bindingStack at: i ->:v, nil?] whileFalse:
		[v = sym ifTrue: [i + 1!];
		i - 2 ->i];
	nil!
**Lisp.Evaluator >> symbolValue: sym
	self bindingStackPos: sym ->:pos, nil?
		ifTrue: [lisp symbolValue: sym]
		ifFalse: [bindingStack at: pos]!
**Lisp.Evaluator >> symbolValue: sym set: value
	self bindingStackPos: sym ->:pos, nil?
		ifTrue: [lisp symbolValue: sym set: value]
		ifFalse: [bindingStack at: pos put: value];
	value!
**Lisp.Evaluator >> evalList: sexps
	sexps nil? ifFalse:
		[sexps do:
			[:sexp
			self eval: sexp ->:result]];
	result!
**Lisp.Evaluator >> apply: sexp args: args
	sexp car ->:ftype, = #builtin ifTrue:
		[args -> iArgs;
		self perform: sexp cdar!];

	self assert: ftype = #lambda;
	bindingStack size ->:savedSize;
	bindingStack addLast: nil, addLast: nil;
	sexp cdar ->:pargs, memberOf?: Lisp.Cons,
		ifTrue:
			[pargs do:
				[:pa
				bindingStack addLast: pa, addLast: args car;
				args cdr ->args]]
		ifFalse: [bindingStack addLast: pargs, addLast: args];
	self evalList: sexp cddr ->:result;
	bindingStack size: savedSize;
	result!
**Lisp.Evaluator >> eval: sexp
	sexp memberOf?: Symbol, ifTrue:
		[sexp = #t
			ifTrue: [sexp]
			ifFalse: [self symbolValue: sexp]!];

	sexp memberOf?: Lisp.Cons, ifTrue:
		[sexp car ->:f;
		f memberOf?: Symbol, ifTrue: [lisp symbolValue: f ->f];
		f car ->:ftype, = #builtin or: [ftype = #lambda], ifTrue:
			[sexp cdr ->:args, notNil? ifTrue:
				[args mapcar: [:a self eval: a] ->args];
			self apply: f args: args!];
		ftype = #special ifTrue:
			[sexp cdr ->iArgs;
			self perform: f cdar!];
		ftype = #macro ifTrue:
			[self apply: f cdar args: sexp cdr ->sexp;
			self eval: sexp!];
		self error: "eval failed " + sexp];

	sexp!
**Lisp.Evaluator >> evalStart: sexp
	bindingStack size: 0;
	bindingStack addLast: nil, addLast: nil;
	self eval: sexp!
	
**special.
***Lisp.Evaluator >> s_quote
	iArgs car!
***Lisp.Evaluator >> s_if
	iArgs ->:args;
	self eval: args car, notNil?
		ifTrue: [self eval: args cdar]
		ifFalse: [self evalList: args cddr]!
***Lisp.Evaluator >> s_progn
	self evalList: iArgs!
***Lisp.Evaluator >> s_let_star
	iArgs ->:args;
	args car do:
		[:v
		nil ->:value;
		v memberOf?: Lisp.Cons,
			ifTrue:
				[v car ->:sym;
				self evalList: v cdr ->value]
			ifFalse: [v ->sym];
		bindingStack addLast: sym, addLast: value];
	self evalList: args cdr!
***Lisp.Evaluator >> s_while
	iArgs ->:args;
	[self eval: args car, notNil?] whileTrue: [self evalList: args cdr];
	nil!

**builtin.
***Lisp.Evaluator >> b_car
	iArgs car car!
***Lisp.Evaluator >> b_cdr
	iArgs car cdr!
***Lisp.Evaluator >> b_cons
	Lisp.Cons new car: iArgs car, cdr: iArgs cdar!
***Lisp.Evaluator >> b_atom
	iArgs car memberOf?: Lisp.Cons, ifTrue: [nil] ifFalse: [#t]!
***Lisp.Evaluator >> b_eq
	iArgs car == iArgs cdar ifTrue: [#t] ifFalse: [nil]!

***Lisp.Evaluator >> b_eval
	self eval: iArgs car!
***Lisp.Evaluator >> b_set
	self symbolValue: iArgs car set: iArgs cdar!
***Lisp.Evaluator >> b_mulk_perform
	Array new ->:args;
	iArgs cddr ->:argsList, notNil? ifTrue: [argsList do: [:a args addLast: a]];
	iArgs cdar perform: iArgs car args: args asFixedArray ->:result;
	result == true ifTrue: [#t!];
	result == false ifTrue: [nil!];
	result!
***Lisp.Evaluator >> b_print
	Lisp.Writer new initWriter: Out, write: iArgs car;
	Out putLn;
	iArgs car!
	
*Lisp class.@
	Object addSubclass: #Lisp instanceVars: "symbolValueMap"
**Lisp >> symbolValue: sym setString: string
	symbolValueMap at: sym put: (Lisp.Reader new init: string, read)
**Lisp >> init
	Dictionary new ->symbolValueMap;
	self symbolValue: #quote setString: "(special s_quote)";
	self symbolValue: #set setString: "(builtin b_set)"
**Lisp >> load: file
	Lisp.Evaluator new init: self ->:ev;
	file readDo:
		[:fs
		Lisp.Reader new initReader: fs ->:rd;
		[rd read ->:sexp, <> #*eof*] whileTrue: [ev evalStart: sexp]]
**Lisp >> symbolValue: sym
	symbolValueMap at: sym ifAbsent: [nil]!
**Lisp >> symbolValue: sym set: value
	symbolValueMap at: sym put: value

*lisp command.@
	Object addSubclass: #Cmd.lisp instanceVars: "lisp"
**Cmd.lisp >> repl
	Lisp.Evaluator new init: lisp ->:ev;
	"lisp>" ->:prompt;
	Out put: prompt;
	Lisp.Reader new initReader: In ->:rd;
	Lisp.Writer new initWriter: Out ->:wr;

	[rd read ->:sexp, <> #*eof*] whileTrue:
		[[
			wr write: (ev evalStart: sexp);
			Out putLn
		] on: Error do:
			[:e Out putLn: e message];
		Out put: prompt]
**Cmd.lisp >> main: args
	Lisp new init ->lisp;
	lisp load: Mulk.systemDirectory + "lisp.l";
	self repl
