/*
	preprocessor.
	$Id: pp.c 3512 2014-08-28 19:56:03Z kt $
*/

#include "std.h"

#include <ctype.h>
#include <string.h>

#include "mem.h"
#include "xbarray.h"
#include "splay.h"
#include "heap.h"

static struct splay splay;
static struct xbarray str;

static char *lex_ptr;
static char *lex(void)
{
	char *st;
	
	while(isspace(LC(lex_ptr))) lex_ptr++;
	if(*lex_ptr=='\0') return NULL;

	st=lex_ptr;
	while(*lex_ptr!='\0'&&!isspace(LC(lex_ptr))) lex_ptr++;
	if(*lex_ptr!='\0') *lex_ptr++='\0';
	return st;
}

static FILE *fp;

/*EOF*/
#define NONE 0
#define CMD_SET 1
#define CMD_IF 2
#define CMD_ELSEIF 3
#define CMD_ELSE 4
#define CMD_END 5
#define CMD_INCLUDE 6

static int get(void)
{
	char *s;
	s=xbarray_fgets(&str,fp);
	if(s==NULL) return EOF;
	else if(*s=='.') {
		lex_ptr=str.elt;
		s=lex();
		if(strcmp(s,".if")==0) return CMD_IF;
		else if(strcmp(s,".elseif")==0) return CMD_ELSEIF;
		else if(strcmp(s,".else")==0) return CMD_ELSE;
		else if(strcmp(s,".end")==0) return CMD_END;
		else if(strcmp(s,".set")==0) return CMD_SET;
		else if(strcmp(s,".include")==0) return CMD_INCLUDE;
	}
	return NONE;
}

static int skip_lines(void)
{
	int st;
	while(TRUE) {
		st=get();
		if(st==CMD_IF) while(skip_lines()!=CMD_END);
		else if(st==CMD_SET||st==CMD_INCLUDE||st==NONE);
		else if(st==EOF) xerror("skip_lines reached eof.");
		else break;
	}
	return st;
}

static int cond_p(void)
{
	char *name;
	int not_p;
	
	name=lex();
	if(name==NULL) xerror("illegal cond.");
	not_p=*name=='~';
	if(not_p) name++;
	return (splay_find(&splay,name)==NULL)==not_p;
}

static int do_lines(void);

static void cmd_if(void)
{
	int st,done;
	
	done=FALSE;
	if(cond_p()) {
		st=do_lines();
		done=TRUE;
	} else st=skip_lines();

	while(!done&&st==CMD_ELSEIF) {
		if(cond_p()) {
			st=do_lines();
			done=TRUE;
		} else st=skip_lines();
	}
		
	if(!done&&st==CMD_ELSE) {
		st=do_lines();
		done=TRUE;
	}

	while(st!=CMD_END) st=skip_lines();
}

static void set(char *name)
{
	name=heap_strdup(&heap_perm,name);
	if(splay_find(&splay,name)!=NULL) xerror("duplicate set %s",name);
	splay_add(&splay,name,name);
}

static void cmd_set(void)
{
	char *name;
	name=lex();
	if(name==NULL) xerror("illegal set.");
	set(name);
}

static void cmd_include(void)
{
	char *fn;
	FILE *saved_fp;
	
	fn=lex();
	if(fn==NULL) xerror("illegal include.");
	saved_fp=fp;
	if((fp=fopen(fn,"r"))==NULL) xerror("open %s failed.",fn);
	if(do_lines()!=EOF) xerror("illegal control.");
	fclose(fp);
	fp=saved_fp;
}	
	
static int do_lines(void)
{
	int st;
	while(TRUE) {
		st=get();
		if(st==CMD_IF) cmd_if();
		else if(st==CMD_SET) cmd_set();
		else if(st==CMD_INCLUDE) cmd_include();
		else if(st==NONE) printf("%s\n",str.elt);
		else break;
	}
	return st;
}

int main(int argc,char *argv[])
{
	int i;

	splay_init(&splay,(int(*)(void*,void*))strcmp);
	for(i=1;i<argc;i++) set(argv[i]);
	
	fp=stdin;
	if(do_lines()!=EOF) xerror("illegal control.");
	return 0;
}
