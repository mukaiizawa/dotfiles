/*
	xc getopt.
	$Id: xgetopt.h 3 2009-08-10 12:56:16Z kt $
*/

extern int xgetopt(int argc,char **argv,char *opt);
extern int xoptind;
extern char *xoptarg;
