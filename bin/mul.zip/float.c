/*
	Float class.
	$Id: float.c 6024 2017-01-14 10:34:11Z kt $
*/

#include "std.h"

#include <string.h>
#include <limits.h>
#include <math.h>

#ifdef __BORLANDC__
#include <float.h>
#define isfinite _finite
#endif

#ifndef isfinite
#define isfinite finite
#endif

#include "om.h"
#include "prim.h"

PRIM(float_equal)
{
	double y;
	if(!p_float_val(args[0],&y)) return FALSE;
	*result=om_boolean(self->xfloat.val==y);
	return TRUE;
}

PRIM(float_lt)
{
	double y;
	if(!p_float_val(args[0],&y)) return FALSE;
	*result=om_boolean(self->xfloat.val<y);
	return TRUE;
}

PRIM(float_add)
{
	double y;
	if(!p_float_val(args[0],&y)) return FALSE;
	y+=self->xfloat.val;
	if(!isfinite(y)) return FALSE;
	*result=p_float(y);
	return TRUE;
}

PRIM(float_multiply)
{
	double y;
	if(!p_float_val(args[0],&y)) return FALSE;
	y*=self->xfloat.val;
	if(!isfinite(y)) return FALSE;
	*result=p_float(y);
	return TRUE;
}

PRIM(float_divide)
{
	double y;
	if(!p_float_val(args[0],&y)) return FALSE;
	if(y==0) return FALSE;
	y=self->xfloat.val/y;
	if(!isfinite(y)) return FALSE;
	*result=p_float(y);
	return TRUE;
}

PRIM(float_asInteger)
{
	double x;
	x=self->xfloat.val;
	if(!(INT64_MIN<=x&&x<=INT64_MAX)) return FALSE;
	*result=p_int64((int64_t)x);
	return TRUE;
}
