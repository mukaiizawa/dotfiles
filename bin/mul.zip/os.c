/*
	OS class. - libc/posix wrapper.
	$Id: os.c 3788 2014-12-26 14:07:55Z kt $
*/

#include "std.h"

#include <time.h>
#include <string.h>
#include <errno.h>
#include <stdlib.h>

#include "pf.h"
#include "xsleep.h"

#include "om.h"
#include "gc.h"
#include "prim.h"

#if WINDOWS_P&&!defined(__BORLANDC__)
#define putenv _putenv
#endif

/* file stream */

PRIM(os_fp)
{
	FILE *fp;
	int fd;
	GET_SINT_ARG(0,fd);
	switch(fd) {
	case 0: fp=stdin; break;
	case 1: fp=stdout; break;
	case 2: fp=stderr; break;
	default: return FALSE;
	}
	*result=p_intptr((intptr_t)fp);
	return TRUE;
}

static char *mode_table[]={
	"rb",
	"wb",
	"ab",
	"rb+"
};

PRIM(os_fopen)
{
	char *fn;
	int mode;
	FILE *fp;
	
	if((fn=p_string_val(args[0]))==NULL) return FALSE;
	GET_SINT_ARG(1,mode);
	if(!(0<=mode&&mode<sizeof(mode_table)/sizeof(char*))) return FALSE;
	if((fp=fopen(fn,mode_table[mode]))==NULL) return FALSE;
	*result=p_intptr((intptr_t)fp);
	return TRUE;
}

PRIM(os_fgetc)
{
	int ch;
	FILE *fp;
	
	if(!p_intptr_val(args[0],(intptr_t*)&fp)) return FALSE;
	ch=fgetc(fp);
	if(ch==EOF&&ferror(fp)) {
		clearerr(fp);
		return FALSE;
	}
	*result=sint(ch);
	return TRUE;	
}

PRIM(os_fputc)
{
	int byte;
	FILE *fp;

	GET_SINT_ARG(0,byte);
	if(!p_byte_p(byte)) return FALSE;
	if(!p_intptr_val(args[1],(intptr_t*)&fp)) return FALSE;
	if(fputc(byte,fp)==EOF) return FALSE;
	return TRUE;
}

PRIM(os_fgets)
{
	FILE *fp;
	struct xbarray xba;
	char *s;

	if(!p_intptr_val(args[0],(intptr_t*)&fp)) return FALSE;	
	xbarray_init(&xba);
	s=xbarray_fgets(&xba,fp);
	if(s==NULL) *result=om_nil;
	else {
		xba.size--; /* remove last nul */
		*result=p_string_xbarray(&xba);
	}
	xbarray_free(&xba);
	return TRUE;
}

PRIM(os_fread)
{
	object ba;
	int from,size;
	FILE *fp;

	ba=args[0];
	if(om_class(ba)!=om_FixedByteArray) return FALSE;
	GET_SINT_ARG(1,from);
	GET_SINT_ARG(2,size);
	if(!(0<=from&&from+size<=ba->fbarray.size)) return FALSE;
	if(!p_intptr_val(args[3],(intptr_t*)&fp)) return FALSE;

	size=fread(ba->fbarray.elt+from,1,size,fp);
	if(size==0&&ferror(fp)) {
		clearerr(fp);
		return FALSE;
	}
	*result=sint(size);
	return TRUE;
}

PRIM(os_fwrite)
{
	object ba;
	int from,size;
	FILE *fp;

	ba=args[0];
	if(om_class(ba)!=om_FixedByteArray) return FALSE;
	GET_SINT_ARG(1,from);
	GET_SINT_ARG(2,size);
	if(!(0<=from&&from+size<=ba->fbarray.size)) return FALSE;
	if(!p_intptr_val(args[3],(intptr_t*)&fp)) return FALSE;
	
	size=fwrite(ba->fbarray.elt+from,1,size,fp);
	if(size==0&&ferror(fp)) {
		clearerr(fp);
		return FALSE;
	}
	*result=sint(size);
	return TRUE;
}

PRIM(os_fseek)
{
	int off;
	FILE *fp;

	if(!p_intptr_val(args[0],(intptr_t*)&fp)) return FALSE;
	GET_SINT_ARG(1,off);

	if(off==-1) return fseek(fp,0,SEEK_END)==0;
	else return fseek(fp,off,SEEK_SET)==0;
}

PRIM(os_ftell)
{
	int pos;
	FILE *fp;

	if(!p_intptr_val(args[0],(intptr_t*)&fp)) return FALSE;	
	if((pos=ftell(fp))==-1) return FALSE;
	if(!sint_range_p(pos)) return FALSE;
	*result=sint(pos);
	return TRUE;
}

PRIM(os_fclose)
{
	FILE *fp;

	if(!p_intptr_val(args[0],(intptr_t*)&fp)) return FALSE;
	fclose(fp);
	return TRUE;
}

/* file operations */

PRIM(os_stat)
{
	char *fn;
	struct pf_stat statbuf;
	int type;
	object so;
	
	if((fn=p_string_val(args[0]))==NULL) return FALSE;
	type=pf_stat(fn,&statbuf);

	if(type==PF_ERROR) return FALSE;

	if(type==PF_NONE) {
		*result=om_nil;
		return TRUE;
	}

	so=gc_object_new(om_FixedArray,3);
	so->farray.elt[0]=sint(type);
	so->farray.elt[1]=p_int64(statbuf.size);
	so->farray.elt[2]=p_int64(statbuf.mtime);
	*result=so;
	return TRUE;
}

PRIM(os_utime)
{
	char *fn;
	int64_t tv;
	
	if((fn=p_string_val(args[0]))==NULL) return FALSE;
	if(!p_int64_val(args[1],&tv)) return FALSE;

	return pf_utime(fn,tv);
}

PRIM(os_getcwd)
{
	char buf[MAX_STR_LEN];
	*result=gc_string(pf_getcwd(buf));
	return TRUE;
}

PRIM(os_chdir)
{
	char *fn;
	if((fn=p_string_val(args[0]))==NULL) return FALSE;
	return pf_chdir(fn);
}

PRIM(os_readdir)
{
	char *path;
	struct xbarray dirs;

	if((path=p_string_val(args[0]))==NULL) return FALSE;
	xbarray_init(&dirs);
	if(!pf_readdir(path,&dirs)) return FALSE;

	*result=p_string_xbarray(&dirs);
	xbarray_free(&dirs);
	return TRUE;
}

PRIM(os_remove)
{
	char *fn;
	if((fn=p_string_val(args[0]))==NULL) return FALSE;
	return pf_remove(fn);
}

PRIM(os_mkdir)
{
	char *path;
	if((path=p_string_val(args[0]))==NULL) return FALSE;
	return pf_mkdir(path);
}

/* time */

PRIM(os_time)
{
	*result=p_int64(time(NULL));
	return TRUE;
}

PRIM(os_clock)
{
	*result=p_float((double)clock()/CLOCKS_PER_SEC);
	return TRUE;
}

PRIM(os_sleep)
{
	double t;
	if(!p_float_val(args[0],&t)) return FALSE;
	xsleep(t);
	return TRUE;
}

/* system */

PRIM(os_system)
{
	char *s;
	if((s=p_string_val(args[0]))==NULL) return FALSE;
	*result=sint(system(s));
	return TRUE;
}

/* environ */

PRIM(os_getenv)
{
	char *s;
	if((s=p_string_val(args[0]))==NULL) return FALSE;
	if((s=getenv(s))==NULL) *result=om_nil;
	else *result=gc_string(s);
	return TRUE;
}

PRIM(os_putenv)
{
	char *s;
	if((s=p_string_val(args[0]))==NULL) return FALSE;
	return putenv(xstrdup(s))==0;
}
