/*
	terminal for dos.
	$Id: dosterm.c 6289 2017-05-20 07:00:25Z kt $
*/

#include "std.h"

#include <string.h>
#include <conio.h>
#if DOSTERM_BIOSKBD_P
#include <bios.h>
#endif

#include "dosterm.h"
#include "term.h"
#include "cqueue.h"

#include "om.h"
#include "ip.h"

static struct cqueue cq;

void dosterm_init(void)
{
	cqueue_reset(&cq);
}

#define CTRL_C 0x03
#define CTRL_BACKSLASH 0x1c

static int fetch(void)
{
	int ch;

#if DOSTERM_BIOSKBD_P
	ch=_bios_keybrd(_KEYBRD_READ)&0xff;
	if(ch==0) return -1;
#else
	ch=getch();
#endif
	if(ch==CTRL_C||ch==CTRL_BACKSLASH) {
		cqueue_reset(&cq);
		ip_trap_code=TRAP_INTERRUPT;
	}
	return ch;
}

void dosterm_check(void)
{
	int ch;
	while(TRUE) {
#if DOSTERM_BIOSKBD_P
		if(_bios_keybrd(_KEYBRD_READY)==0) break;
#else
		if(!kbhit()) break;
#endif
		ch=fetch();
		if(ch!=-1) cqueue_put(&cq,ch);
	}
}

/* term compatible layer */

void term_start(void)
{
	dosterm_init();
}

int term_set_property(int prop,int value)
{
	return FALSE;
}

int term_get_property(int prop,int *value)
{
	switch(prop) {
	case TERM_WIDTH:
		*value=80;
		break;
	case TERM_HEIGHT:
		*value=25;
		break;
	default:
		return FALSE;
	}
	return TRUE;
}

void term_finish(void)
{
}

int term_get(void)
{
	int ch;
	if(!cqueue_empty_p(&cq)) return cqueue_get(&cq);
	else {
		while((ch=fetch())==-1);
		return ch;
	}
}

void term_put(char *p,int size)
{
	fwrite(p,size,1,stdout);
}

int term_hit_p(void)
{
	dosterm_check();
	return !cqueue_empty_p(&cq);
}

static void xputs(char *s)
{
	term_put(s,strlen(s));
}

void term_goto_xy(int x,int y)
{
	char buf[MAX_STR_LEN];
	xsprintf(buf,"\x1b[%d;%dH",y+1,x+1);
	xputs(buf);
}

void term_clear(void)
{
	xputs("\x1b[2J\x1b[H");
}
