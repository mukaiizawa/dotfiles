windows�p�����R�[�h�ϊ���
$Id: ctrwin.m 5955 2016-12-23 01:25:10Z kt $

*[man]
.caption ����
windows�pCodeTranslator�N���X�B

CodeTranslatorFactory���ԐړI�ɍ\�z�����̂ŁA���ڎg�p����K�v�͂Ȃ��B
.caption ��������
windows�ł̂ݓ���B
.caption �֘A����
.overview ctrlib

*import.@
	Mulk import: "dl"
**import dll.@
	DL import: "kernel32.dll"
		procs: #(#MultiByteToWideChar 106 #WideCharToMultiByte 108)
		
*CodeTranslator.win class.@
	CodeTranslator addSubclass: #CodeTranslator.win
		instanceVars: "wcBuf fromCode toCode"
**CodeTranslator.win >> alloc
	super alloc;
	FixedByteArray basicNew: limit * 4 ->wcBuf
**CodeTranslator.win >> codeNumber: ch
	ch = 's' ifTrue: [0!]; --CP_ACP
	ch = 'u' ifTrue: [65001!]; --CP_UTF8
	self error: "illegal char code " + ch
**CodeTranslator.win >> init: fromTo
	self codeNumber: fromTo first ->fromCode;
	self codeNumber: (fromTo at: 1) ->toCode
**CodeTranslator.win >> translate: buf size: size
	self reserve: size;
	DL call: #MultiByteToWideChar
		with: fromCode with: 0
		with: buf with: size
		with: wcBuf with: wcBuf size // 2 ->:wcCount;
	DL call: #WideCharToMultiByte
		with: toCode with: 0
		with: wcBuf with: wcCount
		with: resultBuf with: resultBuf size with: #(0 0)!
