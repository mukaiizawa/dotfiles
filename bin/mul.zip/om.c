/*
	object memory.
	$Id: om.c 4006 2015-01-31 07:02:37Z kt $
*/

#include "std.h"

#include "mem.h"

#include "om.h"

#if !MACRO_OM_P_P
int om_p(object o)
{
	return (((intptr_t)o)&1)==0;
}
#endif

/* short integer access */

#if !MACRO_SINT_P_P
int sint_p(object o)
{
	return (((intptr_t)o)&1)==1;
}
#endif

#if !MACRO_SINT_VAL_P
int sint_val(object o)
{
	xassert(sint_p(o));
	return ((intptr_t)o)>>1;
}
#endif

int sint_range_p(int i)
{
	return SINT_MIN<=i&&i<=SINT_MAX;
}

#if !MACRO_SINT_P
object sint(int i)
{
	xassert(sint_range_p(i));
	return (object)(((intptr_t)i<<1)|1);
}
#endif

/* header access */
/** hash */

int om_hash(object o)
{
	int result;
	if(om_p(o)) result=o->header;
	else result=sint_val(o);
	result&=OM_HASH_MASK;
	return result;
}

void om_set_hash(object o,int val)
{
	xassert(om_p(o));
	xassert(0<=val&&val<=OM_HASH_MASK);
	o->header=(o->header&~OM_HASH_MASK)|val;
}

static int hash_count;

void om_init_hash(object o)
{
	om_set_hash(o,hash_count++);
	if(hash_count>OM_HASH_MASK) hash_count=0;
}

int om_bytes_hash(char *p,int size)
{
	int i,hval;
	hval=0;
	for(i=0;i<size;i++) hval=hval*137+LC(p+i);
	return hval&OM_HASH_MASK;
}

void om_set_string_hash(object o)
{
	xassert(om_size(o)==SIZE_STRING||om_size(o)==SIZE_SYMBOL);
	om_set_hash(o,om_bytes_hash(o->fbarray.elt,o->fbarray.size));
}

int om_number_hash(double d)
{
	int i;
	if(SINT_MIN<=d&&d<=SINT_MAX) {
		i=(int)d;
		if(i==d) return i&OM_HASH_MASK;
	}
	return om_bytes_hash((char*)&d,sizeof(double));
}

/** size */

#if !MACRO_OM_SIZE_P
int om_size(object o)
{
	if(sint_p(o)) return SIZE_SINT;
	return (o->header&OM_SIZE_MASK)>>OM_SIZE_POS;
}
#endif

void om_set_size(object o,int size)
{
	xassert(om_p(o));
	xassert(0<=size&&size<256);
	o->header=(o->header&~OM_SIZE_MASK)|(size<<OM_SIZE_POS);
}

/* allocation */

int om_used_memory;
int om_max_used_memory;

#if OM_MEMORY_CHUNK_P
#include "heap.h"
static struct heap heap;
#define LINK0_SIZE (8*sizeof(intptr_t))
static object link0;
#define LINK1_SIZE (LINK0_SIZE*2)
static object link1;
#endif

object om_alloc(int size)
{
	om_used_memory+=size;
	if(om_used_memory>om_max_used_memory) om_max_used_memory=om_used_memory;
#if OM_MEMORY_CHUNK_P
	{
		object result;
		if(size<=LINK0_SIZE) {
			if(link0==NULL) result=heap_alloc(&heap,LINK0_SIZE);
			else {
				result=link0;
				link0=result->next;
			}
			return result;
		} else if(size<=LINK1_SIZE) {
			if(link1==NULL) result=heap_alloc(&heap,LINK1_SIZE);
			else {
				result=link1;
				link1=result->next;
			}
			return result;
		}
	}
#endif

	return xmalloc(size);
}

static int om_byte_size(object o)
{
	int size;
	size=om_size(o);
	switch(size) {
	case SIZE_FBARRAY:
	case SIZE_STRING:
	case SIZE_SYMBOL:
		return sizeof(struct fbarray)+o->fbarray.size-1;
	case SIZE_FARRAY:
		return sizeof(struct farray)+(o->farray.size-1)*sizeof(object);
	case SIZE_LINT:
		return sizeof(struct lint);
	case SIZE_FLOAT:
		return sizeof(struct xfloat);
	default:
		return sizeof(struct gobject)+(size-1)*sizeof(object);
	}
}

void om_free(object o)
{
	int size;
	size=om_byte_size(o);
	
	om_used_memory-=size;
#if OM_MEMORY_CHUNK_P
	if(size<=LINK0_SIZE) {
		o->next=link0;
		link0=o;
		return;
	} else if(size<=LINK1_SIZE) {
		o->next=link1;
		link1=o;
		return;
	}
#endif
	xfree(o);
}

/* table */

struct xarray om_table;

object om_nil;
object om_true;
object om_false;

object om_Class;
object om_ShortInteger;
object om_LongInteger;
object om_Float;
object om_FixedByteArray;
object om_String;
object om_Symbol;
object om_FixedArray;
object om_Method;
object om_Process;
object om_Context;
object om_Block;
object om_Char;

object om_Mulk;
object om_boot;
object om_doesNotUnderstand;
object om_primitiveFailed;
object om_error;
object om_trap_cp_sp;
object om_equal;
object om_plus;
object om_lt;
object om_inc;
object om_dec;

/**/

void om_init_array(object *table,int size)
{
	int i;
	for(i=0;i<size;i++) table[i]=om_nil;
}

object om_class(object o)
{
	object result;
	
	if(sint_p(o)) result=om_ShortInteger;
	else {
		switch(om_size(o)) {
		case SIZE_FBARRAY: result=om_FixedByteArray; break;
		case SIZE_STRING: result=om_String; break;
		case SIZE_SYMBOL: result=om_Symbol; break;
		case SIZE_FARRAY: result=om_FixedArray; break;
		case SIZE_LINT: result=om_LongInteger; break;
		case SIZE_FLOAT: result=om_Float; break;
		default: result=o->gobject.xclass; break;
		}
	}

	xassert(result!=NULL);
	return result;
}

object om_boolean(int b)
{
	if(b) return om_true;
	else return om_false;
}

void om_init(void)
{
	xarray_init(&om_table);
	hash_count=0;
	om_used_memory=0;
	om_max_used_memory=0;

#if OM_MEMORY_CHUNK_P
	heap_init(&heap);
	link0=NULL;
	link1=NULL;
#endif
}
