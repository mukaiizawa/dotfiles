/*
	interpreter.
	$Id: ip.c 6205 2017-03-25 09:41:55Z kt $
*/

#include "std.h"
#include <string.h>
#include "mem.h"

#include "om.h"

#include "ip.h"
#include "gc.h"
#include "inst.h"

#if INTR_DOSPOLLING_P
#include <signal.h>
#include "dosterm.h"
#endif

#define STACK_GAP 100

static object cur_process;
static object cur_method;
static object cur_context; /* nil to frame mode */

static int ip;
static int sp;
static int sp_used; /* after last gc */
static int sp_max;
static int fp;
static int cp;
static int cp_used;
static int cp_max;
static int64_t cycle;

/* error */

int ip_trap_code;
static char *error_message;

static void error_mark(char *msg)
{
	/* note: execution continues, you'd better to return ip_main immediately */
	ip_trap_code=TRAP_ERROR;
	error_message=msg;
}

/* process */

static object process_new(int fs_size,int cs_size)
{
	object process;
	
	process=gc_object_new(om_Process,0);

	process->process.frame_stack=gc_object_new(om_FixedArray,fs_size);
	process->process.sp=sint(0);

	process->process.context_stack=gc_object_new(om_FixedArray,cs_size);
	process->process.cp=sint(0);

	return process;
}

static void process_sync(void)
{
	cur_process->process.context=cur_context;
	gc_refer(cur_process,cur_context);
	cur_process->process.method=cur_method;
	gc_refer(cur_process,cur_method);
	cur_process->process.ip=sint(ip);

	gc_regist_refnew(cur_process->process.frame_stack);
	cur_process->process.sp=sint(sp);
	cur_process->process.sp_used=sint(sp_used);
	cur_process->process.sp_max=sint(sp_max);
	cur_process->process.fp=sint(fp);

	gc_regist_refnew(cur_process->process.context_stack);
	cur_process->process.cp=sint(cp);
	cur_process->process.cp_used=sint(cp_used);
	cur_process->process.cp_max=sint(cp_max);
}

#ifdef IP_PROFILE
#include "log.h"
#include "omd.h"
#include "splay.h"
#include "heap.h"

struct profile {
	object xclass;
	object selector;
	int cycle_count;
	int call_count;
};

static struct splay profile_splay;
static struct heap profile_heap;
static struct profile *cur_profile;

static int object_cmp(object p,object q)
{
	return (char*)p-(char*)q;
}

static int profile_cmp(void *p0,void *q0)
{
	struct profile *p,*q;
	int d;
	
	p=p0;
	q=q0;
	if((d=object_cmp(p->xclass,q->xclass))!=0) return d;
	if((d=object_cmp(p->selector,q->selector))!=0) return d;
	return 0;
}

static void profile_init(void)
{
	heap_init(&profile_heap);
	splay_init(&profile_splay,profile_cmp);
}

static struct profile *profile_get(object method)
{
	struct profile t,*p;
	t.xclass=method->method.belong_class->xclass.name;
	t.selector=method->method.selector;

	p=splay_find(&profile_splay,&t);
	if(p==NULL) {
		p=heap_alloc(&profile_heap,sizeof(struct profile));
		p->xclass=t.xclass;
		p->selector=t.selector;
		p->cycle_count=0;
		p->call_count=0;
		splay_add(&profile_splay,p,p);
	}
	return p;
}

static void profile_dump_func(int depth,void *key,void *data)
{
	struct profile *p;
	p=key;
	log_f(" %6.2f %8d %8d %8d ",
		p->cycle_count*100.0/(cycle),
		p->cycle_count,p->call_count,p->cycle_count/p->call_count);
	om_log_symbol(p->xclass);
	log_f(" >> ");
	om_log_symbol(p->selector);
	log_ln();
}

static void profile_dump(void)
{
	splay_foreach(&profile_splay,profile_dump_func);
}

#endif

/* switch method */

static void switch_method(object m)
{
	cur_method=m;
#ifdef IP_PROFILE
	cur_profile=profile_get(m);
#endif
}

/* frame stack */

static void fs_push(object o)
{
	object fs;

	fs=cur_process->process.frame_stack;
	if(sp==fs->farray.size-STACK_GAP) error_mark("fs_push/stack overflow.");
	else if(sp>=fs->farray.size) xerror("fs_push/stack overflow.");
	
	fs->farray.elt[sp++]=o;
	if(sp>sp_used) {
		sp_used=sp;
		if(sp_used>sp_max) sp_max=sp_used;
	}
	/* fs is always refnew -- see ip_mark_object */
}

static object *fs_nth(int pos)
{
	xassert(0<=pos&&pos<sp);
	return &cur_process->process.frame_stack->farray.elt[pos];
}

static void fs_ndrop(int n)
{
	/* note: do not erase dropped items in stack. see i_send */
	sp-=n;
	xassert(sp>=0);
}

static object fs_top(void)
{
	return *fs_nth(sp-1);
}

static object fs_pop(void)
{
	object result;

	result=fs_top();
	fs_ndrop(1);
	return result;
}

/* context stack */

static void cs_push(object o)
{
	object cs;

	cs=cur_process->process.context_stack;
	if(cp==cs->farray.size-STACK_GAP) error_mark("cs_push/stack overflow.");
	else if(cp>=cs->farray.size) xerror("cs_push/stack overflow.");
	
	cs->farray.elt[cp++]=o;
	if(cp>cp_used) {
		cp_used=cp;
		if(cp_used>cp_max) cp_max=cp_used;
	}
	/* cs is always refnew -- see ip_mark_object */
}

static object cs_pop(void)
{
	xassert(cp>=1);
	return cur_process->process.context_stack->farray.elt[--cp];
}

static void cs_save(void)
{
	if(ip==-1) return;

	if(cur_context!=om_nil) cs_push(cur_context);
	else cs_push(cur_method);
	cs_push(sint(fp));
	cs_push(sint(ip));
}

static void cs_resume(void)
{
	if(cp==0) {
		ip=-1;
		return;
	}

	ip=sint_val(cs_pop());
	fp=sint_val(cs_pop());
	cur_context=cs_pop();
	if(cur_context->gobject.xclass==om_Context) {
		switch_method(cur_context->context.method);
	} else {
		switch_method(cur_context);
		cur_context=om_nil;
	}
}

/* search method */

static object find_method_class(object cl,object sel)
{
	object methods,m;
	int i;
	
	methods=cl->xclass.methods;
	if(methods==om_nil) return NULL;
	xassert(om_class(methods)==om_FixedArray);
	for(i=0;i<methods->farray.size;i++) {
		m=methods->farray.elt[i];
		if(m==om_nil) return NULL;
		xassert(om_class(m)==om_Method);
		if(m->method.selector==sel) return m;
	}
	return NULL;
}

static object find_method_feature(object cl,object sel)
{
	object fs,f,m;
	int i;
	
	fs=cl->xclass.features;
	if(fs==om_nil) return NULL;
	xassert(om_size(fs)==SIZE_FARRAY);
	for(i=0;i<fs->farray.size;i++) {
		f=fs->farray.elt[i];
		xassert(om_class(f)==om_Class);
		if((m=find_method_class(f,sel))!=NULL) return m;
		if((m=find_method_feature(f,sel))!=NULL) return m;
	}
	return NULL;
}

static object find_method_main(object cl,object sel)
{
	object m;

	while(cl!=om_nil) {
		xassert(om_class(cl)==om_Class);
		if((m=find_method_class(cl,sel))!=NULL) return m;
		if((m=find_method_feature(cl,sel))!=NULL) return m;
		cl=cl->xclass.superclass;
	}
	return NULL;
}

#if IP_METHOD_CACHE_P
#define CACHE_SIZE 1024 /* must be 2^n */

struct cache {
	object class,selector,method;
} cache[CACHE_SIZE];

static void cache_reset(object selector)
{
	int i;
	for(i=0;i<CACHE_SIZE;i++) {
		if(selector==om_nil||cache[i].selector==selector) cache[i].class=NULL;
	}
}

int cache_hit;
int cache_new;
int cache_update;

static void cache_init(void)
{
	cache_reset(om_nil);
	cache_hit=0;
	cache_new=0;
	cache_update=0;
}

/* o must be object and CACHE_SIZE<OM_HASH_MASH */
#define HASH(o) o->header

static object find_method(object cl,object sel)
{
	int hval;
	struct cache *c;
	object m;
	
	hval=(HASH(cl)^(HASH(sel)<<1))&(CACHE_SIZE-1);

	c=&cache[hval];
	if(c->class==cl&&c->selector==sel) {
		cache_hit++;
		return c->method;
	}

	m=find_method_main(cl,sel);
	if(c->class==NULL) cache_new++;
	else cache_update++;
	
	c->class=cl;
	c->selector=sel;
	c->method=m;

	return m;
}
#else
#define find_method(cl,sel) find_method_main(cl,sel)
#endif

/* instructions */

static int fetch(void)
{
	object bc;
	bc=cur_method->method.bytecode;
	xassert(om_class(bc)==om_FixedByteArray);
	xassert(0<=ip&&ip<bc->fbarray.size);
	return LC(bc->fbarray.elt+ip++);
}

static object temp_var(int no)
{
	return *fs_nth(fp+no);
}

static void i_push_instance_var(int no)
{
	object self;
	int size;
	
	self=temp_var(0);
	size=om_size(self);
	xassert(size<SIZE_LAST);
	xassert(0<=no&&no<size);
	fs_push(self->gobject.elt[no]);
}

static void i_push_context_var(int no)
{
	xassert(cur_context!=om_nil);
	xassert(0<=no&&no<om_size(cur_context)-SIZE_CONTEXT);
	fs_push(cur_context->context.vars[no]);
}

static void i_push_temp_var(int no)
{
	fs_push(temp_var(no));
}

static object literal(int no)
{
	object ls;
	
	ls=cur_method->method.literal;
	xassert(om_class(ls)==om_FixedArray);
	xassert(0<=no&&no<ls->farray.size);
	return ls->farray.elt[no];	
}

static void i_push_literal(int no)
{
	fs_push(literal(no));
}

static void i_set_instance_var(int no)
{
	object self,o;
	int size;
	
	self=temp_var(0);
	size=om_size(self);
	xassert(size<SIZE_LAST);
	xassert(0<=no&&no<size);
	o=fs_top();
	self->gobject.elt[no]=o;
	gc_refer(self,o);
}

static void i_set_context_var(int no)
{
	object val;
	
	xassert(cur_context!=om_nil);
	xassert(0<=no&&no<om_size(cur_context)-SIZE_CONTEXT);
	val=fs_top();
	cur_context->context.vars[no]=val;
	gc_refer(cur_context,val);
}

static void i_set_temp_var(int no)
{
	*fs_nth(fp+no)=fs_top();
}

static void i_end(void)
{
	object retval;
	
	retval=fs_pop();
	sp=fp;
	fs_push(retval);
	cs_resume();
}

static void i_return(void)
{
	object retval;
	int retsp,retcp;

	if(cur_context==om_nil) {
		i_end();
		return;
	}
	
	retval=fs_pop();
	retsp=sint_val(cur_context->context.sp);
	retcp=sint_val(cur_context->context.cp);
	
	if(retsp>sp||retcp>cp||
		cur_process->process.context_stack->farray.elt[retcp-1]!=cur_context) {
		error_mark("i_return/illegal context.");
		return;
	}
	sp=retsp;
	cp=retcp;
	cs_pop(); /* context mark. */
	fs_push(retval);
	cs_resume();
}

static int perform(object self,object sel,int narg,object *args,
	object *result);

static void send_error(object rec,object err,object sel,int narg)
{
	object fa;
	
	fa=gc_object_new(om_FixedArray,narg+1);
	fa->farray.elt[0]=sel;
	if(narg>0) memcpy(&fa->farray.elt[1],fs_nth(sp-narg),sizeof(object)*narg);
	fs_ndrop(narg+1);
	perform(rec,err,1,&fa,NULL);
}

extern int (*prim_table[])(object self,object *args,object *result);

static object perform_method(object rec,object m,int narg)
{
	object result,*args;
	int prim,ets,i,cs;
	
#ifdef IP_PROFILE
	profile_get(m)->call_count++;
#endif
	if(m->method.prim_code!=om_nil) {
		result=rec;
#ifdef IP_PROFILE
		/* primitive counts as 1 cycle par call. */
		profile_get(m)->cycle_count++;
#endif
		prim=sint_val(m->method.prim_code);
		if(narg==0) args=NULL;
		else args=fs_nth(sp-narg);
		fs_ndrop(narg+1);
		/* note: after sp accession */
		if((*prim_table[prim])(rec,args,&result)) {
			return result;
		}
		sp+=narg+1;
		if(m->method.bytecode==om_nil) {
			send_error(rec,om_primitiveFailed,m->method.selector,narg);
			return NULL;
		}
	}

	cs_save();
	switch_method(m);
	fp=sp-narg-1;
	ets=sint_val(m->method.ext_temp_size);
	for(i=0;i<ets;i++) fs_push(om_nil);
	cs=sint_val(m->method.context_size);
	if(cs!=0) {
		cur_context=gc_object_new(om_Context,cs);
		cs_push(cur_context);
		cur_context->context.method=m;
		cur_context->context.sp=sint(fp);
		cur_context->context.cp=sint(cp);
	} else cur_context=om_nil;
	ip=0;
	return NULL;
}

static int perform(object rec,object sel,int narg,object *args,object *resultp)
{
	int i;
	object m,result;

	m=find_method(om_class(rec),sel);
	if(m==NULL||narg!=sint_val(m->method.arg_count)) return FALSE;	
	fs_push(rec);
	for(i=0;i<narg;i++) fs_push(args[i]);
	result=perform_method(rec,m,narg);
	if(resultp==NULL) {
		xassert(result==NULL);
	} else *resultp=result;
	return TRUE;
}

static void xsend(int super_p,object sel,int narg)
{
	object rec,cl,m,result;
	
	rec=*fs_nth(sp-1-narg);
	if(super_p) {
		cl=cur_method->method.belong_class->xclass.superclass;
		if(cl==om_nil) {
			send_error(rec,om_doesNotUnderstand,sel,narg);
			return;
		}
	} else cl=om_class(rec);

	m=find_method(cl,sel);
	if(m==NULL) {
		send_error(rec,om_doesNotUnderstand,sel,narg);
		return;
	}
	result=perform_method(rec,m,narg);
	if(result!=NULL) {
		fs_push(result);
	}
}

static void i_send(int super_p,int narg,int selpos)
{
	xsend(super_p,literal(selpos),narg);
}

static void i_block(int narg,int size)
{
	object block;

	xassert(cur_context!=om_nil);
	
	block=gc_object_new(om_Block,0);
	block->block.context=cur_context;
	block->block.narg=sint(narg);
	block->block.start=sint(ip);
	fs_push(block);
	ip+=size;
}

static void i_branch(int off)
{
	ip+=off;
}

static void i_branch_cond(int cond,int off)
{
	object o;
	o=fs_top();
	if(!(o==om_true||o==om_false)) {
		error_mark("i_branch_cond/reciever is not Boolean.");
	}
	if(o==om_boolean(cond)) i_branch(off);
	else fs_ndrop(1);
}

static void i_send_equal(void)
{
	object self,arg;
	self=*fs_nth(sp-2);
	arg=*fs_nth(sp-1);
	if((sint_p(self)&&sint_p(arg))
		||om_size(self)==SIZE_SYMBOL
		||(om_size(self)<SIZE_LAST&&self->gobject.xclass==om_Char)) {
		fs_ndrop(2);
		fs_push(om_boolean(self==arg));
		return;
	}

	xsend(FALSE,om_equal,1);
}

static void i_send_plus(void)
{
	object self,arg;
	int ans;
	self=*fs_nth(sp-2);
	arg=*fs_nth(sp-1);
	if(sint_p(self)&&sint_p(arg)) {
		ans=sint_val(self)+sint_val(arg);
		if(sint_range_p(ans)) {
			fs_ndrop(2);
			fs_push(sint(ans));
			return;
		}
	}
	xsend(FALSE,om_plus,1);
}

static void i_send_lt(void)
{
	object self,arg;
	self=*fs_nth(sp-2);
	arg=*fs_nth(sp-1);
	if(sint_p(self)&&sint_p(arg)) {
		fs_ndrop(2);
		fs_push(om_boolean(sint_val(self)<sint_val(arg)));
		return;
	}
	xsend(FALSE,om_lt,1);
}

static void i_start_times_do(void)
{
	if(!sint_p(fs_top())) {
		error_mark("i_start_times_do/reciever is not ShortInteger");
		return;
	}
	fs_push(sint(0));
}

static void i_times_do(int vn,int off)
{
	int end,cur;
	end=sint_val(*fs_nth(sp-2));
	cur=sint_val(fs_top());
	if(cur<end) {
		if(vn!=0) {
			if(cur_context==om_nil) *fs_nth(fp+vn)=sint(cur);
			else cur_context->context.vars[vn]=sint(cur);
		}
		*fs_nth(sp-1)=sint(cur+1);
	} else {
		fs_ndrop(1);
		i_branch(off);
	}		
}

static void i_send_inc(void)
{
	object self;
	int ans;
	
	self=fs_top();
	if(sint_p(self)) {
		ans=sint_val(self)+1;
		if(ans<=SINT_MAX) {
			*fs_nth(sp-1)=sint(ans);
			return;
		}
	}
	xsend(FALSE,om_inc,0);
}

static void i_send_dec(void)
{
	object self;
	int ans;
	
	self=fs_top();
	if(sint_p(self)) {
		ans=sint_val(self)-1;
		if(SINT_MIN<=ans) {
			*fs_nth(sp-1)=sint(ans);
			return;
		}
	}
	xsend(FALSE,om_dec,0);
}

static void trap(void)
{
	object args[3];
	if(ip_trap_code==TRAP_ERROR) {
		args[0]=gc_string(error_message);
		perform(cur_process,om_error,1,args,NULL);
	} else {
		cs_save();
		args[0]=sint(ip_trap_code);
		args[1]=sint(cp);
		args[2]=sint(sp);
		ip=-1;
		perform(cur_process,om_trap_cp_sp,3,args,NULL);
	}
	ip_trap_code=TRAP_NONE;
}

static void ip_main(void)
{
	int op,lo,opr;
	object common_literal[7];

	common_literal[0]=sint(0);
	common_literal[1]=sint(1);
	common_literal[2]=sint(2);
	common_literal[3]=sint(-1);
	common_literal[4]=om_nil;
	common_literal[5]=om_true;
	common_literal[6]=om_false;
			
	while(ip!=-1) {
#ifdef IP_PROFILE
		cur_profile->cycle_count++;
#endif
		if(ip_trap_code!=TRAP_NONE) trap();

		cycle++;
		if(cycle%IP_POLLING_INTERVAL==0) {
			gc_chance();
#if INTR_DOSPOLLING_P
			dosterm_check();
#endif
		}

		op=fetch();
		lo=op&0xf;
		switch(op>>4) {
		case BASIC_INST:
			switch(lo) {
			case PUSH_INSTANCE_VAR_INST: i_push_instance_var(fetch()); break;
			case PUSH_CONTEXT_VAR_INST: i_push_context_var(fetch()); break;
			case PUSH_TEMP_VAR_INST: i_push_temp_var(fetch()); break;
			case PUSH_LITERAL_INST: i_push_literal(fetch()); break;
			case SET_INSTANCE_VAR_INST: i_set_instance_var(fetch()); break;
			case SET_CONTEXT_VAR_INST: i_set_context_var(fetch()); break;
			case SET_TEMP_VAR_INST: i_set_temp_var(fetch()); break;
			case DROP_INST: fs_ndrop(1); break;
			case END_INST: i_end(); break;
			case RETURN_INST: i_return(); break;
			case BRANCH_BACKWARD_INST: i_branch(-fetch()); break;
			default: xassert(FALSE);
			}
			break;
		case SEND_INST: i_send(FALSE,lo,fetch()); break;
		case SEND_SUPER_INST: i_send(TRUE,lo,fetch()); break;
		case BLOCK_INST: i_block(lo,fetch()); break;
		case EXT_INST:
			switch(lo) {
			case BRANCH_FORWARD_INST: i_branch(fetch()); break;
			case BRANCH_TRUE_FORWARD_INST: i_branch_cond(TRUE,fetch()); break;
			case BRANCH_FALSE_FORWARD_INST: i_branch_cond(FALSE,fetch()); break;
			case START_TIMES_DO_INST: i_start_times_do(); break;
			case TIMES_DO_INST:
				opr=fetch();
				i_times_do(opr,fetch());
				break;
			default: xassert(FALSE);
			}
			break;
		case PUSH_INSTANCE_VAR_SHORT_INST: i_push_instance_var(lo); break;
		case PUSH_CONTEXT_VAR_SHORT_INST: i_push_context_var(lo); break;		
		case PUSH_TEMP_VAR_SHORT_INST: i_push_temp_var(lo); break;
		case PUSH_LITERAL_SHORT_INST: i_push_literal(lo); break;
		case SET_INSTANCE_VAR_SHORT_INST: i_set_instance_var(lo); break;
		case SET_CONTEXT_VAR_SHORT_INST: i_set_context_var(lo); break;
		case SET_TEMP_VAR_SHORT_INST: i_set_temp_var(lo); break;
		case SEND_0_SHORT_INST: i_send(FALSE,0,lo); break;
		case SEND_1_SHORT_INST: i_send(FALSE,1,lo); break;
		case SEND_COMMON_INST:
			switch(lo) {
			case 0: i_send_equal(); break;
			case 1: i_send_plus(); break;
			case 2: i_send_lt(); break;
			case 3: *fs_nth(sp-1)=om_boolean(fs_top()==om_nil); break;
			case 4: *fs_nth(sp-1)=om_boolean(fs_top()!=om_nil); break;
			case 5: i_send_inc(); break;
			case 6: i_send_dec(); break;
			default: xassert(FALSE);
			}
			break;
		case PUSH_COMMON_LITERAL_INST: fs_push(common_literal[lo]); break;
		default: xassert(FALSE);
		}
	}
}

#if INTR_SIGNAL_P||INTR_SIGACTION_P
#include <signal.h>
static void intr_handler(int signo)
{
	ip_trap_code=TRAP_INTERRUPT;
#if INTR_SIGNAL_P
	signal(SIGINT,intr_handler);
#endif
}
#endif

#if INTR_WINCONSOLE_P
#include <windows.h>
static BOOL intr_handler(DWORD dwCtrlType)
{
	if(dwCtrlType==CTRL_C_EVENT) {
		ip_trap_code=TRAP_INTERRUPT;
		return TRUE;
	}
	return FALSE;
}
#endif

static void intr_init(void)
{
#if INTR_SIGNAL_P
	signal(SIGINT,intr_handler);
#endif

#if INTR_SIGACTION_P
	struct sigaction sa;
	memset(&sa,0,sizeof(sa));
	sa.sa_handler=intr_handler;
	if(sigaction(SIGINT,&sa,NULL)==-1) xerror("sigaction failed.");
#endif

#if INTR_WINCONSOLE_P
	if(SetConsoleCtrlHandler((PHANDLER_ROUTINE)intr_handler,TRUE)==0) {
		xerror("SetConsoleCtrlHandler failed.");
	}
#endif

#if INTR_DOSPOLLING_P
	signal(SIGINT,SIG_IGN);
	dosterm_init();
#endif
}

void ip_start(object arg,int fs_size,int cs_size)
{
#if IP_METHOD_CACHE_P
	cache_init();
#endif

#ifdef IP_PROFILE
	profile_init();
#endif

	cur_process=process_new(fs_size,cs_size);

	ip=-1; /* not in execution */
	sp=0;
	sp_used=0;
	sp_max=0;
	fp=0;
	cp=0;
	cp_used=0;
	cp_max=0;
	ip_trap_code=TRAP_NONE;
	cycle=0;

	perform(om_Mulk,om_boot,1,&arg,NULL);

	intr_init();
	
	ip_main();

#ifdef IP_PROFILE
	profile_dump();
#endif
}

/**/

void ip_mark_object(int full_gc_p)
{
	object fs,cs;
	int i;
	
	fs=cur_process->process.frame_stack;
	if(sp_used>sp) {
		for(i=sp;i<sp_used;i++) fs->farray.elt[i]=om_nil;
		sp_used=sp;
	}

	cs=cur_process->process.context_stack;
	if(cp_used>cp) {
		for(i=cp;i<cp_used;i++) cs->farray.elt[i]=om_nil;
		cp_used=cp;
	}
	
	if(!full_gc_p) {
		gc_regist_refnew(fs);
		gc_regist_refnew(cs);
	}
	
	gc_mark(cur_process);
	gc_mark(cur_context);
	gc_mark(cur_method);
}

/* core primitives */

#include "prim.h"

/** Object */

PRIM(object_class)
{
	*result=om_class(self);
	return TRUE;
}

PRIM(object_equal)
{
	*result=om_boolean(self==args[0]);
	return TRUE;
}

static int basic_size(object o)
{
	int size;
	size=om_size(o);
	switch(size) {
	case SIZE_SINT:
		size=sizeof(int);
		break;
	case SIZE_FBARRAY:
	case SIZE_STRING:
	case SIZE_SYMBOL:
		size=o->fbarray.size;
		break;
	case SIZE_FARRAY:
		size=o->farray.size;
		break;
	case SIZE_LINT:
		size=sizeof(int64_t);
		break;
	case SIZE_FLOAT:
		size=sizeof(double);
		break;
	default:
		break;
	}
	return size;
}

PRIM(object_basicSize)
{
	*result=sint(basic_size(self));
	return TRUE;
}

PRIM(object_basicAt)
{
	int pos,value;

	GET_SINT_ARG(0,pos);
	if(!(0<=pos&&pos<basic_size(self))) return FALSE;
	switch(om_size(self)) {
	case SIZE_SINT:
		value=sint_val(self);
		*result=sint(LC(((char*)&value)+pos));
		break;
	case SIZE_FBARRAY:
	case SIZE_STRING:
	case SIZE_SYMBOL:
		*result=sint(LC(self->fbarray.elt+pos));
		break;
	case SIZE_FARRAY:
		*result=self->farray.elt[pos];
		break;
	case SIZE_LINT:
		*result=sint(LC(((char*)&self->lint.val)+pos));
		break;
	case SIZE_FLOAT:
		*result=sint(LC(((char*)&self->xfloat.val)+pos));
		break;
	default:
		*result=self->gobject.elt[pos];
		break;
	}
	return TRUE;
}

PRIM(object_basicAt_put)
{
	int pos,ival,sizecode;
	
	GET_SINT_ARG(0,pos);
	if(!(0<=pos&&pos<basic_size(self))) return FALSE;
	sizecode=om_size(self);
	ival=0;
	if(sizecode==SIZE_FBARRAY||sizecode==SIZE_STRING||sizecode==SIZE_SYMBOL
		||sizecode==SIZE_LINT||sizecode==SIZE_FLOAT) {
		GET_SINT_ARG(1,ival);
		if(!p_byte_p(ival)) return FALSE;
	}
			
	switch(sizecode) {
	case SIZE_SINT:
		return FALSE;
	case SIZE_FBARRAY:
	case SIZE_STRING:
	case SIZE_SYMBOL:
		self->fbarray.elt[pos]=ival;
		break;
	case SIZE_FARRAY:
		self->farray.elt[pos]=args[1];
		gc_refer(self,args[1]);
		break;
	case SIZE_LINT:
		SC(((char*)&self->lint.val)+pos,ival);
		break;
	case SIZE_FLOAT:
		SC(((char*)&self->xfloat.val)+pos,ival);
		break;
	default:
		self->gobject.elt[pos]=args[1];
		gc_refer(self,args[1]);
		break;
	}
	return TRUE;
}

PRIM(object_hash)
{
	*result=sint(om_hash(self));
	return TRUE;
}

PRIM(object_sethash)
{
	int h;
	GET_SINT_ARG(0,h);
	if(!om_p(self)) return FALSE;
	if(!(0<=h&&h<=OM_HASH_MASK)) return FALSE;
	om_set_hash(self,h);
	return TRUE;
}

PRIM(object_perform_args)
{
	object *argv;
	int narg;

	if(om_class(args[0])!=om_Symbol) return FALSE;
	if(!p_farray_to_array(args[1],&narg,&argv)) return FALSE;
	if(!perform(self,args[0],narg,argv,result)) return FALSE;
	return TRUE;
}

PRIM(object_performMethod_args)
{
	object *argv,m;
	int i,narg;

	m=args[0];
	if(!p_farray_to_array(args[1],&narg,&argv)) return FALSE;
	if(narg!=sint_val(m->method.arg_count)) return FALSE;
	fs_push(self);
	for(i=0;i<narg;i++) fs_push(argv[i]);
	*result=perform_method(self,m,narg);
	return TRUE;
}

/** Class */

PRIM(class_basicNew)
{
	int ext;
	GET_SINT_ARG(0,ext);
	if(self==om_ShortInteger) return FALSE;
	if(ext<0) return FALSE;
	*result=gc_object_new(self,ext);
	return TRUE;
}

/** Block */

static int eval_block(object b,int narg,object *args)
{
	object cx;
	int i;
	
	if(sint_val(b->block.narg)!=narg) return FALSE;
	cx=b->block.context;

	fs_push(cx->context.vars[0]);
	for(i=0;i<narg;i++) fs_push(args[i]);
	
	cs_save();
	switch_method(cx->context.method);
	fp=sp-narg-1;
	cur_context=cx;
	ip=sint_val(b->block.start);
	return TRUE;
}

PRIM(block_valueArgs)
{
	int narg;
	object *argv;
	*result=NULL;
	if(!p_farray_to_array(args[0],&narg,&argv)) return FALSE;
	return eval_block(self,narg,argv);
}
	
PRIM(block_value)
{
	*result=NULL;
	return eval_block(self,0,NULL);
}

PRIM(block_value1)
{
	*result=NULL;
	return eval_block(self,1,args);
}

PRIM(block_value2)
{
	*result=NULL;
	return eval_block(self,2,args);
}

/** Process */

PRIM(process_resumeCp_sp)
{
	GET_SINT_ARG(0,cp);
	GET_SINT_ARG(1,sp);
	cs_resume();
	*result=NULL;
	return TRUE;
}

/*** subprocess switching */

PRIM(process_basicStart)
{
	object parent;
	
	/* self must be process or it's subprocess */
	if(om_class(args[0])!=om_Symbol) return FALSE;
	
	process_sync();
	parent=cur_process;
	cur_process=self;
	ip=-1;
	sp=0;
	sp_used=0;
	sp_max=0;
	fp=0;
	cp=0;
	cp_used=0;
	cp_max=0;
	perform(self,args[0],1,&parent,NULL);
	return TRUE;
}

PRIM(process_basicSwitch)
{
	process_sync();
	cur_process=self;
	cur_context=cur_process->process.context;
	cur_method=cur_process->process.method;
	ip=sint_val(cur_process->process.ip);
	sp=sint_val(cur_process->process.sp);
	sp_used=sint_val(cur_process->process.sp_used);
	sp_max=sint_val(cur_process->process.sp_max);
	fp=sint_val(cur_process->process.fp);
	cp=sint_val(cur_process->process.cp);
	cp_used=sint_val(cur_process->process.cp_used);
	cp_max=sint_val(cur_process->process.cp_max);
	return TRUE;
}

/** Kernel */

PRIM(kernel_currentProcess)
{
	process_sync();
	*result=cur_process;
	return TRUE;
}

PRIM(kernel_cacheReset)
{
#if IP_METHOD_CACHE_P
	cache_reset(args[0]);
#endif
	return TRUE;
}

PRIM(kernel_info)
{
	int no;
	GET_SINT_ARG(0,no);
	switch(no) {
	case 0: *result=p_int64(cycle); break;
	case 1: *result=sint(om_used_memory); break;
	case 2: *result=sint(om_max_used_memory); break;
	case 3: *result=sint(om_table.size); break;
#if IP_METHOD_CACHE_P
	case 4: *result=sint(cache_hit); break;
	case 5: *result=sint(cache_new); break;
	case 6: *result=sint(cache_update); break;
#endif
	default: *result=om_nil; break;
	}
	return TRUE;
}
