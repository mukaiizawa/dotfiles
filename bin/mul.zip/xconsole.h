/*
	xconsole -- basic console IO for terminal less system.
	$Id: xconsole.h 2247 2013-04-29 06:52:15Z kt $
*/

extern void xputc(int ch);
extern void xputs(char *s);
extern void xexit(void);
