/*
	xc character type.
	$Id: xctype.h 503 2011-03-04 14:47:38Z kt $
*/

extern int sjis_trail_size(int ch);
extern int sjis_mblead_p(int ch);
extern int sjis_mbtrail_p(int ch);

extern int utf8_trail_size(int ch);
extern int utf8_mblead_p(int ch);
extern int utf8_mbtrail_p(int ch);
