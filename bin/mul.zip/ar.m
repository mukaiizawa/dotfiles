�A�[�J�C�o
$Id: ar.m 5838 2016-11-20 01:17:39Z kt $

*[man]
.caption ����
	ar.c [option] archive dir -- dir�̓��e��archive�ɂ܂Ƃ߂�B
	ar.l [option] archive -- archive�̃t�@�C���ꗗ��\���B
	ar.e [option] archive dir -- archive�̓��e��dir���֓W�J����B
	ar.p [option] archive entry -- archive����entry�t�@�C�����o�͂���B
.caption ����
�����̃t�@�C�����A�[�J�C�u�t�@�C���ɂ܂Ƃ߂���A�W�J�����肷��B

�t�@�C������UTF-8�`���ŕۑ�����ׁA�قȂ镶���R�[�h�Z�b�g�����V�X�e���Ԃł�����������B
.caption �I�v�V����
	c -- archive�����k����B
	f -- �W�����͂���̃t�@�C�����X�g�̃t�@�C���݂̂�ΏۂƂ���(c/e)�B
	v -- �����ߒ���\������(c/e/p)�B
	
*ar tool.@
	Mulk import: #("optparse" "ctrlib" "tempfile");
	Object addSubclass: #Cmd.ar instanceVars:
		"arstr baseDir options fileSet ctr buf bufSize verbose?"

**Cmd.ar >> init
	4096 ->bufSize;
	FixedByteArray basicNew: bufSize ->buf
**Cmd.ar >> initFileSet
	options at: 'f', ifTrue: [Set new addAll: In lines ->fileSet]
**Cmd.ar >> initVerbose
	options at: 'v' ->verbose?
**Cmd.ar >> initCtr: fromTo
	Mulk.charset = #sjis ifTrue: [CodeTranslatorFactory create: fromTo ->ctr]
**Cmd.ar >> finish
	ctr notNil? ifTrue: [ctr finish]
	
**create.
***Cmd.ar >> writeString: s
	ctr notNil? ifTrue: [ctr translate: s ->s];
	arstr put: s, putByte: 0
***Cmd.ar >> writeFile: f
	f readableFile? ifFalse: [self!];

	f pathFrom: baseDir ->:fn;
	fileSet notNil? ifTrue:
		[fileSet includes?: fn, ifFalse: [self!]];

	verbose? ifTrue: [Out0 putLn: "archive " + fn];
	self writeString: fn;
	self writeString: f size asString;
	f readDo:
		[:fs
		[fs read: buf size: bufSize ->:size, <> 0] whileTrue:
			[arstr write: buf size: size]]
***Cmd.ar >> main.c: args
	self initCtr: "su";
	OptionParser new init: "cfv" ->options, parse: args ->args;
	self initFileSet;
	self initVerbose;
	args first ->:fn;
	args at: 1, asFile ->baseDir;

	options at: 'c' ->:compress?,
		ifTrue: [TempFile create]
		ifFalse: [fn asFile] ->:arfile;
	arfile writeDo:
		[:s s ->arstr;
		baseDir deepList: [:f self writeFile: f]];
	compress? ifTrue:
		["bzip2 " + fn + ' ' + arfile quotedPath, runCmd;
		arfile remove];
	self finish

**readings.
***Cmd.ar >> readString
	StringWriter new ->:w;
	[arstr getByte ->:byte, <> 0] whileTrue:
		[byte = -1 ifTrue: [nil!];
		w putByte: byte];
	w asString ->:result;
	ctr notNil? ifTrue: [ctr translate: result ->result];
	result!
***Cmd.ar >> readArchiveEntries: arfn do: block
	options at: 'c' ->:compress?,
		ifTrue:
			[TempFile create ->:arfile;
			"bzip2.d " + arfn + ' ' + arfile quotedPath, runCmd]
		ifFalse: [arfn asFile ->arfile];
	arfile readDo:
		[:s s ->arstr;
		[self readString ->:fn, notNil?] whileTrue:
			[self readString asInteger ->:size;
			block value: fn value: size]];
	compress? ifTrue: [arfile remove]
***Cmd.ar >> skip: size
	[size <> 0] whileTrue:
		[size min: bufSize ->:s;
		arstr read: buf size: s;
		size - s ->size]
***Cmd.ar >> read: size to: str
	[size <> 0] whileTrue:
		[size min: bufSize ->:s;
		arstr read: buf size: s;
		str write: buf size: s;
		size - s ->size]
		
**Cmd.ar >> main.l: args
	self initCtr: "us";
	OptionParser new init: "c" ->options, parse: args ->args;
	self readArchiveEntries: args first do:
		[:fn :size
		Out putLn: fn;
		self skip: size];
	self finish
**Cmd.ar >> main.e: args
	self initCtr: "us";
	OptionParser new init: "cfv" ->options, parse: args ->args;
	self initFileSet;
	self initVerbose;
	args at: 1, asFile ->baseDir;
	self readArchiveEntries: args first do:
		[:fn :size
		fileSet nil? or: [fileSet includes?: fn],
			ifTrue:
				[baseDir + fn ->:f;
				verbose? ifTrue: [Out0 putLn: "extract " + fn];
				f writeDo: [:fs self read: size to: fs]]
			ifFalse:
				[verbose? ifTrue: [Out0 putLn: "skip " + fn];
				self skip: size]];
	self finish
**Cmd.ar >> main.p: args
	self initCtr: "us";
	OptionParser new init: "cv" ->options, parse: args ->args;
	self initVerbose;
	args at: 1 ->:pn;
	self readArchiveEntries: args first do:
		[:fn :size
		fn = pn
			ifTrue:
				[verbose? ifTrue: [Out0 putLn: "extract " + fn];
				self read: size to: Out]
			ifFalse:
				[verbose? ifTrue: [Out0 putLn: "skip " + fn];
				self skip: size]];
	self finish
