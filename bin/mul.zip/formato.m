officeSuite�p�e�L�X�g���`���[�e�B���e�B
$Id: formato.m 5730 2016-10-16 01:10:39Z kt $

*[man]
.caption ����
javaScript�o�R��officeSuite�𐧌䂷�鎖�Ńe�L�X�g���`���s���ׂ̃��[�e�B���e�B�N���X�Q�B

*import.@
	Mulk import: "format"

*Format.FixedFormReader class.@
	Object addSubclass: #Format.FixedFormReader
**Format.FixedFormReader >> read: reader
	reader level ->:level;
	[reader level >= level] whileTrue:
		[reader header asSymbol ->:name;
		reader getLn;
		StringWriter new ->:wr;
		reader linesDo: [:l wr putLn: l];
		reader nextBlock;
		Mulk at: name put: wr asString]
		
*Format.Office class.@
	Format addSubclass: #Format.Office
**Format.Office >> putString: buf
	Out put: '"';
	buf do:
		[:ch
		ch = '\\' | (ch = '"') ifTrue: [Out put: '\\'];
		Out put: ch];
	Out put: '"'
**Format.Office >> putInsertText: buf topMargin: tm restMargin: rm
	Out put: "insertText(";
	self putString: buf;
	Out putLn: "," + tm + "," + rm + ");"
**Format.Office >> writeVerbatim: buf topMargin: tm restMargin: rm
	self putInsertText: buf topMargin: tm restMargin: rm
**Format.Office >> writeParagraph: buf topMargin: tm
	self putInsertText: buf topMargin: tm restMargin: 0
**Format.Office >> writeOutline: s level: l
	Out put: "insertOutline(";
	self putString: (WideCharArray new addString: s);
	Out putLn: "," + l + ");"
**Format.Office >> writeCaption: buf
	self putInsertText: buf topMargin: 0 restMargin: 4
**Format.Office >> writeRightAlign: buf
	Out put: "insertRightAlign(";
	self putString: buf;
	Out putLn: ");"
**Format.Office >> writeCenterAlign: buf
	Out put: "insertCenterAlign(";
	self putString: buf;
	Out putLn: ");"
**Format.Office >> writeLineBreak
	Out putLn: "insertLineBreak();"
**Format.Office >> writePageBreak
	Out putLn: "insertPageBreak();"
