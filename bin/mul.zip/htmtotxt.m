html����e�L�X�g�ւ̕ϊ�
$Id: htmtotxt.m 3511 2014-08-28 12:50:05Z kt $

*[man]
.caption ����
	htmtotxt [options]
.caption ����
���͂�html�L�q����e�L�X�g���𔲂��o���B
.caption �I�v�V����
	e -- �G���e�B�e�B��ϊ����Ȃ��B
	E -- �G���e�B�e�B�ϊ����̃G���[�𖳎�����B
	t -- �^�O���������Ȃ��B

*htmtotxt tool.@
	Mulk import: "optparse";
	Object addSubclass: #Cmd.htmtotxt instanceVars:
		"entity? ignoreError? entityMap unicodeMap"
**Cmd.htmtotxt >> makeDictionary: list
	Dictionary new ->:result;
	0 until: list size by: 2, do:
		[:i result at: (list at: i) put: (list at: i + 1)];
	result!
**Cmd.htmtotxt >> init
	self makeDictionary: #(
		"gt" '>'
		"lt" '<'
		"nbsp" ' '
		"amp" '&'
		"quot" '"'
	) ->entityMap;

	self makeDictionary: #(
		252 "u"
		8252 "!!"
		9825 "(heart)"
		9829 "(heart)"
		12316 "�`"
		21085 "��"
		21534 "��"
		25445 "��"
		25620 "�~"
		25681 "��"
		23207 "�J"
		32363 "�q"
		39606 "�Ă�"
		40333 "�C�X�J"
	) ->unicodeMap
**Cmd.htmtotxt >> entity
	entity? ifFalse: [Out put: '&'!];
	
	StringWriter new ->:w;
	[In getChar ->:ch, <> ';'] whileTrue:
		[ch nil? or: [ch = '\n'], ifTrue:
			[ignoreError? & (ch = '\n')
				ifTrue: [Out put: '&', put: w asString, putLn!]
				ifFalse: [self error: "illegal entity"]];
		w put: ch];
	w asString ->:e;

	e first = '#'
		ifTrue:
			[e copyFrom: 1 ->:code;
			code first = 'x' ifTrue: ["0" + code ->code];
			code asInteger ->code;
			code < 127
				ifTrue: [code asChar]
				ifFalse: [unicodeMap at: code ifAbsent: ["&" + e + ';']]]
		ifFalse: [entityMap at: e ifAbsent: ["&" + e + ';']] ->:t;
	Out put: t
**Cmd.htmtotxt >> main: args
	OptionParser new init: "eEt" ->:op, parse: args ->args;
	op at: 'e', not ->entity?;
	op at: 'E' ->ignoreError?;
	op at: 't', not ->:tag?;
	
	false ->:intag?;
	nil ->:tag;
	[In getChar ->:ch, notNil?] whileTrue:
		[intag?
			ifTrue:
				[ch = '>'
					ifTrue:
						[false ->intag?;
						tag asString = "br" ifTrue: [Out putLn]]
					ifFalse: [tag put: ch]]
			ifFalse:
				[ch = '<' & tag?
					ifTrue:
						[true ->intag?;
						StringWriter new ->tag]
					ifFalse:
						[ch = '&'
							ifTrue: [self entity]
							ifFalse: [Out put: ch]]]]
