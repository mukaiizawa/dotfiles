/*
	View class.
	$Id: view.h 6015 2017-01-08 02:30:43Z kt $
*/

/* properties */
#include "kbd.h" /* 0 */
#define VIEW_WIDTH 1
#define VIEW_HEIGHT 2
#define VIEW_FONT_WIDTH 3
#define VIEW_FONT_HEIGHT 4
#define VIEW_ORIGIN_X 5
#define VIEW_ORIGIN_Y 6
#define VIEW_KEYBOARD_COLOR 7 /* android only */
#define VIEW_KEYBOARD_WIDTH 8
#define VIEW_KEYBOARD_HEIGHT 9
#define VIEW_KEYBOARD_ORIGIN_X 10
#define VIEW_KEYBOARD_ORIGIN_Y 11

extern void view_set_font(char *font);
extern void view_open(int width,int height);
extern int view_set_property(int prop,int value);
extern int view_get_property(int prop,int *value);
extern void view_close(void);

extern void view_fill_rectangle(int x,int y,int width,int height,int color);
extern void view_draw_char(int x,int y,int mbchar,int color);
extern void view_draw_line(int x0,int y0,int x1,int y1,int color);
extern void view_put_true_color_image(int x,int y,char *rgb,int w,int h);
extern void view_copy_area(int fx,int fy,int w,int h,int tx,int ty);

extern int view_get(void);
extern int view_hit_p(void);
