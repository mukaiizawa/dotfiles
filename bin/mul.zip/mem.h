/*
	xc memory access.
	$Id: mem.h 2801 2013-12-14 13:11:37Z kt $
*/

#define LC(p) (*(unsigned char*)(p))
#define SC(p,v) (*(unsigned char*)(p)=(unsigned char)(v))
