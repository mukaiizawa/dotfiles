/*
	xc std.
	$Id: std.h 5299 2016-04-10 03:15:03Z kt $
*/

#define TRUE 1
#define FALSE 0

#include "config.h"

#include <stdio.h>
#include <stdarg.h>

#ifdef __BORLANDC__
#define INT64(x) (x ## i64)
typedef int intptr_t;
typedef unsigned int uintptr_t;
typedef __int64 int64_t;
#define INT32_MAX 2147483647
#define INT32_MIN (-INT32_MAX-1)
#define INTPTR_MAX INT32_MAX
#define INTPTR_MIN INT32_MIN
#define INT64_MAX INT64(9223372036854775807)
#define INT64_MIN (-INT64_MAX-1)
#else
#define INT64(x) (x ## ll)
#include <stdint.h>
#endif

#define MAX_STR_LEN 256

extern void xvsprintf(char *buf,char *fmt,va_list va);
extern void xsprintf(char *buf,char *fmt,...);

extern void xerror(char *fmt,...);
extern void *xmalloc(int size);
extern void xfree(void *);
extern void *xrealloc(void *p,int size);
extern char *xstrdup(char *s);

/* use xassert to catch assert failure. */

#ifdef NDEBUG
#define xassert(cond) ;
#else
extern void xassert_failed(char *fn,int line);
#define xassert(cond) if(!(cond)) xassert_failed(__FILE__,__LINE__);
#endif
