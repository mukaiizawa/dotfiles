/*
	view for unix.
	$Id: unixview.c 5285 2016-04-07 12:03:54Z kt $
*/

#include "std.h"

#include <locale.h>
#include <unistd.h>
#include <ctype.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <pthread.h>
#include <semaphore.h>

#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include <X11/Xlocale.h>

#include <X11/Xft/Xft.h>

#include "cqueue.h"
#include "xsleep.h"

#include "om.h"
#include "ip.h"

#include "view.h"

static Display *display;
static Atom wm_protocols,wm_delete_window;
static XFontSet fontset;
static Window window;
static XSizeHints *hints;
static GC gc,wgc;
static Pixmap pixmap;

static XftFont *font;
static Colormap colormap;
static XftDraw *draw;

static int view_width;
static int view_height;
static int font_width;
static int font_height;
static int font_ascent;

#if CYGWIN_P /* if cygwin, convert char code from SJIS to UTF-8 */
#include <iconv.h>
static iconv_t icd;
#endif

static pthread_t event_loop_thread;

static struct cqueue key_queue;
static sem_t *key_queue_sem,*key_sem;

static int shift_mode;

static int window_open_p;
static int init_p=FALSE;

static sem_t *xsem_new(char *name,int value)
{
	sem_t *result;
#if NAMED_SEMAPHORE_P
	if((result=sem_open(name,O_CREAT,S_IRWXU,value))==SEM_FAILED) {
		xerror("sem_open failed.");
	}
#else 
	result=xmalloc(sizeof(sem_t));
	sem_init(result,0,value);
#endif
	return result;
}

static void xsem_free(char *name,sem_t *sem)
{
#if NAMED_SEMAPHORE_P
	sem_close(sem);
	sem_unlink(name);
#else
	sem_destroy(sem);
	xfree(sem);
#endif
}
	
static KeySym left_keys[]={
	XK_1, XK_2, XK_3, XK_4, XK_5,
	XK_q, XK_w, XK_e, XK_r, XK_t,
	XK_a, XK_s, XK_d, XK_f, XK_g,
	XK_z, XK_x, XK_c, XK_v, XK_b
};

static int left_key_p(KeySym key)
{
	int i;
	for(i=0;i<sizeof(left_keys)/sizeof(KeySym);i++) {
		if(left_keys[i]==key) return TRUE;
	}
	return FALSE;
}

static void key_queue_put(int ch)
{
	sem_wait(key_queue_sem);
	cqueue_put(&key_queue,ch);
	sem_post(key_queue_sem);
	sem_post(key_sem);
}

static int mod_key_p(KeySym key)
{
	if(key==XK_Muhenkan) return TRUE;
	if(key==XK_Henkan) return TRUE;
	if(shift_mode==KBD_SPACE_SHIFT_MODE&&key==XK_space) return TRUE;
	return FALSE;
}

static void *event_loop(void *arg)
{
	XEvent event,event2;
	KeySym key;
	char ch;
	int autorepeat_p,left_mod_p,right_mod_p,space_mod_p,type_space_p;

	left_mod_p=right_mod_p=space_mod_p=type_space_p=FALSE;
	while(TRUE) {
		if(XPending(display)==0) {
			xsleep(0.01);
			continue;
		}
		XLockDisplay(display);
		XNextEvent(display,&event);
		XUnlockDisplay(display);
		if(event.type==DestroyNotify) break;
		
		switch(event.type) {
		case Expose:
			if(window_open_p) {
				XCopyArea(display,pixmap,window,wgc,
					event.xexpose.x,event.xexpose.y,
					event.xexpose.width,event.xexpose.height,
					event.xexpose.x,event.xexpose.y);
			}
			break;
		case ClientMessage:
			if(event.xclient.message_type==wm_protocols
				&&event.xclient.data.l[0]==wm_delete_window) {
				/* close button */
				ip_trap_code=TRAP_QUIT;
				key_queue_put(0);
			}
			break;
		case KeyPress:
			key=XLookupKeysym(&event.xkey,0);
			if(mod_key_p(key)) {
				if(key==XK_Muhenkan) left_mod_p=TRUE;
				if(key==XK_Henkan) right_mod_p=TRUE;
				if(key==XK_space) {
					space_mod_p=TRUE;
					type_space_p=TRUE;
				}
			} else {
				if(shift_mode==KBD_CROSS_SHIFT_MODE) {
					if(left_mod_p) {
						if(left_key_p(key)) event.xkey.state|=ControlMask;
						else event.xkey.state|=ShiftMask;
					}
					if(right_mod_p) {
						if(left_key_p(key)) event.xkey.state|=ShiftMask;
						else event.xkey.state|=ControlMask;
					}
				} else {
					if(left_mod_p||right_mod_p) event.xkey.state|=ControlMask;
					if(space_mod_p) {
						type_space_p=FALSE;
						event.xkey.state=ShiftMask;
					}
				}

				XLookupString((XKeyEvent*)&event,&ch,1,&key,NULL);

				if(ch!=0||key==XK_space||key==XK_at) {
					if(ch==3) ip_trap_code=TRAP_INTERRUPT;
					key_queue_put(ch);
				}
			}
			break;
		case KeyRelease:	
			key=XLookupKeysym(&event.xkey,0);
			
			if(mod_key_p(key)) {
				autorepeat_p=FALSE;
				if(XEventsQueued(display,QueuedAfterReading)) {
					XPeekEvent(display,&event2);
					autorepeat_p=event2.type==KeyPress
						&&event2.xkey.time==event.xkey.time
						&&event2.xkey.keycode==event.xkey.keycode;
					if(autorepeat_p) XNextEvent(display,&event2);
				}

				if(!autorepeat_p) {
					if(key==XK_Muhenkan) left_mod_p=FALSE;
					if(key==XK_Henkan) right_mod_p=FALSE;
					if(key==XK_space) {
						space_mod_p=FALSE;
						if(type_space_p) key_queue_put(' ');
					}
				}
			}
		default:
			break;
		}
	}
	return NULL;
}

/* api */
/** frame */

void view_open(int width,int height)
{
	if(!init_p) {
		if(setlocale(LC_ALL,"")==NULL) xerror("setlocale failed.");
		XInitThreads();
		if(!XSupportsLocale()) xerror("XSupportsLocale failed.");
		init_p=TRUE;
	}
	
	if(width==0) width=640;
	if(height==0) height=480;
	view_width=width;
	view_height=height;
	
	if((display=XOpenDisplay(NULL))==NULL) xerror("XOpenDisplay failed.");

	fontset=NULL;
	font=NULL;
	view_set_font("8x13,kanji16");

#if CYGWIN_P
	icd=iconv_open("UTF-8","CP932");
#endif

	wm_protocols=XInternAtom(display,"WM_PROTOCOLS",False);
	wm_delete_window=XInternAtom(display,"WM_DELETE_WINDOW",False);
		
	window=XCreateSimpleWindow(display,DefaultRootWindow(display),
		50,50,width,height,2,BlackPixel(display,0),WhitePixel(display,0));
	XSetStandardProperties(display,window,"mulkView","mulkView",None,
		NULL,0,NULL);
	hints=XAllocSizeHints();
	hints->flags=PMinSize|PMaxSize;
	hints->min_width=hints->max_width=width;
	hints->min_height=hints->max_height=height;
	XSetWMNormalHints(display,window,hints);
	
	XSetWMProtocols(display,window,&wm_delete_window,1);

	wgc=XCreateGC(display,window,0,NULL);
	gc=XCreateGC(display,window,0,NULL);

	pixmap=XCreatePixmap(display,window,width,height,DefaultDepth(display,0));
	colormap=DefaultColormap(display,0);
	draw=XftDrawCreate(display,pixmap,DefaultVisual(display,0),colormap);
	
	cqueue_reset(&key_queue);
	key_queue_sem=xsem_new("/mulk.key_queue",1);
	key_sem=xsem_new("/mulk.key",0);
	view_set_property(KBD_SHIFT_MODE,KBD_CROSS_SHIFT_MODE);
	
	XSelectInput(display,window,ExposureMask|StructureNotifyMask|KeyPressMask
		|KeyReleaseMask);
	XMapRaised(display,window);
	window_open_p=TRUE;

	if(pthread_create(&event_loop_thread,NULL,event_loop,NULL)!=0) {
		xerror("pthread_create failed.");
	}
}

void free_font(void)
{
	if(fontset!=NULL) {
		XFreeFontSet(display,fontset);
		fontset=NULL;
	}
	if(font!=NULL) font=NULL;
}

void view_set_font(char *font_name)
{
	char **missing,*def_return;
	int missing_count;
	XFontStruct **fslist,*fs;
	char **fnlist;
	int i,n,a,h,w;

	XGlyphInfo glyph;

	free_font();	

	if(*font_name=='*') {
		if((font=XftFontOpenName(display,0,font_name+1))==NULL) {
			xerror("XftFontOpenName failed.");
		}
		XftTextExtents8(display,font,(FcChar8*)"|",1,&glyph);
		font_width=glyph.xOff;
		font_height=glyph.height;
		font_ascent=glyph.y;
	} else {
		fontset=XCreateFontSet(display,font_name,&missing,&missing_count,
			&def_return);
		if(fontset==NULL) xerror("XCreateFontSet failed.");

		n=XFontsOfFontSet(fontset,&fslist,&fnlist);
		for(i=0;i<n;i++) {
			fs=fslist[i];

			a=fs->ascent;
			h=fs->ascent+fs->descent;
			w=fs->max_bounds.width;
			if(i==0) {
				font_ascent=a;
				font_width=w;
				font_height=h;
			} else {
				if(font_ascent<a) font_ascent=a;
				if(font_height<h) font_height=h;
				if(font_width>w) font_width=w;
			}
		}
	}
}

int view_set_property(int prop,int value)
{
	XWindowChanges changes;
	
	switch(prop) {
	case KBD_SHIFT_MODE:
		shift_mode=value;
		break;
	case VIEW_ORIGIN_X:
		changes.x=value;
		XConfigureWindow(display,window,CWX,&changes);
		break;
	case VIEW_ORIGIN_Y:
		changes.y=value;
		XConfigureWindow(display,window,CWY,&changes);
		break;
	default:
		return FALSE;
	}
	return TRUE;
}

int view_get_property(int prop,int *value)
{
	switch(prop) {
	case VIEW_WIDTH:
		*value=view_width;
		break;
	case VIEW_HEIGHT:
		*value=view_height;
		break;
	case VIEW_FONT_WIDTH:
		*value=font_width;
		break;
	case VIEW_FONT_HEIGHT:
		*value=font_height;
		break;
	default:
		return FALSE;
	}
	return TRUE;
}

void view_close(void)
{
	window_open_p=FALSE;
	
	XDestroyWindow(display,window);
	XFlush(display);
	if(pthread_join(event_loop_thread,NULL)!=0) {
		xerror("pthread_join failed");
	}
	XFree(hints);
	free_font();
	XftDrawDestroy(draw);
	XFreePixmap(display,pixmap);
	XFreeGC(display,gc);
	XFreeGC(display,wgc);
	
#if CYGWIN_P
	iconv_close(icd);
#endif
	xsem_free("/mulk.key",key_sem);
	xsem_free("/mulk.key_queue",key_queue_sem);
	XCloseDisplay(display);	
}

/** drawing */

static void expose(int x,int y,int w,int h)
{
	XExposeEvent ev;
	ev.type=Expose;
	ev.serial=0;
	ev.send_event=TRUE;
	ev.display=display;
	ev.window=window;
	ev.x=x;
	ev.y=y;
	ev.width=w;
	ev.height=h;
	ev.count=0;

	XSendEvent(display,window,True,ExposureMask,(XEvent*)&ev);
	XFlush(display);
}

void view_fill_rectangle(int x,int y,int width,int height,int color)
{
	XSetForeground(display,gc,color);
	XFillRectangle(display,pixmap,gc,x,y,width,height);
	expose(x,y,width,height);
}

void view_draw_char(int x,int y,int mbchar,int color)
{
	char buf[3];
	int buflen;
	XRectangle extents;

	XGlyphInfo glyph;
	
	buflen=0;
	if(mbchar&0xff0000) buf[buflen++]=(mbchar>>16)&0xff;
	if(mbchar&0xff00) buf[buflen++]=(mbchar>>8)&0xff;
	buf[buflen++]=mbchar&0xff;

	if(fontset!=NULL) {
		XSetForeground(display,gc,color);
		XmbDrawString(display,pixmap,fontset,gc,x,y+font_ascent,buf,buflen);
		XmbTextExtents(fontset,buf,buflen,NULL,&extents);
		expose(x+extents.x,y+font_ascent+extents.y,extents.width,
			extents.height);
	} else {
		XftColor ftc;
		XRenderColor rc;
		rc.red=((color>>16)&0xff)*0x101;
		rc.green=((color>>8)&0xff)*0x101;
		rc.blue=(color&0xff)*0x101;
		rc.alpha=0xffff;
		XftColorAllocValue(display,DefaultVisual(display,0),colormap,&rc,
			&ftc);
#if CYGWIN_P
		{
			char *in,*out,buf2[3];
			size_t inleft,outleft;
			in=buf;
			out=buf2;
			inleft=buflen;
			outleft=3;
			iconv(icd,&in,&inleft,&out,&outleft);
			XftDrawStringUtf8(draw,&ftc,font,x,y+font_ascent,(FcChar8*)buf2,
				3-outleft);
			XftTextExtentsUtf8(display,font,(FcChar8*)buf2,3-outleft,&glyph);
		}
#else
		XftDrawStringUtf8(draw,&ftc,font,x,y+font_ascent,(FcChar8*)buf,
			buflen);
		XftTextExtentsUtf8(display,font,(FcChar8*)buf,buflen,&glyph);
#endif
		XftColorFree(display,DefaultVisual(display,0),colormap,&ftc);
		expose(x-glyph.x,y+font_ascent-glyph.y,glyph.width,glyph.height);
	}
}

void view_draw_line(int x0,int y0,int x1,int y1,int color)
{
	int x,y,w,h;
	
	XSetForeground(display,gc,color);
	XDrawLine(display,pixmap,gc,x0,y0,x1,y1);

	if(x0>x1) {
		x=x1;
		w=x0-x1+1;
	} else {
		x=x0;
		w=x1-x0+1;
	}

	if(y0>y1) {
		y=y1;
		h=y0-y1+1;
	} else {
		y=y0;
		h=y1-y0+1;
	}
	
	expose(x,y,w,h);
}

void view_put_true_color_image(int x,int y,char *rgb,int w,int h)
{
	Visual *visual;
	XImage *image;
	char *bgrx,*p,*q;
	int i;
	visual=DefaultVisual(display,0);
	if(visual->class!=TrueColor) xerror("Xserver does not support truecolor.");
	bgrx=xmalloc(w*h*4);
	p=rgb;
	q=bgrx;
	for(i=0;i<w*h;i++) {
		q[0]=p[2];
		q[1]=p[1];
		q[2]=p[0];
		q[3]=0;
		p+=3;
		q+=4;
	}
	
	image=XCreateImage(display,visual,24,ZPixmap,0,bgrx,w,h,32,0);
	XPutImage(display,pixmap,gc,image,0,0,x,y,w,h);
	XDestroyImage(image);
	expose(x,y,w,h);
}

void view_copy_area(int fx,int fy,int w,int h,int tx,int ty)
{
	XCopyArea(display,pixmap,pixmap,gc,fx,fy,w,h,tx,ty);
	expose(tx,ty,w,h);
}

/** keyboard */

int view_get(void)
{
	int result;
	sem_wait(key_sem);
	sem_wait(key_queue_sem);
	result=cqueue_get(&key_queue);
	sem_post(key_queue_sem);
	return result;
}

int view_hit_p(void)
{
	return !cqueue_empty_p(&key_queue);
}
