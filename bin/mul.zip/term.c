/*
	Terminal class.
	$Id: term.c 6287 2017-05-20 06:00:15Z kt $
*/

#include "std.h"
#include "term.h"
#include "om.h"

#include "prim.h"

PRIM(term_start)
{
	term_start();
	return TRUE;
}

PRIM(term_set_property)
{
	int prop,value;
	GET_SINT_ARG(0,prop);
	GET_SINT_ARG(1,value);
	return term_set_property(prop,value);
}

PRIM(term_get_property)
{
	int prop,value,st;
	GET_SINT_ARG(0,prop);
	st=term_get_property(prop,&value);
	*result=sint(value);
	return st;
}

PRIM(term_finish)
{
	term_finish();
	return TRUE;
}

PRIM(term_get)
{
	*result=sint(term_get());
	return TRUE;
}

PRIM(term_put)
{
	int wc;
	char buf[3],*p;

	GET_SINT_ARG(0,wc);
	if(!(0<=wc&&wc<=0xffffff)) return FALSE;
	p=buf+2;
	while(wc>=256) {
		*p--=wc&0xff;
		wc=wc>>8;
	}
	*p=wc;
	term_put(p,buf+3-p);
	return TRUE;
}

PRIM(term_hit_p)
{
	*result=om_boolean(term_hit_p());
	return TRUE;
}

PRIM(term_goto_xy)
{
	int x,y;
	GET_SINT_ARG(0,x);
	GET_SINT_ARG(1,y);
	term_goto_xy(x,y);
	return TRUE;
}

PRIM(term_clear)
{
	term_clear();
	return TRUE;
}
