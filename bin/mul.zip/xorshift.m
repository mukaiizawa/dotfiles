Xor shift�@ (RandomGenerator.XorShift class)
$Id: xorshift.m 3980 2015-01-28 12:31:49Z kt $

initialize idea: http://d.hatena.ne.jp/gintenlabo/20100930/1285859540

*[man]
.caption ����
Xor shift�@�ɂ�闐��������B
.hierarchy RandomGenerator.XorShift
.caption �֘A����
.overview randgen

*@
	Mulk import: "randgen"

*RandomGenerator.XorShift class.@
	RandomGenerator addSubclass: #RandomGenerator.XorShift instanceVars:
		"x y z w"
**RandomGenerator.XorShift >> randomize: seed
	seed | (seed & 0x7fffffff << 32) ->seed;
	123456789 ^ seed & 0xffffffff ->x;
	362436069 ^ (seed >> 15) & 0xffffffff ->y;
	521288629 ^ (seed >> 1) & 0xffffffff ->z;
	88675123 ^ (seed >> 14) & 0xffffffff ->w;
	40 timesRepeat: [self int32]
**RandomGenerator.XorShift >> int32
	x ^ (x << 11) & 0xffffffff ->:t;
	y ->x;
	z ->y;
	w ->z;
	w ^ (w >> 19) ^ t ^ (t >> 8) ->w!
