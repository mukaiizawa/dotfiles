Jpeg.Reader class.
$Id: jpeg.m 5622 2016-08-28 03:09:48Z kt $

*[man]
.caption ����
libjpeg���C�u�����̃��b�p�[�N���X�ŁAjpeg�t�@�C����ǂݍ��ދ@�\��񋟂���B
.hierarchy Jpeg.Reader
.caption �֘A����
.overview view

*import.@
	Mulk import: #("dl" "view")

*import libjpeg.@
	Mulk.hostOS = #linux ifTrue: ["libjpeg.so" ->:lib];
	Mulk.hostOS = #windows ifTrue: ["libjpeg-9.dll" ->lib];
	DL import: lib procs:
		#(#jpeg_std_error 1 #jpeg_CreateDecompress 3 #jpeg_stdio_src 2
		#jpeg_read_header 2 #jpeg_start_decompress 1 #jpeg_read_scanlines 3
		#jpeg_finish_decompress 1 #jpeg_destroy_decompress 1)

*Jpeg.Decompress class.@
	DL.Struct addSubclass: #Jpeg.Decompress
**Jpeg.Decompress >> init
	super init;
	Mulk.hostOS = #linux ifTrue: [656 ->:size]; --64bit only.
	Mulk.hostOS = #windows ifTrue:
		[Mulk.ptrByteSize = 4 ifTrue: [456] ifFalse: [632] ->size];
	self init: size;

	FixedByteArray basicNew:
		(Mulk.ptrByteSize = 4 ifTrue: [132] ifFalse: [168]) ->:err;
	nc addChunk: err;
	self at: 0 put: (DL call: #jpeg_std_error with: err);

	Mulk.hostOS = #linux ifTrue: [80] ifFalse: [90] ->:version;	
	DL call: #jpeg_CreateDecompress with: self with: version with: buffer size
**Jpeg.Decompress >> width
	buffer nativeInt32At: (Mulk.ptrByteSize = 4 ifTrue: [28] ifFalse: [48])!
**Jpeg.Decompress >> height
	buffer nativeInt32At: (Mulk.ptrByteSize = 4 ifTrue: [32] ifFalse: [52])!
**Jpeg.Decompress >> destroy
	DL call: #jpeg_destroy_decompress with: self

*Jpeg.Reader class.@
	Object addSubclass: #Jpeg.Reader
**Jpeg.Reader >> readImage: fn
	Jpeg.Decompress new ->:dinfo;
	fn asFile openRead ->:fs;
	DL call: #jpeg_stdio_src with: dinfo with: fs fp;
	DL call: #jpeg_read_header with: dinfo with: 1;

	dinfo width ->:w;
	dinfo height ->:h;

	w * 3 ->:row;
	FixedByteArray basicNew: row * h ->:dbuf;
	dbuf address ->:adr;
	DL.IntPtrBuffer new ->:arg;

	DL call: #jpeg_start_decompress with: dinfo;
	h timesDo:
		[:y
		arg value: adr;
		DL call: #jpeg_read_scanlines with: dinfo with: arg with: 1;
		adr + row ->adr];

	DL call: #jpeg_finish_decompress with: dinfo;
	dinfo destroy;

	fs close;
	
	View.Image new initWidth: w height: h buffer: dbuf!
***[man.m]
fn��jpeg�t�@�C����ǂݍ��݁AView.Image�̃C���X�^���X��Ԃ��B
