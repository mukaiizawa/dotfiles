/*
	dynamic library.
	$Id: dl.h 2778 2013-12-08 09:49:08Z kt $
*/

extern int dl_call(object *args,object *result,
	intptr_t (*callg)(intptr_t f,int argc,intptr_t argv[]));
