/*
	keyboard mode.
	$Id: kbd.h 2325 2013-05-18 23:03:32Z kt $
*/
#define KBD_SHIFT_MODE 0 /* property */
#define KBD_CROSS_SHIFT_MODE 0
#define KBD_SPACE_SHIFT_MODE 1
