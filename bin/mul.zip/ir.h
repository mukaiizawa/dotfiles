/*
	image reader.
	$Id: ir.h 37 2009-09-22 12:22:37Z kt $
*/

extern void ir(char *fn);
